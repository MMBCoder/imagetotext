# Moving the .pbix to another machine

## The short version

**Opening and reading the dashboard needs nothing at all.** A `.pbix` carries an
imported copy of the data inside it, so every page, number and chart works on a
machine that has never seen the source files.

You only have to change something if you want to **refresh** it - pull new dates
out of the workbook. Then Power BI has to find the workbook again, and on a
different machine it lives somewhere else.

---

## What the model reads

| Read as | Holds | Required? |
|---|---|---|
| `<ProjectDataFolder>\<SourceWorkbookName>` | the daily data, sheet `idr` | **yes** |
| `<ProjectDataFolder>\Thresholds.csv` | alert thresholds and health-score weights | optional |
| `<ProjectDataFolder>\MetricDefinitions.csv` | the glossary behind the Definitions page | optional |

**Only the workbook is required.** Both CSVs fall back to defaults baked into the
model at build time:

```
FromFile = try Csv.Document( File.Contents( ... ) ) otherwise null,
Default  = #table( ... 17 threshold rows ... ),
Source   = if FromFile = null then Default else FromFile
```

The file wins when it is there; the defaults are used when it is not. A machine
that has only the workbook still refreshes, still alerts, and still shows the
Definitions page. Drop a `Thresholds.csv` next to the workbook later and it takes
over immediately, with no model change.

Verified by hiding both CSVs and refreshing: 17 threshold rows and 33 glossary
rows loaded, 13/13 partitions ready, and the alert engine returned the same
6 alerts / 4 critical as with the files present.

The parameters currently point at the machine this was built on:

```
ProjectDataFolder  = C:\Users\mirza\OneDrive\Documents\codex\IDR_Executive_Monitoring\data
SourceWorkbookName = idr_kafka_edl.xlsx
SourceSheetName    = idr
```

---

## First: there is no .pbix until Desktop makes one

This repository contains a **PBIP project**, not a `.pbix`. A `.pbix` is a ZIP
package whose model part only Power BI Desktop's engine can write, so it cannot
be generated from source - it has to be produced by opening the project and
using **File > Save as**.

Renaming `IDR_Executive_Monitoring.pbip` to `.pbix` does **not** work. The
`.pbip` is a 196-byte JSON pointer file; Power BI opens a `.pbix` as a ZIP,
finds text, and reports:

```
'...IDR_Executive_Monitoring.pbix' can't be opened.
Either the file is encrypted or corrupted.
  InnerException: File contains corrupted data.
    at ZipIOEndOfCentralDirectoryBlock.FindPosition(Stream archiveStream)
```

A ZIP-header failure like that means the file is not a package at all.

### Produce the .pbix on the machine that will use it

Preferably build it on the target machine rather than shipping one across,
because a `.pbix` written by a newer Desktop may be refused by an older one.

1. Copy these three items to the target machine, keeping them side by side:

```
IDR_Executive_Monitoring.pbip
IDR_Executive_Monitoring.ReportIDR_Executive_Monitoring.SemanticModel```

   About 880 KB in total. The `data` folder is optional - see below.

2. Open `IDR_Executive_Monitoring.pbip`. If Desktop does not offer to open it,
   enable **File > Options and settings > Options > Preview features > Power BI
   Project (.pbip) save option** and restart.
3. Repoint the parameters (Case B, step 3) at the local workbook.
4. **Home > Refresh**.
5. **File > Save as > Power BI file (.pbix)**.

From then on that `.pbix` is self-contained and opens with no configuration.

---

## Case A - you only want to look at it

1. Copy `IDR_Executive_Monitoring.pbix` to the other machine.
2. Open it.

Done. Every visual renders from the data stored inside the file. Do **not** press
Refresh - that is the one action that needs the workbook, and it will fail with a
`DataSource.Error` if the path does not resolve there.

---

## Case B - you want to refresh it there

### 1. Note where the workbook lives

Only the workbook has to be reachable - a local drive, a synced OneDrive folder,
or a UNC path such as `\\server\share\IDR`.

Copying the two CSVs alongside it is optional. Do it if you want to retune alert
thresholds on that machine without rebuilding the model; skip it and the built-in
defaults apply.

### 2. Open the .pbix

Ignore any refresh error on open - you are about to fix its cause.

### 3. Repoint the parameters

**Home** → the small arrow under **Transform data** → **Edit parameters**.

| Parameter | Set to |
|---|---|
| `ProjectDataFolder` | the folder holding the workbook, **no trailing backslash** |
| `SourceWorkbookName` | the file name exactly as File Explorer shows it, including the extension |
| `SourceSheetName` | `idr` unless the tab was renamed |

Click **OK**.

> Same dialog inside Power Query: **Transform data** → **Manage Parameters** →
> **Edit Parameters**.

### 4. Apply

**Close & Apply** in the Power Query editor, or **Apply changes** on the yellow
pending-changes bar.

### 5. Approve the data source the first time

A new machine has no saved permission for that folder, so expect one or both of:

- **"Access to the file is required"** → **Edit Permissions** → set
  authentication (**Windows** for a corporate share) → **OK**.
- **"Information is required about data privacy"** → set the source to
  **Organizational** → **Save**.

### 6. Refresh, then save

**Home** → **Refresh**, then **Ctrl+S** so the new path and refreshed data are
stored in the file.

---

## Weekly append workflow

The model is built for exactly this. Append the new rows to the bottom of the
`idr` tab, save the workbook, open the `.pbix` and press **Refresh**. Nothing
else to touch:

- `Dim_Date` is generated as `CALENDAR(MIN(Event Date), MAX(Event Date))`, so the
  calendar extends itself to cover the new dates
- the date-range slicer picks up the wider range automatically
- rolling baselines, z-scores and the weekly reason trend all re-evaluate
- the resolution rate is a period sum, so selecting a wider range just includes
  the new dates

Two things that will silently break it:

- **renaming a column header.** The query uses `MissingField.Ignore`, so a
  renamed column is skipped rather than erroring - the measure that depended on
  it goes blank instead of failing loudly.
- **appending to a different sheet.** `SourceSheetName` falls back to the *first*
  sheet if the named one is missing, which may be the wrong tab.

---

## Refreshing in the Power BI Service

The Service cannot reach a local drive.

- **Local or network folder** → install an **on-premises data gateway** on a
  machine that can see the folder, bind the dataset to it, then schedule refresh.
- **Simpler** → keep the workbook in **OneDrive for Business** or **SharePoint**
  and point `ProjectDataFolder` at that location. Cloud-hosted files refresh in
  the Service without a gateway.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `DataSource.Error: Could not find file ...` | `ProjectDataFolder` still points at the old machine, or has a trailing `\` | Redo step 3 |
| Refresh fails on `Dim_Thresholds` or `Dim_Metric_Definitions` | A CSV is present but malformed - a readable-but-broken file is used rather than ignored | Fix its header row, or delete the file and let the built-in defaults apply |
| Every visual reads "No data" | The `.pbip` was opened rather than the `.pbix` - a project stores no data | Press **Home → Refresh** once, or use the `.pbix` |
| Refresh succeeds but a column is blank | A workbook header was renamed | Restore the header. `MissingField.Ignore` skips unknown names silently |
| Wrong sheet loaded | `SourceSheetName` no longer matches | Set it in step 3 |
| Old path keeps coming back | Cached data source permission | **File → Options and settings → Data source settings** → select the old path → **Clear permissions** |
