# Data Dictionary

Generated from the semantic model by `tools/gen_docs.py`. Every entry below is read out of the TMDL that Power BI loads, so this document and the model cannot disagree.

- **Tables:** 13
- **Measures:** 633
- **Grain:** one row per `Event Date` in `Fact_IDR_Daily`

## 1. Source column mapping

Power Query renames the workbook headers into model names. `MissingField.Ignore` is used, so a header that is absent is skipped rather than breaking the refresh.

| Workbook header | Model column | Type | Meaning |
|---|---|---|---|
| `Total EDL Logins` | Total EDL Logins | int64 | Total logins at sessionid level in the EDL data. |
| `Unique EDL Logins` | Unique EDL Logins | int64 | Total logins at syfid (profile) level in the EDL data. |
| `Total Kafka Logins Events` | Total Kafka Logins Events | int64 | Total logins at sessionid level in the CDP data. |
| `Unique Kafka Logins at Profile` | Unique Kafka Logins at Profile | int64 | Total logins at syfid (profile) level in the CDP data. |
| `Web_IDR_Resolved` | Web IDR Resolved | int64 | Web login at syfid level in the CDP data. |
| `App_IDR_Resolved` | App IDR Resolved | int64 | App login at syfid level in the CDP data. |
| `_IDR_Resolved` | IDR Resolved | int64 | Profiles where identity resolved: web + kafka + account, or app + kafka + account. Equals Web IDR Resolved plus App IDR Resolved on every loaded row. |
| `IDR_Resolved` | IDR Resolved | | *alias, tolerated if present* |
| `IDR_Not_Resolved` | IDR Not Resolved | int64 | Profiles where identity did not resolve because at least one of the three events is missing. Equals the sum of the eight partial-match populations below on every loaded row. |
| `Web_Only` | Web Only | int64 | Profiles with a web event only in CDP. Counts towards IDR Not Resolved. |
| `Kafka_Only` | Kafka Only | int64 | Profiles with a kafka event only in CDP. Counts towards IDR Not Resolved. |
| `App_Only` | App Only | int64 | Profiles with an app event only in CDP. Counts towards IDR Not Resolved. |
| `Kafka_and_Web` | Kafka and Web | int64 | Profiles with kafka and web events only in CDP - the account event is missing. Counts towards IDR Not Resolved. |
| `Kafka_and_Apps` | Kafka and Apps | int64 | Profiles with kafka and apps events only in CDP - the account event is missing. Counts towards IDR Not Resolved. |
| `Web_and_Account` | Web and Account | int64 | Profiles with web and account events only in CDP - the kafka event is missing. Counts towards IDR Not Resolved. |
| `Kafka_and_Account` | Kafka and Account | int64 | Profiles with kafka and account events only in CDP - the web or app event is missing. Counts towards IDR Not Resolved. |
| `Apps_and_Account` | Apps and Account | int64 | Profiles with apps and account events only in CDP - the kafka event is missing. Counts towards IDR Not Resolved. |
| `Difference Total EDL vs Kafka Logins` | Difference Total EDL vs Kafka Logins | int64 | Difference between EDL and CDP at sessionid level. Positive means EDL recorded more. |
| `Difference Unique EDL vs Kafka Logins` | Difference Unique EDL vs Kafka Logins | int64 | Difference between EDL and CDP at syfid (profile) level. Positive means EDL recorded more. |
| `Event_date` | Event Date | dateTime | Business date of the daily snapshot. The grain of this table is one row per Event Date. |
| `Overall Idr Resolution Rate (%)` | Overall IDR Resolution Rate | double | Raw source column, shipped empty. The rate is calculated over the selected date range by the measure of the same name. |
| `apps_idr_resolved_edl` | Apps IDR Resolved EDL | int64 | Source column apps_idr_resolved_edl: apps IDR resolved at syfid (profile) level in EDL. |
| `web_idr_resolved_edl` | Web IDR Resolved EDL | int64 | Source column web_idr_resolved_edl: web IDR resolved at syfid (profile) level in EDL. |

> The workbook ships the resolved-count header as `_IDR_Resolved`, with a leading underscore. Both that and the plain `IDR_Resolved` spelling are mapped, so either is accepted.

## 2. Tables

| Table | Kind | Purpose |
|---|---|---|
| `Fact_IDR_Daily` | Import (Excel) | Daily snapshot. One row per Event Date. All columns hidden; the measure layer is the only analytical surface. |
| `Fact_Overlap_Daily` | Calculated | The eight identity populations unpivoted to one row per date and segment. Makes segment-level anomaly ranking a single measure instead of eight. |
| `Dim_Date` | Calculated | Date dimension spanning exactly the loaded data. Marked as the model date table. |
| `Dim_Thresholds` | Import (CSV) | Business-editable alert thresholds and health-score weights. |
| `Dim_Metric_Definitions` | Import (CSV) | Business glossary driving the Metric Definitions page. |
| `Dim_Alert_Rules` | Calculated | Catalogue of the nine alert rules. Disconnected. |
| `Dim_Scorecard` | Calculated | Rows of the Management Summary scorecard. Disconnected. |
| `Dim_Timeframe` | Calculated | Timeframe selector for Historical Trends. Disconnected. |
| `Dim_Metric_Watch` | Calculated | Headline metric watchlist; row source of the Root Cause comparison table. Disconnected. |
| `Dim_DQ_Checks` | Calculated | Catalogue of data-quality checks. Disconnected. |
| `Trend Metric` | Field parameter | Metric selector for the Historical Trends chart. |
| `Refresh Info` | Import (inline) | Single-row model refresh timestamp. |
| `_Metrics` | Calculated | Home table for all 633 explicit measures. Holds no data. |

### Relationships

| From | To | Cardinality | Direction |
|---|---|---|---|
| `Fact_IDR_Daily[Event Date]` | `Dim_Date[Date]` | many-to-one | single |
| `Fact_Overlap_Daily[Event Date]` | `Dim_Date[Date]` | many-to-one | single |

Every other dimension is deliberately **disconnected**: it drives a `SWITCH` in the measure layer rather than filtering the fact table.

## 3. Why resolution failed - the eight partial-match populations

Resolution needs three events: (web or app) + kafka + account. Each row is
a population that carried only part of that evidence. They sum exactly to
IDR Not Resolved on every loaded row.

| Segment | Evidence held | Missing event | Order |
|---|---|---|---|
| Kafka and Web | Two of three | Account | 1 |
| Kafka and Apps | Two of three | Account | 2 |
| Kafka and Account | Two of three | Web or App | 3 |
| Web and Account | Two of three | Kafka | 4 |
| Apps and Account | Two of three | Kafka | 5 |
| Web Only | One of three | Kafka and Account | 6 |
| App Only | One of three | Kafka and Account | 7 |
| Kafka Only | One of three | Web or App, and Account | 8 |

## 4. Alert rules

| Key | Rule | Domain | Priority | What it detects |
|---|---|---|---|---|
| `R07` | Multi-Signal Compound Incident | Compound | 1 | Several independent controls failing on the same date, which points to one upstream cause. |
| `R01` | IDR Resolution Rate Breach | IDR | 2 | Resolution rate below its absolute threshold, or falling materially against the previous day or the 7-day baseline. |
| `R02` | IDR Not Resolved Spike | IDR | 3 | Unresolved IDR volume above its baseline growth tolerance, its absolute ceiling, or its z-score tolerance. |
| `R04` | Reconciliation Direction Reversal | Reconciliation | 4 | Signed EDL/Kafka variance changed direction. A move to negative means Kafka now exceeds EDL. |
| `R03` | EDL vs Kafka Reconciliation Drift | Reconciliation | 5 | EDL/Kafka reconciliation rate drifting against its own 7-day baseline, on total or unique volume. |
| `R06` | Volume Anomaly | Volume | 6 | Login volume outside the recent noise band, judged by z-score so normal growth is not flagged. |
| `R05` | Overlap Population Anomaly | Overlap | 7 | One of the eight identity overlap populations moved abnormally against its 7-day baseline. |
| `R08` | Data Quality Warning | Data Quality | 8 | Structural data-quality defects detected in the loaded data. |
| `R09` | Source vs Calculated Rate Variance | Data Quality | 9 | The resolution rate published by the source disagrees with the rate recalculated from the counts. |

Severity ranks: `0` no data, `1` healthy, `2` warning, `3` critical. `Alert Priority Score = rank x 1000 + (100 - priority)`, so severity always dominates and priority only breaks ties inside a severity.

## 5. Threshold configuration

Read from `data/Thresholds.csv` at refresh. Edit that file and refresh; no DAX change is required.

| Key | Metric | Warning | Critical | Direction | Health weight | Unit |
|---|---|---:|---:|---|---:|---|
| `IDR_RESOLUTION_RATE` | IDR Resolution Rate | 0.985 | 0.97 | Lower is worse | 30 | Ratio |
| `IDR_RESOLUTION_RATE_DROP` | IDR Resolution Rate Drop | 0.005 | 0.01 | Higher is worse | 0 | Ratio |
| `IDR_NOT_RESOLVED_VS_BASELINE` | IDR Not Resolved vs 7D Baseline | 0.25 | 0.5 | Higher is worse | 20 | Ratio |
| `IDR_NOT_RESOLVED_ABS` | IDR Not Resolved Absolute | 15000 | 30000 | Higher is worse | 0 | Count |
| `IDR_NOT_RESOLVED_ZSCORE` | IDR Not Resolved Z-Score | 2 | 3 | Higher is worse | 0 | Score |
| `RECON_DRIFT_PP` | EDL vs Kafka Reconciliation Drift | 0.05 | 0.1 | Higher is worse | 20 | Ratio |
| `RECON_GAP_PCT` | EDL vs Kafka Absolute Gap | 0.3 | 0.4 | Higher is worse | 0 | Ratio |
| `RECON_DIRECTION` | Reconciliation Direction Reversal | 1 | 1 | Higher is worse | 0 | Flag |
| `VOLUME_ZSCORE` | Volume Anomaly Z-Score | 2 | 3 | Higher is worse | 10 | Score |
| `OVERLAP_CHANGE_PCT` | Overlap Population Change | 0.5 | 1 | Higher is worse | 10 | Ratio |
| `OVERLAP_ZSCORE` | Overlap Population Z-Score | 2 | 3 | Higher is worse | 0 | Score |
| `DATA_QUALITY` | Data Quality Issues | 1 | 3 | Higher is worse | 10 | Count |
| `SOURCE_VS_CALC_RATE` | Source vs Calculated Rate Variance | 0.01 | 0.02 | Higher is worse | 0 | Ratio |
| `MIN_BASELINE_DAYS` | Minimum Baseline Days for Z-Score | 7 | 7 | Configuration | 0 | Days |
| `MIN_DRIFT_BASELINE_DAYS` | Minimum Baseline Days for Drift | 3 | 3 | Configuration | 0 | Days |
| `OVERLAP_MIN_ABS_CHANGE` | Overlap Minimum Absolute Move | 500 | 2000 | Higher is worse | 0 | Count |
| `VOLUME_MIN_CHANGE_PCT` | Volume Minimum Relative Move | 0.15 | 0.25 | Higher is worse | 0 | Ratio |

Health-score weights sum to 100 across the six scored components. A weight of `0` means the metric drives alerting but not the score.

## 6. Data-quality checks

| Key | Check | Category | Measure | Detects |
|---|---|---|---|---|
| `DQ01` | Missing Event Date | Structural | `[DQ Missing Event Date]` | Rows with no business date. Such rows cannot be placed on any trend. |
| `DQ02` | Duplicate Event Date | Structural | `[DQ Duplicate Date Count]` | More than one row for the same date. Breaks the daily grain and double counts every SUM. |
| `DQ03` | Null in required column | Structural | `[DQ Null Value Count]` | A column that must always be populated is empty. |
| `DQ04` | Negative count value | Structural | `[DQ Negative Value Count]` | A count column holds a negative number. The two difference columns are excluded: negative is valid there. |
| `DQ05` | Web + App does not equal IDR Resolved | Arithmetic | `[DQ IDR Consistency Breaches]` | Channel-level resolved counts do not reconcile to the total. |
| `DQ06` | Published difference disagrees with recomputed | Arithmetic | `[DQ Reconciliation Consistency Breaches]` | The published EDL/Kafka difference does not equal the difference recomputed from the volume columns. |
| `DQ07` | Published rate outside 0-100% | Arithmetic | `[DQ Unexpected Resolution Rate Count]` | The published resolution rate is not a valid proportion. |
| `DQ08` | Published rate differs from recalculated rate | Trust | `[DQ Rate Variance Breaches]` | The source percentage disagrees with the rate recalculated from the counts beyond tolerance. |
| `DQ09` | Missing calendar day | Completeness | `[DQ Missing Day Count]` | A day inside the loaded range carries no data at all. |
| `DQ10` | Unexpected volume movement | Analytical | `[DQ Unexpected Volume Movement Count]` | Login volume beyond the critical z-score tolerance. Reported here, alerted through Rule 6. |
| `DQ11` | Unexpected overlap movement | Analytical | `[DQ Unexpected Overlap Movement Count]` | An identity population beyond the critical tolerance. Reported here, alerted through Rule 5. |
| `DQ12` | Unexpected resolution movement | Analytical | `[DQ Unexpected Resolution Movement Count]` | Resolution rate below the critical threshold. Reported here, alerted through Rule 1. |

**Structural**, **Arithmetic**, **Trust** and **Completeness** checks count toward `Data Quality Issue Count` and the health score. **Analytical** findings are surfaced here but alerted through the rule engine, so nothing is scored twice.

## 7. Trend-intelligence pattern

Every headline KPI carries the same set of derived measures, so any metric can be read the same way anywhere in the report.

| Suffix | Meaning |
|---|---|
| `(Current)` | Value on the selected business date. |
| `(Previous Day)` | Value on the previous date **that has data** (gap-safe). |
| `(Delta)` | Day-on-day movement. |
| `(Delta %)` | Day-on-day movement as a percentage. |
| `(Delta pp)` | Day-on-day movement in percentage points (rate metrics only). |
| `(7D Avg)` | Rolling seven-day average **including** the selected date. |
| `(7D Baseline)` | Mean of the seven days **before** the selected date. Excluding the day under judgement is what makes a single-day spike detectable. |
| `(vs 7D Baseline)` | Movement against that baseline. |
| `(vs 7D Baseline %)` | Movement against that baseline, as a percentage. |
| `(vs 7D Baseline pp)` | Movement against that baseline, in percentage points (rate metrics only). |
| `(7D StDev)` | Volatility over the baseline window. Hidden. |
| `(Z-Score)` | Standard deviations from the baseline. **Blank** until the baseline holds `MIN_BASELINE_DAYS` observations. |
| `(Historical Avg / Min / Max)` | Across all history up to the selected date. |
| `(Volatility)` | Coefficient of variation over the baseline window. |
| `(Trend)` | Rising / Falling / Stable against the baseline. |

Metrics carrying the full pattern:

- `IDR Resolution Rate` (format `0.00%`, governed by `[Sev Rank IDR Resolution]`)
- `IDR Non-Resolution Rate` (format `0.00%`, governed by `[Sev Rank IDR Resolution]`)
- `IDR Not Resolved` (format `#,##0`, governed by `[Sev Rank IDR Not Resolved]`)
- `IDR Resolved` (format `#,##0`, governed by `[Sev Rank IDR Resolution]`)
- `Web IDR Resolved` (format `#,##0`)
- `App IDR Resolved` (format `#,##0`)
- `Web Resolution %` (format `0.0%`)
- `App Resolution %` (format `0.0%`)
- `Total EDL Logins` (format `#,##0`, governed by `[Sev Rank Volume]`)
- `Unique EDL Logins` (format `#,##0`, governed by `[Sev Rank Volume]`)
- `Total Kafka Logins Events` (format `#,##0`, governed by `[Sev Rank Volume]`)
- `Unique Kafka Logins` (format `#,##0`, governed by `[Sev Rank Volume]`)
- `Total EDL vs Kafka Difference` (format `+#,##0;-#,##0;0`, governed by `[Sev Rank Direction]`)
- `Unique EDL vs Kafka Difference` (format `+#,##0;-#,##0;0`, governed by `[Sev Rank Direction]`)
- `Total Reconciliation %` (format `0.0%`, governed by `[Sev Rank Reconciliation]`)
- `Unique Reconciliation %` (format `0.0%`, governed by `[Sev Rank Reconciliation]`)
- `Absolute Total Difference` (format `#,##0`, governed by `[Sev Rank Reconciliation]`)
- `Overlap Population` (format `#,##0`, governed by `[Sev Rank Overlap]`)

## 8. Measure catalogue

| Display folder | Measures |
|---|---:|
| 00 - Selected Period | 32 |
| 01 - Executive KPIs | 18 |
| 02 - IDR | 26 |
| 03 - Reconciliation | 24 |
| 04 - Volume | 11 |
| 05 - Overlap | 24 |
| 06 - Alerts | 25 |
| 07 - Data Quality | 25 |
| 08 - Trend Intelligence | 345 |
| 09 - Configuration | 57 |
| 10 - Health Score | 6 |
| 11 - Narrative | 6 |
| 12 - Report UX | 34 |
| **Total** | **633** |

### 00 - Selected Period

| Measure | Format | Description |
|---|---|---|
| `Active Alerts Caption` | text | Caption under the active alert count. |
| *(hidden)* `Alert Flag Colour` | text | Semantic colour for the active alert count. |
| `App Device Caption` | text | Subtitle for the app device comparison. |
| `App Gap Caption` | text | Caption under the app difference card. |
| *(hidden)* `App Match Colour` | text | Semantic colour for the app device match rate. |
| `App Share Caption` | text | Caption under App IDR Resolved. |
| `Critical Alerts Caption` | text | Caption under the critical alert count. |
| `Data Quality Caption` | text | Caption under the data quality status. |
| `Health Score Caption` | text | Caption under the platform health score. |
| `Period Attempted Caption` | text | Caption under Profiles Attempted. |
| `Period Narrative` | text | Plain-language summary of the selected period for the overview page. |
| `Period Not Resolved Caption` | text | Caption under IDR Not Resolved. |
| `Period Rate Caption` | text | Caption under the overall resolution rate. |
| *(hidden)* `Period Rate Colour` | text | Semantic colour for the period resolution rate, against the configured thresholds. |
| `Period Resolved Caption` | text | Caption under IDR Resolved. |
| `Profile Gap Caption` | text | Caption under the unique difference. |
| `Profile Level Caption` | text | Caption under Unique EDL Logins. |
| `Profile Match Caption` | text | Caption under Unique Kafka Logins at Profile and the profile match rate. |
| *(hidden)* `Profile Match Colour` | text | Semantic colour for the syfid-level match rate. |
| `Selected Day Count` | `#,##0` | Number of event dates in the current selection. |
| `Selected Period Label` | text | The event date range currently selected, for the page subtitle. |
| `Session Gap Caption` | text | Caption under the total difference. |
| `Session Level Caption` | text | Caption under Total EDL Logins. |
| `Session Match Caption` | text | Caption under Total Kafka Logins Events and the session match rate. |
| *(hidden)* `Session Match Colour` | text | Semantic colour for the sessionid-level match rate. |
| `Top Missing Caption` | text | Caption under the most-missed event. |
| `Top Reason Caption` | text | Caption under the largest non-resolution reason. |
| `Top Reason Share Caption` | text | Caption under the largest reason's share. |
| `Web Device Caption` | text | Subtitle for the web device comparison. |
| `Web Gap Caption` | text | Caption under the web difference card. |
| *(hidden)* `Web Match Colour` | text | Semantic colour for the web device match rate. |
| `Web Share Caption` | text | Caption under Web IDR Resolved. |

### 01 - Executive KPIs

| Measure | Format | Description |
|---|---|---|
| `Active Alerts` | `0` | Number of alert rules at warning or critical on the selected date. |
| `Alert Flag` | text | Escalation state: NO ISSUE, WATCH, ACTION REQUIRED or CRITICAL. |
| `Alert Severity` | text | Overall traffic-light state of the platform: Green healthy, Amber warning, Red critical. |
| `Critical Alerts` | `0` | Number of alert rules at critical on the selected date. |
| `Data Through Label` | text | Header caption stating the business date the page is reporting on. |
| `Date Range Label` | text | Full span of loaded history. |
| `Earliest Business Date` | `dd-mmm-yyyy` | Earliest Event Date available in the source data. |
| `Executive Alert Message` | text | Human-readable headline alert, generated from the highest-priority failing rule. |
| `Health Score Band` | text | Health score banded into HEALTHY / WATCH / DEGRADED / CRITICAL. |
| `Health Score Label` | text | Health score formatted for a card subtitle. |
| `IDR Platform Health Score` | `0` | Weighted 0-100 composite health score across resolution, unresolved trend, reconciliation, volume, overlap and data quality. |
| `Last Refresh` | `dd-mmm-yyyy hh:nn` | Timestamp of the last semantic model refresh (local time of the refreshing machine). |
| `Last Refresh Label` | text | Header caption showing when the model last refreshed. |
| `Latest Business Date` | `dd-mmm-yyyy` | Latest Event Date available in the source data, ignoring all filters. The report is always as-of the data, never as-of the calendar. |
| `Overall IDR Non-Resolution Rate (%)` | `0.00%` | Share of profiles that did not resolve across the selected event dates. |
| `Overall IDR Resolution Rate (%)` | `0.00%` | Overall IDR resolution rate across the selected event dates: resolved / (resolved + not resolved). Formatted as a percentage. |
| `Previous Business Date` | `dd-mmm-yyyy` | Previous date with data before the selected date. Gap-safe: skips missing days rather than returning blanks. |
| `Selected Business Date` | `dd-mmm-yyyy` | The date all executive KPI cards evaluate at. Latest loaded date by default, or the end of the current date selection. |

### 02 - IDR

| Measure | Format | Description |
|---|---|---|
| `App Contribution %` | `0.0%` | App share of successfully resolved identities. |
| `App IDR Resolved` | `#,##0` | Identities resolved through the app channel. |
| `App IDR Resolved (Period)` | `#,##0` | App login at syfid level in CDP, summed over the selected dates. |
| `App Resolution %` | `0.0%` | App-resolved identities as a share of all IDR requests. |
| `App Share of Resolved (%)` | `0.00%` | App as a share of all resolved profiles over the selected dates. |
| `Apps IDR Resolved EDL` | `#,##0` | App-resolved identities as counted on the EDL side. |
| `Apps IDR Resolved EDL (Period)` | `#,##0` | apps_idr_resolved_edl: apps IDR resolved at syfid (profile) level in EDL, summed over the selected dates. The EDL counterpart of App IDR Resolved. |
| `Calculated IDR Resolution Rate` | `0.00%` | Resolution rate recalculated from resolved and unresolved counts. This is the rate every alert is judged against. |
| `IDR Non-Resolution Rate` | `0.0%` | Share of requests that failed to resolve. |
| `IDR Not Resolved` | `#,##0` | Identity-resolution requests that could not be resolved. The primary customer-impact signal. |
| `IDR Not Resolved %` | `0.00%` | Unresolved requests as a share of all requests. |
| `IDR Not Resolved (Period)` | `#,##0` | Profiles where identity did not resolve, summed over the selected dates. |
| `IDR Resolution Rate` | `0.0%` | Share of IDR requests successfully resolved. Alias of the calculated rate, used everywhere in the report. |
| `IDR Resolved` | `#,##0` | Identity-resolution requests successfully resolved. |
| `IDR Resolved (Period)` | `#,##0` | Profiles where identity resolved, summed over the selected dates. |
| `IDR Total Requests` | `#,##0` | Denominator for every resolution ratio: resolved plus unresolved requests. |
| `Profiles Attempted (Period)` | `#,##0` | Resolved plus not resolved: the denominator of the resolution rate. |
| `Source IDR Resolution Rate` | `0.00%` | Volume-weighted average of the resolution rate as published in the source file. Used only to audit the source. |
| `Source vs Calculated Resolution Rate Variance` | `+0.0%;-0.0%;0.0%` | Gap between the published rate and the independently recalculated rate. Beyond tolerance the source percentage cannot be trusted. |
| `Web Contribution %` | `0.0%` | Web share of successfully resolved identities. Reveals channel mix shifts. |
| `Web IDR Resolved` | `#,##0` | Identities resolved through the web channel. |
| `Web IDR Resolved (Period)` | `#,##0` | Web login at syfid level in CDP, summed over the selected dates. |
| `Web IDR Resolved EDL` | `#,##0` | Web-resolved identities as counted on the EDL side. |
| `Web IDR Resolved EDL (Period)` | `#,##0` | web_idr_resolved_edl: web IDR resolved at syfid (profile) level in EDL, summed over the selected dates. The EDL counterpart of Web IDR Resolved. |
| `Web Resolution %` | `0.0%` | Web-resolved identities as a share of all IDR requests. |
| `Web Share of Resolved (%)` | `0.00%` | Web as a share of all resolved profiles over the selected dates. |

### 03 - Reconciliation

| Measure | Format | Description |
|---|---|---|
| `Absolute Total Difference` | `#,##0` | Magnitude of the EDL/Kafka total gap, direction discarded. |
| `Absolute Unique Difference` | `#,##0` | Magnitude of the EDL/Kafka unique gap, direction discarded. |
| `App Level Match Rate (%)` | `0.00%` | CDP app resolved as a share of EDL app resolved, at syfid level. |
| `Difference App EDL vs CDP (Period)` | `+#,##0;-#,##0;0` | apps_idr_resolved_edl minus App_IDR_Resolved over the selected dates. |
| `Difference Total EDL vs Kafka Logins (Period)` | `+#,##0;-#,##0;0` | EDL minus CDP at sessionid level over the selected dates. Positive means EDL recorded more events than CDP. |
| `Difference Unique EDL vs Kafka Logins (Period)` | `+#,##0;-#,##0;0` | EDL minus CDP at syfid (profile) level over the selected dates. |
| `Difference Web EDL vs CDP (Period)` | `+#,##0;-#,##0;0` | web_idr_resolved_edl minus Web_IDR_Resolved over the selected dates. Positive means EDL resolved more web profiles than CDP. |
| `Kafka to EDL Coverage %` | `0.0%` | Kafka volume expressed as a share of EDL volume. Above 100% means Kafka is reporting more than EDL. |
| `Profile Level Match Rate (%)` | `0.00%` | CDP as a share of EDL at syfid (profile) level. |
| `Recon Drift` | `0.0%` | Absolute drift of the total reconciliation rate against its 7-day baseline. |
| `Reconciliation Direction` | text | Plain-language direction of the total reconciliation gap. |
| `Reconciliation Direction Change` | text | Detects a sign flip in the signed EDL/Kafka variance versus the previous day. A move to negative means Kafka now exceeds EDL. |
| `Session Level Match Rate (%)` | `0.00%` | CDP as a share of EDL at sessionid level. 100% means the two platforms agree on event volume. |
| `Source Total Difference` | `+#,##0;-#,##0;0` | Total difference as published in the source file. Audited against the recalculated difference. |
| `Source Unique Difference` | `+#,##0;-#,##0;0` | Unique difference as published in the source file. |
| `Total Difference % of EDL` | `0.0%` | Absolute EDL/Kafka gap as a share of EDL volume. |
| `Total EDL vs Kafka Difference` | `+#,##0;-#,##0;0` | Signed difference: EDL total minus Kafka total. Positive means EDL exceeds Kafka; negative means Kafka exceeds EDL. |
| `Total Reconciliation %` | `0.0%` | How closely Kafka and EDL agree on total volume. Judged by drift against its own baseline, because the standing gap is structural. |
| `Unique EDL vs Kafka Difference` | `+#,##0;-#,##0;0` | Signed difference at identity level: unique EDL minus unique Kafka. |
| `Unique Recon Drift` | `0.0%` | Absolute drift of the unique reconciliation rate against its 7-day baseline. |
| `Unique Reconciliation %` | `0.0%` | How closely Kafka and EDL agree on unique identities. |
| `Unique Reconciliation Direction` | text | Plain-language direction of the unique reconciliation gap. |
| `Unique Reconciliation Direction Change` | text | Sign-flip detection on the unique EDL/Kafka variance. |
| `Web Level Match Rate (%)` | `0.00%` | CDP web resolved as a share of EDL web resolved, at syfid level. |

### 04 - Volume

| Measure | Format | Description |
|---|---|---|
| `Total EDL Logins` | `#,##0` | All login events recorded in EDL. |
| `Total EDL Logins (Period)` | `#,##0` | Total logins at sessionid level in EDL, summed over the selected dates. |
| `Total Kafka Logins Events` | `#,##0` | All login events observed on the Kafka stream. |
| `Total Kafka Logins Events (Period)` | `#,##0` | Total logins at sessionid level in CDP, summed over the selected dates. |
| `Unique EDL Logins` | `#,##0` | Distinct logins recorded in EDL. |
| `Unique EDL Logins (Period)` | `#,##0` | Total logins at syfid (profile) level in EDL, summed over the selected dates. |
| `Unique Kafka Logins` | `#,##0` | Distinct Kafka logins matched at profile level. |
| `Unique Kafka Logins at Profile (Period)` | `#,##0` | Total logins at syfid (profile) level in CDP, summed over the selected dates. |
| `Volume Worst Change %` | `0.0%` | Largest relative volume movement against the 7-day baseline. |
| `Volume Worst Z-Score` | `0.00` | Largest absolute volume z-score across EDL total/unique and Kafka total/unique. |
| `Worst Volume Metric` | text | Which volume stream is furthest from its baseline. |

### 05 - Overlap

| Measure | Format | Description |
|---|---|---|
| `App Only` | `#,##0` | Identities seen only in the app. |
| `Apps and Account` | `#,##0` | Identities seen in both the app and the account system. |
| `Kafka Only` | `#,##0` | Identities seen only on the Kafka stream. |
| `Kafka and Account` | `#,##0` | Identities seen in both Kafka and the account system. |
| `Kafka and Apps` | `#,##0` | Identities seen in both Kafka and the app. |
| `Kafka and Web` | `#,##0` | Identities seen in both Kafka and web. |
| `Non-Resolution Population (Period)` | `#,##0` | Profiles in the partial-match population(s) currently in context, summed over the selected dates. With no segment filter this equals IDR Not Resolved. |
| `Non-Resolution Rank` | `0` | Rank of this reason by profiles affected over the selected dates, largest first. |
| `Non-Resolution Share (%)` | `0.00%` | Share of all non-resolution over the selected dates that this reason accounts for. |
| `Overlap Population` | `#,##0` | Total identities across all eight exclusive and overlap populations. |
| `Overlap Population %` | `0.00%` | Overlap population as a share of unique EDL logins - how much of the identity base sits in an ambiguous state. |
| `Overlap Segment Population` | `#,##0` | Population of the identity segment currently in context. Driven by the unpivoted overlap table. |
| *(hidden)* `Overlap Segment Sev Rank` | `0` | Severity of the identity population in row context, judged on relative and absolute movement together. |
| `Overlap Segment Share %` | `0.0%` | Segment population as a share of the total overlap population for the same day. |
| `Overlap Segments In Breach` | `0` | How many of the eight identity populations are outside their warning tolerance. |
| `Overlap Worst Absolute Change` | `#,##0` | Largest absolute movement in identities across the eight overlap populations. |
| `Overlap Worst Change %` | `0.0%` | Largest material movement of any identity overlap population against its 7-day baseline. |
| `Overlap Worst Z-Score` | `0.00` | Largest absolute z-score across the eight identity overlap populations. |
| `Top Missing Event` | text | The event whose absence accounts for the most non-resolution over the selected dates. |
| `Top Non-Resolution Reason` | text | Name of the partial-match population contributing the most non-resolution over the selected dates. |
| `Top Non-Resolution Reason Share (%)` | `0.00%` | Share of non-resolution attributable to the single largest reason. |
| `Web Only` | `#,##0` | Identities seen only on web. |
| `Web and Account` | `#,##0` | Identities seen in both web and the account system. |
| `Worst Overlap Segment` | text | Name of the identity population moving furthest from its baseline. The first place to look during an overlap anomaly. |

### 06 - Alerts

| Measure | Format | Description |
|---|---|---|
| `Active Critical Signal Count` | `0` | How many alert rules are simultaneously critical on the selected date. |
| `Active Warning Signal Count` | `0` | How many alert rules are simultaneously in warning on the selected date. |
| `Alert Priority Score` | `0` | Ranking score for the executive alert panel. Severity dominates, rule priority breaks ties. |
| `Date Severity` | text | Alert severity of the date in row context, as text. |
| `Date Severity Rank` | `0` | Worst alert severity on the date in row context. |
| *(hidden)* `Overall Severity Rank` | `0` | Worst severity across every alert rule. |
| `Primary Risk Driver` | text | The single highest-priority failing rule. Drives the 'investigate first' guidance. |
| `Rule Baseline` | text | Baseline the alert rule is judged against. |
| `Rule Change` | text | Movement that triggered the alert rule. |
| `Rule Current Value` | text | Headline value for the alert rule in row context. |
| `Rule Message` | text | Plain-language business interpretation of the alert rule in row context. |
| `Rule Severity` | text | Severity of the alert rule in row context, as text. |
| *(hidden)* `Rule Severity Colour` | text | Semantic colour for the alert rule in row context. |
| `Rule Severity Rank` | `0` | Severity rank of the alert rule in row context: 0 no data, 1 healthy, 2 warning, 3 critical. |
| `Selected Metric Severity` | text | Severity of the alert rule governing the selected metric. |
| *(hidden)* `Selected Metric Severity Rank` | `0` | Severity rank of the alert rule governing the selected metric. |
| *(hidden)* `Sev Rank Compound` | `0` | Rule 7 severity: escalation when several independent signals fail on the same date. |
| *(hidden)* `Sev Rank Data Quality` | `0` | Rule 8 severity: number of data-quality defects detected in the loaded data. |
| *(hidden)* `Sev Rank Direction` | `0` | Rule 4 severity: reconciliation direction reversal. Critical whenever Kafka exceeds EDL. |
| *(hidden)* `Sev Rank IDR Not Resolved` | `0` | Rule 2 severity: unresolved IDR volume against baseline growth, an absolute ceiling and a z-score. |
| *(hidden)* `Sev Rank IDR Resolution` | `0` | Rule 1 severity: IDR resolution rate against its absolute thresholds and against day-on-day and baseline drops. |
| *(hidden)* `Sev Rank Overlap` | `0` | Rule 5 severity: anomalous movement in any identity overlap population. |
| *(hidden)* `Sev Rank Reconciliation` | `0` | Rule 3 severity: EDL/Kafka reconciliation drift against baseline, plus an absolute gap check. |
| *(hidden)* `Sev Rank Source Rate Variance` | `0` | Rule 9 severity: disagreement between the published and recalculated resolution rate. |
| *(hidden)* `Sev Rank Volume` | `0` | Rule 6 severity: volume movement outside the recent noise band and materially large. |

### 07 - Data Quality

| Measure | Format | Description |
|---|---|---|
| `DQ Check Count` | `0` | Number of rows failing the data-quality check in row context. |
| `DQ Check Status` | text | Verdict for the data-quality check in row context. |
| `DQ Date Issue Count` | `0` | Structural defects on the date in row context. |
| `DQ Date Issue List` | text | Named list of the data-quality defects found on the date in row context. |
| `DQ Date Status` | text | Data-quality verdict for the date in row context. |
| `DQ Distinct Dates` | `#,##0` | Distinct Event Dates loaded. |
| `DQ Duplicate Date Count` | `0` | Rows in excess of one per Event Date. Anything above zero breaks the daily grain. |
| `DQ IDR Consistency Breaches` | `0` | Dates where Web plus App resolved does not equal total IDR Resolved. |
| `DQ Missing Day Count` | `0` | Days inside the loaded date range that have no data at all. |
| `DQ Missing Event Date` | `0` | Rows with no Event Date. Such rows cannot be placed on any trend. |
| `DQ Negative Value Count` | `0` | Rows with a negative value in a column that can only be a count. |
| `DQ Null Value Count` | `0` | Rows containing at least one null in a column that must always be populated. |
| `DQ Rate Variance Breaches` | `0` | Dates where the published resolution rate differs from the recalculated rate by more than tolerance. |
| `DQ Reconciliation Consistency Breaches` | `0` | Dates where the published EDL/Kafka difference disagrees with the difference recomputed from the volume columns. |
| `DQ Row Count` | `#,##0` | Rows loaded from the source file. |
| `DQ Unexpected Overlap Movement Count` | `0` | Dates where an identity overlap population moved beyond the critical tolerance. |
| `DQ Unexpected Resolution Movement Count` | `0` | Dates whose resolution rate fell below the critical threshold. |
| `DQ Unexpected Resolution Rate Count` | `0` | Dates where the published resolution rate falls outside 0-100%. |
| `DQ Unexpected Volume Movement Count` | `0` | Dates whose login volumes moved beyond the critical z-score tolerance. |
| `DQ_Status` | text | Alias of Data Quality Status. |
| `Data Quality Issue Count` | `0` | Total structural data-quality defects across the loaded data. |
| `Data Quality Issue Count (Selected Date)` | `0` | Structural data-quality defects on the selected business date. |
| `Data Quality Label` | text | Header caption for data-quality state. |
| `Data Quality Status` | text | Overall data-quality verdict: Healthy, Warning or Critical. |
| `Source vs Calculated Resolution Rate Variance (Selected Date)` | `+0.0%;-0.0%;0.0%` | Gap between the published and the recalculated resolution rate on the selected business date. |

### 08 - Trend Intelligence

345 measures: the trend pattern above applied to each of the 18 headline metrics. Not listed individually.

### 09 - Configuration

| Measure | Format | Description |
|---|---|---|
| *(hidden)* `Baseline Day Count` | `0` | Number of days with data inside the 7-day baseline window. Gates every z-score and drift rule. |
| `Critical Resolution Rate` | `0.0%` | Critical reference line for the resolution trend chart. |
| *(hidden)* `THR Crit DATA_QUALITY` | text | Crit threshold for DATA_QUALITY, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit IDR_NOT_RESOLVED_ABS` | text | Crit threshold for IDR_NOT_RESOLVED_ABS, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit IDR_NOT_RESOLVED_VS_BASELINE` | text | Crit threshold for IDR_NOT_RESOLVED_VS_BASELINE, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit IDR_NOT_RESOLVED_ZSCORE` | text | Crit threshold for IDR_NOT_RESOLVED_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit IDR_RESOLUTION_RATE` | text | Crit threshold for IDR_RESOLUTION_RATE, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit IDR_RESOLUTION_RATE_DROP` | text | Crit threshold for IDR_RESOLUTION_RATE_DROP, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit MIN_BASELINE_DAYS` | text | Crit threshold for MIN_BASELINE_DAYS, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit MIN_DRIFT_BASELINE_DAYS` | text | Crit threshold for MIN_DRIFT_BASELINE_DAYS, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit OVERLAP_CHANGE_PCT` | text | Crit threshold for OVERLAP_CHANGE_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit OVERLAP_MIN_ABS_CHANGE` | text | Crit threshold for OVERLAP_MIN_ABS_CHANGE, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit OVERLAP_ZSCORE` | text | Crit threshold for OVERLAP_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit RECON_DIRECTION` | text | Crit threshold for RECON_DIRECTION, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit RECON_DRIFT_PP` | text | Crit threshold for RECON_DRIFT_PP, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit RECON_GAP_PCT` | text | Crit threshold for RECON_GAP_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit SOURCE_VS_CALC_RATE` | text | Crit threshold for SOURCE_VS_CALC_RATE, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit VOLUME_MIN_CHANGE_PCT` | text | Crit threshold for VOLUME_MIN_CHANGE_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Crit VOLUME_ZSCORE` | text | Crit threshold for VOLUME_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn DATA_QUALITY` | text | Warn threshold for DATA_QUALITY, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn IDR_NOT_RESOLVED_ABS` | text | Warn threshold for IDR_NOT_RESOLVED_ABS, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn IDR_NOT_RESOLVED_VS_BASELINE` | text | Warn threshold for IDR_NOT_RESOLVED_VS_BASELINE, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn IDR_NOT_RESOLVED_ZSCORE` | text | Warn threshold for IDR_NOT_RESOLVED_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn IDR_RESOLUTION_RATE` | text | Warn threshold for IDR_RESOLUTION_RATE, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn IDR_RESOLUTION_RATE_DROP` | text | Warn threshold for IDR_RESOLUTION_RATE_DROP, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn MIN_BASELINE_DAYS` | text | Warn threshold for MIN_BASELINE_DAYS, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn MIN_DRIFT_BASELINE_DAYS` | text | Warn threshold for MIN_DRIFT_BASELINE_DAYS, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn OVERLAP_CHANGE_PCT` | text | Warn threshold for OVERLAP_CHANGE_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn OVERLAP_MIN_ABS_CHANGE` | text | Warn threshold for OVERLAP_MIN_ABS_CHANGE, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn OVERLAP_ZSCORE` | text | Warn threshold for OVERLAP_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn RECON_DIRECTION` | text | Warn threshold for RECON_DIRECTION, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn RECON_DRIFT_PP` | text | Warn threshold for RECON_DRIFT_PP, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn RECON_GAP_PCT` | text | Warn threshold for RECON_GAP_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn SOURCE_VS_CALC_RATE` | text | Warn threshold for SOURCE_VS_CALC_RATE, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn VOLUME_MIN_CHANGE_PCT` | text | Warn threshold for VOLUME_MIN_CHANGE_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Warn VOLUME_ZSCORE` | text | Warn threshold for VOLUME_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight DATA_QUALITY` | text | Weight threshold for DATA_QUALITY, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight IDR_NOT_RESOLVED_ABS` | text | Weight threshold for IDR_NOT_RESOLVED_ABS, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight IDR_NOT_RESOLVED_VS_BASELINE` | text | Weight threshold for IDR_NOT_RESOLVED_VS_BASELINE, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight IDR_NOT_RESOLVED_ZSCORE` | text | Weight threshold for IDR_NOT_RESOLVED_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight IDR_RESOLUTION_RATE` | text | Weight threshold for IDR_RESOLUTION_RATE, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight IDR_RESOLUTION_RATE_DROP` | text | Weight threshold for IDR_RESOLUTION_RATE_DROP, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight MIN_BASELINE_DAYS` | text | Weight threshold for MIN_BASELINE_DAYS, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight MIN_DRIFT_BASELINE_DAYS` | text | Weight threshold for MIN_DRIFT_BASELINE_DAYS, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight OVERLAP_CHANGE_PCT` | text | Weight threshold for OVERLAP_CHANGE_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight OVERLAP_MIN_ABS_CHANGE` | text | Weight threshold for OVERLAP_MIN_ABS_CHANGE, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight OVERLAP_ZSCORE` | text | Weight threshold for OVERLAP_ZSCORE, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight RECON_DIRECTION` | text | Weight threshold for RECON_DIRECTION, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight RECON_DRIFT_PP` | text | Weight threshold for RECON_DRIFT_PP, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight RECON_GAP_PCT` | text | Weight threshold for RECON_GAP_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight SOURCE_VS_CALC_RATE` | text | Weight threshold for SOURCE_VS_CALC_RATE, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight VOLUME_MIN_CHANGE_PCT` | text | Weight threshold for VOLUME_MIN_CHANGE_PCT, read from data/Thresholds.csv. |
| *(hidden)* `THR Weight VOLUME_ZSCORE` | text | Weight threshold for VOLUME_ZSCORE, read from data/Thresholds.csv. |
| `Target Resolution Rate` | `0.0%` | Target line for the resolution trend chart, set one point above the warning threshold. |
| *(hidden)* `Timeframe Filter` | `0` | Returns 1 when a date falls inside the selected timeframe window. Applied as a visual filter on the Historical Trends page. |
| `Warning Resolution Rate` | `0.0%` | Warning reference line for the resolution trend chart. |
| `Zero Reference Line` | `#,##0` | Zero line for the signed variance chart. Above the line EDL exceeds Kafka; below it Kafka exceeds EDL. |

### 10 - Health Score

| Measure | Format | Description |
|---|---|---|
| `Health Component Data Quality` | `0` | 0-100 score for data quality of the loaded data. |
| `Health Component IDR Not Resolved Trend` | `0` | 0-100 score for the trend in unresolved IDR volume. |
| `Health Component IDR Resolution` | `0` | 0-100 score for IDR resolution health. |
| `Health Component Overlap Stability` | `0` | 0-100 score for stability of the identity overlap populations. |
| `Health Component Reconciliation` | `0` | 0-100 score for EDL/Kafka reconciliation. Collapses to zero on a direction reversal. |
| `Health Component Volume Stability` | `0` | 0-100 score for volume stability against the rolling baseline. |

### 11 - Narrative

| Measure | Format | Description |
|---|---|---|
| `Abnormality Summary` | text | Root Cause Explorer: how abnormal the selected date is against three different baselines. |
| `Current Risk Summary` | text | What is at risk right now and what to investigate first. |
| `Executive Summary Text` | text | Dynamic executive narrative: what changed, how large, improving or deteriorating, and what is driving the risk. |
| `Trend Summary` | text | One-line direction of travel across the four headline metrics. |
| `What Changed Summary` | text | Root Cause Explorer: what moved on the selected date. |
| `Why Flagged Explanation` | text | Root Cause Explorer: the reasons the selected date is flagged, generated from the firing rules. |

### 12 - Report UX

| Measure | Format | Description |
|---|---|---|
| *(hidden)* `Alert Severity Colour` | text | Semantic colour for the overall platform state. |
| `Card Caption Active Alerts` | text | Caption for the active alerts card. |
| `Card Caption EDL Logins` | text | Caption for the EDL login volume card. |
| `Card Caption Health Score` | text | Caption for the platform health score card. |
| `Card Caption Kafka Events` | text | Caption for the Kafka login event volume card. |
| `Card Caption Not Resolved` | text | Caption for the IDR Not Resolved executive card. |
| `Card Caption Resolution` | text | Caption for the IDR Resolution Rate executive card. |
| `Card Caption Total Variance` | text | Caption for the total EDL vs Kafka variance card. |
| `Card Caption Unique Variance` | text | Caption for the unique EDL vs Kafka variance card. |
| *(hidden)* `Colour IDR Not Resolved` | text | Semantic colour for the unresolved IDR card. |
| *(hidden)* `Colour IDR Resolution` | text | Semantic colour for the resolution rate card. |
| *(hidden)* `Colour Reconciliation` | text | Semantic colour for the reconciliation variance cards. |
| *(hidden)* `Colour Volume` | text | Semantic colour for the volume cards. |
| *(hidden)* `DQ Check Colour` | text | Semantic colour for the data-quality check in row context. |
| *(hidden)* `DQ Date Status Colour` | text | Semantic colour for the per-date data-quality verdict. |
| *(hidden)* `Data Quality Colour` | text | Semantic colour for the data-quality verdict. |
| *(hidden)* `Date Severity Colour` | text | Semantic colour for the date in row context. |
| `Exec Header Subtitle` | text | Executive page subtitle. |
| `Exec Header Title` | text | Static executive page title, held as a measure so it can be themed centrally. |
| `Exec Status Banner` | text | Single-line status banner combining escalation state, business date and data quality. |
| *(hidden)* `Health Score Colour` | text | Semantic colour for the health score. |
| `Overlap Title` | text | Dynamic title for the overlap composition chart. |
| `Reconciliation Trend Title` | text | Dynamic title for the signed variance trend chart. |
| `Resolution Trend Title` | text | Dynamic title for the executive resolution trend chart. |
| `Root Cause Title` | text | Dynamic title for the Root Cause Explorer page. |
| `Scorecard Change` | text | Movement for the scorecard row in context. |
| *(hidden)* `Scorecard Colour` | text | Semantic colour for the scorecard row in context. |
| *(hidden)* `Scorecard Severity Rank` | `0` | Severity rank for the scorecard row in context. |
| `Scorecard Status` | text | Status for the scorecard row in context. |
| `Scorecard Target` | text | Target for the scorecard row in context. |
| `Scorecard Trend` | text | Direction of travel for the scorecard row in context. |
| `Scorecard Value` | text | Current value for the scorecard row in context. |
| *(hidden)* `Selected Metric Colour` | text | Semantic colour for the selected metric. |
| `Watchlist Title` | text | Dynamic title for the unresolved watchlist. |

## 9. Disconnected selector contents

**Dim_Scorecard**

| Key | Metric | Order |
|---|---|---|
| `RESOLUTION` | IDR Resolution Rate | 1 |
| `NON_RESOLUTION` | IDR Non-Resolution Rate | 2 |
| `RECON_TOTAL` | EDL / Kafka Reconciliation | 3 |
| `RECON_UNIQUE` | Unique Reconciliation | 4 |
| `WEB_RES` | Web Resolution | 5 |
| `APP_RES` | App Resolution | 6 |
| `DATA_QUALITY` | Data Quality | 7 |
| `ACTIVE_ALERTS` | Active Alerts | 8 |

**Dim_Timeframe** — windows are measured back from `[Latest Business Date]`, never from `TODAY()`.

| Timeframe | Days | Order |
|---|---:|---:|
| Last 7 Days | 7 | 1 |
| Last 30 Days | 30 | 2 |
| Last 90 Days | 90 | 3 |
| Last 6 Months | 182 | 4 |
| Last 12 Months | 365 | 5 |
| All History | all | 6 |

