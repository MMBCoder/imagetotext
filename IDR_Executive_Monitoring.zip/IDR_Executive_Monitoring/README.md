# IDR Executive Monitoring

A daily dashboard comparing **EDL against CDP** login volume and explaining
**IDR resolution** on the CDP side, built as a **Power BI Project (PBIP)** with
a TMDL semantic model.

The workbook calls the CDP side "Kafka", so the field names on the report do
too - every figure traces back to a column in `idr_kafka_edl.xlsx`.

Two levels of comparison, and they are not interchangeable:

| Level | Means | Fields |
|---|---|---|
| **sessionid** | every login event | `Total EDL Logins` vs `Total Kafka Logins Events` |
| **syfid (profile)** | one row per profile | `Unique EDL Logins` vs `Unique Kafka Logins at Profile` |

A profile resolves when CDP holds **(web or app) + kafka + account**. The eight
partial-match populations in the file are the profiles that carried only part of
that evidence - and they sum *exactly* to `IDR_Not_Resolved` on every loaded
row, which is what lets the report say **why** resolution failed rather than
just how often.

---

## Quick start

1. Open **`IDR_Executive_Monitoring.pbip`** in Power BI Desktop
   (a 2024 build or later; on older builds enable
   *File → Options → Preview features → Power BI Project (.pbip) save option*).
2. Press **Home → Refresh** once. A `.pbip` stores no data, so the model opens
   empty and every visual reads "No data" until the first refresh.
3. To produce a `.pbix`: **File → Save as → Power BI file (.pbix)**. The `.pbix`
   embeds the data, so it opens populated without a refresh.

### Report format

The report ships as **`IDR_Executive_Monitoring.Report/report.json`**, the
legacy PBIP report format, and *not* as a PBIR `definition/` folder.

This is deliberate and was established by testing rather than assumed. Power BI
Desktop 2.157 (August 2026) ignores a PBIR `definition/` folder inside a PBIP:
it loads the semantic model, shows no page tabs and leaves the canvas blank,
with no error. Saving the project from Desktop confirms the direction - Desktop
deletes `definition/` and writes `report.json`.

PBIR is still the authoring format because one file per visual is far easier to
generate and validate. `tools/pbir_to_legacy.py` lowers it to the format
Desktop reads, and the PBIR tree is staged under `build/pbir/` where the
structural validator checks it.

If the data lives somewhere else, change the parameters rather than the queries:
**Transform data → Edit parameters**. Moving the file to another machine is
covered step by step in [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md) - the short
version is that a `.pbix` opens anywhere with no changes, and only *refreshing*
needs the source folder repointed.

| Parameter | Default | Purpose |
|---|---|---|
| `ProjectDataFolder` | `<project>\data` | Folder holding the workbook and the two configuration CSVs |
| `SourceWorkbookName` | `idr_kafka_edl.xlsx` | Workbook file name |
| `SourceSheetName` | `idr` | Worksheet name; falls back to the first sheet if not found |

---

## Architecture

```
IDR_Executive_Monitoring.pbip              entry point
IDR_Executive_Monitoring.SemanticModel/    TMDL model  - 13 tables, 623 measures
  definition/
    model.tmdl  database.tmdl  relationships.tmdl  expressions.tmdl
    tables/*.tmdl        one file per table
    roles/Viewer.tmdl
IDR_Executive_Monitoring.Report/           legacy PBIP report - 7 pages, 128 visuals
  definition.pbir            dataset reference (no $schema - as Desktop writes it)
  report.json                the whole report: config + sections + visualContainers
  StaticResources/RegisteredResources/IDRCommandCenter.json    theme
build/pbir/                  PBIR staging, gitignored, validated but not shipped
data/
  idr_kafka_edl.xlsx        source of truth
  Thresholds.csv            every alert threshold and health weight
  MetricDefinitions.csv     business glossary
docs/
  DATA_DICTIONARY.md        generated from the model
  VALIDATION_REPORT.md      generated from the data
tools/                      generators and validators
```

### Data model

A star schema. `Dim_Date` is the only date axis in the report; the raw
`Event Date` column is hidden so nothing can accidentally trend on it.

```
Dim_Date[Date]  1 ──< Fact_IDR_Daily[Event Date]        daily snapshot
                1 ──< Fact_Overlap_Daily[Event Date]    identity populations, unpivoted
```

Everything else is **disconnected** on purpose — `Dim_Thresholds`,
`Dim_Alert_Rules`, `Dim_Scorecard`, `Dim_Timeframe`, `Dim_Metric_Watch`,
`Dim_DQ_Checks`. Each drives a `SWITCH` in the measure layer instead of
filtering the fact table. That is what lets one table visual render nine alert
rules, or eighteen metrics side by side, without nine or eighteen visuals.

`Fact_Overlap_Daily` unpivots the eight partial-match populations to one row per
date and segment, and carries a `Missing Event` column saying which leg was
absent. Because the eight sum exactly to `IDR_Not_Resolved`, one ranking measure
answers "which reason is driving non-resolution?" instead of eight parallel ones,
and grouping by `Missing Event` turns that into an instruction.

`Dim_Date` is generated as `CALENDAR(MIN(Event Date), MAX(Event Date))`, so the
calendar spans exactly the loaded data and extends itself as history is appended.

All raw fact columns are hidden. `discourageImplicitMeasures` is set: the
623 explicit measures are the only analytical surface.

### Measure layer

| Folder | Count | Contents |
|---|---:|---|
| 00 - Selected Period | 26 | Period sums, the headline rate, card captions and colours |
| 01 - Executive KPIs | 18 | As-of dates, health score, alert flag, header captions |
| 02 - IDR | 26 | Resolution, channels, source-vs-calculated audit |
| 03 - Reconciliation | 20 | Signed and absolute variance, agreement rates, direction |
| 04 - Volume | 11 | EDL and CDP totals and uniques |
| 05 - Overlap | 24 | Eight populations, share of non-resolution, ranking |
| 06 - Alerts | 25 | Nine rules: severity, value, baseline, change, message |
| 07 - Data Quality | 25 | Twelve checks, dataset-wide and per-date |
| 08 - Trend Intelligence | 345 | The standard pattern applied to 18 headline metrics |
| 09 - Configuration | 57 | Threshold lookups, baseline sufficiency, timeframe |
| 10 - Health Score | 6 | Six weighted components |
| 11 - Narrative | 6 | Dynamic executive prose |
| 12 - Report UX | 34 | Dynamic titles, captions, semantic colours |

Full listing in [`docs/DATA_DICTIONARY.md`](docs/DATA_DICTIONARY.md).

---

## The as-of rule

Nothing in this report uses `TODAY()`.

```
Latest Business Date   = MAX(Event Date) ignoring all filters
Selected Business Date = MIN( MAX(Dim_Date[Date]) in context, Latest Business Date )
Previous Business Date = the previous date that actually has data
```

Every executive card evaluates at `Selected Business Date`. With no date
selection that is the latest loaded date; select a historical date and the whole
page rewinds to it. `Previous Business Date` skips gaps rather than returning
blanks, so a missing day in the feed does not silently produce a blank delta.

---

## Alert engine

Nine rules, each with its own severity measure. Severity ranks are
`0` no data, `1` healthy, `2` warning, `3` critical.

| Rule | Fires when |
|---|---|
| **R01** Resolution rate breach | Rate below its absolute threshold, **or** falling materially against yesterday, **or** against the 7-day baseline |
| **R02** Unresolved spike | Growth against baseline, **or** an absolute ceiling, **or** a z-score |
| **R03** Reconciliation drift | Agreement rate drifting against its own baseline, on total or unique |
| **R04** Direction reversal | Signed variance changes sign. Kafka exceeding EDL is critical |
| **R05** Overlap anomaly | A population moves materially in **both** relative and absolute terms |
| **R06** Volume anomaly | A z-score **and** a materially large relative move |
| **R07** Compound incident | Two criticals, or one critical with two warnings, or three warnings |
| **R08** Data quality | Structural defects **on the selected date** |
| **R09** Source vs calculated | The published rate disagrees with the recalculated rate. Inert while the source column ships empty, which it currently does |

`Alert Priority Score = rank x 1000 + (100 - priority)`, so severity always
dominates and rule priority only breaks ties within a severity. The executive
alert panel is filtered to `>= 2000` (warning or worse) and sorted by that score,
so the most consequential issue is the first line an executive reads.

### Why the rules are shaped this way

Three things were tuned after watching the engine run against the sample, and
they matter more than the thresholds:

- **Z-scores refuse to fire on a thin baseline.** A standard deviation computed
  on two observations is meaninglessly small, and every ordinary move reads as a
  five-sigma event. `MIN_BASELINE_DAYS` (7) covers a full weekly cycle, so the
  normal weekend volume drop sits *inside* the baseline instead of being reported
  as an incident.
- **Percentage moves need an absolute floor.** Several identity populations hold
  single-digit counts. Without `OVERLAP_MIN_ABS_CHANGE`, a population going from
  1 to 2 registers as a 100% spike and the overlap rule fires every day.
- **Data quality is not a platform incident.** R08 is scoped to the selected
  date, and R08/R09 are excluded from the compound rule. Otherwise one bad date
  anywhere in the file marks every date as a multi-signal incident.

Before these guards the engine flagged 12 of 15 dates as compound incidents.
After them it flags 4 — the four that are genuinely broken.

---

## Health score

`IDR Platform Health Score` is 0-100, a weighted mean of six components.

| Component | Weight | Scored on |
|---|---:|---|
| IDR resolution | 30 | Rate against its thresholds |
| Unresolved trend | 20 | Growth against the 7-day baseline |
| Reconciliation | 20 | Drift against baseline; **collapses to 0 on a direction reversal** |
| Volume stability | 10 | Worst volume z-score |
| Overlap stability | 10 | Worst material population move |
| Data quality | 10 | Structural defects on the date |

Each component scores 100 at or better than its warning threshold, 50 at
critical, and 0 one full band beyond critical, clamped and linear between.
A component with no usable baseline yet is excluded from **both** numerator and
denominator rather than scored as perfect.

Bands: `85+` HEALTHY, `65-84` WATCH, `40-64` DEGRADED, below `40` CRITICAL.

---

## Changing thresholds

Edit **`data/Thresholds.csv`** and refresh. No DAX change is required.

| Column | Meaning |
|---|---|
| `Metric Key` | Stable key the DAX looks up. **Do not rename.** |
| `Warning Threshold` / `Critical Threshold` | Where the metric enters each state |
| `Direction` | Whether higher or lower is worse |
| `Weight` | Contribution to the health score. `0` = alerts but does not score |
| `Unit`, `Description` | Documentation, surfaced on the Data Quality page |

The seventeen rows are listed in the data dictionary. Health-score weights sum
to 100 across the six scored components; if you change them, keep that true or
the score changes meaning.

**Retune these before trusting the report on your own data.** Two are seeded
from the observed October 2025 regime and are not universal:
`RECON_GAP_PCT` (the standing EDL/Kafka gap is structural, around 24% here) and
`IDR_NOT_RESOLVED_ABS` (an absolute ceiling that scales with platform size).

---

## Report pages

Everything responds to one **event date range slicer** - a Between slicer with a
drag slider, synced across pages - so "the selected period" means the same thing
everywhere. The slicer container is deliberately tall: Power BI silently drops
the slider track when the visual is too short for it.

| # | Page | Answers |
|---|---|---|
| 1 | **Overview** | What happened over the dates I selected? |
| 2 | **EDL vs CDP Volume** | Do the two platforms agree - at session, profile and device level? |
| 3 | **IDR Resolution** | How much resolved, and is it web or app driven? |
| 4 | **Why Resolution Failed** | Which missing event is costing us the most? |
| 5 | **Daily Detail** | Every source field, one row per `Event_date` |
| 6 | **Alerts & Data Quality** | What to investigate, and can I trust the data? |
| 7 | **Definitions** | The source data dictionary |

### The headline rate

`Overall IDR Resolution Rate (%)` follows the workbook dictionary exactly:

```
sum(_IDR_Resolved) / sum(_IDR_Resolved + IDR_Not_Resolved)
```

over the event dates selected in the filter. It is **volume weighted** across
the whole range rather than an average of daily rates - the two differ whenever
daily volume varies, and only the weighted one answers "how did we do over this
period". The card states the formula underneath the number so nobody has to
guess.

The source column `Overall Idr Resolution Rate (%)` ships **empty** by design;
the dictionary says the rate should be calculated over the selected range. The
model reads the column but never uses it.

### Four grains of the same comparison

EDL vs CDP is asked at four grains on one page, so the eye can scan across and
see which grain diverges:

| Grain | EDL side | CDP side |
|---|---|---|
| sessionid | `Total EDL Logins` | `Total Kafka Logins Events` |
| syfid (profile) | `Unique EDL Logins` | `Unique Kafka Logins at Profile` |
| web device | `web_idr_resolved_edl` | `Web_IDR_Resolved` |
| app device | `apps_idr_resolved_edl` | `App_IDR_Resolved` |

The device rows are a like-for-like pair because `*_idr_resolved_edl` is *"idr
resolved at syfid level in **EDL**"* - the same measurement, at the same grain,
on the other platform. On the loaded sample web matches at **79.4%** and app at
**92.4%**, so the loss between the platforms is markedly worse on web.

> The workbook's `dictionary` tab still describes these two as "in CDP". The
> corrected wording is applied through `OVERRIDES` in
> `tools/gen_metric_definitions.py`; delete those entries once the workbook
> itself carries it, and the generator will go back to reading it verbatim.

### Why resolution failed

The eight partial-match populations are unpivoted to one row per date and
reason, then grouped two ways:

- **by reason** - the evidence the profile did carry (`Kafka_and_Web`, ...)
- **by missing event** - the leg that was absent, which is the actionable view

On the loaded sample, `Kafka_and_Web` (54.0%) and `Kafka_and_Account` (41.3%)
are 95% of all non-resolution, and grouping by missing event says the **Account**
event alone accounts for 55.5%.

### Built for 7+ months of daily data

The sample is 15 days; the real feed is months of daily rows. So:

- the date slicer is a **range**, and every headline number is a period sum
- rate and volume trends stay **daily** - a line handles 200+ points fine
- the stacked reason trend is **weekly**, because 200+ stacked columns is not
  readable at any size
- month, week and ISO-week keys already exist on `Dim_Date` for regrouping

### Readability

Deliberately constrained, after a first build that clipped its own text: at most
about twenty containers per page, 10pt body, 12pt panel titles, 30pt KPI values,
word wrap on every card and table, and one grid so nothing overlaps.

---

## Design

A dark operational command centre, not a generic Power BI page.

| Role | Colour | Used for |
|---|---|---|
| Critical | `#FF4D5E` | Action required |
| Warning | `#F5A623` | Watch |
| Healthy | `#24C38E` | On target |
| Informational | `#3E8BFF` `#22C7DE` `#8B7CF6` | Series identity only |
| Surfaces | `#0A0E17` `#131A26` `#223049` | Page, card, border |

Every colour carries state. Severity colours come from measures, never from
static formatting, so a card cannot show green while its rule is critical.

---

## Regenerating

The whole project is generated, so it is reproducible and reviews cleanly.
Lineage tags are UUID5 values derived from object names, which means re-running
produces byte-identical output rather than a diff full of new GUIDs.

```bash
python tools/build.py          # regenerate everything, then validate
```

Or individually:

| Command | Does |
|---|---|
| `python tools/gen_semantic_model.py` | Writes the TMDL model |
| `python tools/gen_report.py` | Writes the PBIR report and theme |
| `python tools/gen_docs.py` | Writes `docs/DATA_DICTIONARY.md` from the model |
| `python tools/gen_metric_definitions.py` | Writes `data/MetricDefinitions.csv` |
| `python tools/validate_project.py` | Schema, reference and layout validation |
| `python tools/validate_data.py` | Reimplements the DAX in Python and runs the acceptance tests |
| `powershell -ExecutionPolicy Bypass -File tools\verify_live_model.ps1` | With the project open in Desktop: validates the model against the **real engine** |

`verify_live_model.ps1` connects to the Analysis Services workspace instance
Power BI Desktop runs, checks every measure and partition for load errors,
evaluates the measures the report depends on, and cross-checks the results
against `docs/validation_summary.json`. It is the only check that exercises
actual DAX rather than a reimplementation of it.

Requires `openpyxl`, `jsonschema`, `referencing`.

### Validation

`validate_project.py` checks three layers:

1. **Schema** — every report JSON file against the official Microsoft PBIR
   schemas, vendored in `tools/schemas/`.
2. **References** — every measure and column the report binds to exists in the
   TMDL; every navigation target, tooltip page and bookmark resolves.
3. **Layout** — no visual falls outside its page, no two content visuals overlap.

`validate_data.py` reimplements the model's DAX in Python against the same
workbook and the same `Thresholds.csv`, then asserts the acceptance tests and
writes [`docs/VALIDATION_REPORT.md`](docs/VALIDATION_REPORT.md). All 15 tests
pass on the supplied sample, including the five expected signals — which are
detected by the rules, not encoded anywhere.

---

## Known limitations

- **Verified by opening it, not only by schema validation.** The project has
  been opened in Power BI Desktop 2.157.879.0 (August 2026): all ten pages
  render, the model loads with 13 tables and 571 measures and no measure or
  partition errors, and every headline measure evaluated on the live Analysis
  Services engine matches `tools/validate_data.py` exactly. Run
  `tools/verify_live_model.ps1` with the project open to reproduce that.

  Three defects only a real open could have found, all fixed:

  | Symptom | Cause |
  |---|---|
  | `UnrecognizedSchemaVersion` on the `.pbip` | An invented `$schema` URL. Desktop writes the `.pbip` and `definition.pbir` with **no** `$schema`, which is what the generator now does. |
  | Blank canvas, no page tabs, no error | Desktop ignores a PBIR `definition/` folder in a PBIP. The report is now emitted in the legacy `report.json` format — see *Report format* above. |
  | `Cannot read properties of undefined (reading 'visualContainers')` | A slicer with `orientation: horizontal`. Bisecting the report narrowed it to that one visual; it is now vertical, matching the slicers that render correctly. |

- **Visual-level filters on a measure do not survive the legacy format.** They
  are evaluated outside the visual's row context and silently empty the whole
  visual, so the two places that needed one apply the condition in DAX instead:
  the alert rule measures are blank unless the rule is firing, and the
  `Selected Metric` family is blank outside the chosen timeframe window. Both
  make Power BI drop the unwanted rows by itself.
- **Fifteen days of history.** Rolling baselines need seven days before z-score
  rules engage, so the first six loaded dates cannot raise a volume or overlap
  anomaly. This is deliberate, and visible as `-` in the rule matrix.
- **`RECON_GAP_PCT` and `IDR_NOT_RESOLVED_ABS` are seeded from the sample.**
  Retune them for your own volumes.
- **No dimensions beyond date exist in the source.** There is no channel,
  region, tenant or device table because the file contains none. The model is
  a star schema so they can be added as dimensions against `Fact_IDR_Daily`
  without reworking the measure layer.
- **The published resolution rate is unreliable.** On 27-Oct-2025 the source
  says 98.00% where the counts give 99.56%. The model uses the recalculated
  rate everywhere and raises R09 rather than trusting either number silently.
- **Data quality flags, it does not fix.** No inconsistent value is corrected
  anywhere in the model.
- **ISO week labels** use the calendar year, so the first days of January can
  carry the previous ISO year's week number. Irrelevant for daily operations,
  worth knowing if you aggregate by `Year-Week` across a year boundary.
- **Cloud-synced folders** (this project sits under OneDrive) occasionally lock
  a directory mid-write. The generators retry and fall back to emptying folders
  in place; if a run still fails, close anything holding the folder and re-run.

---

## What the sample data shows

Loaded window: **20-Oct-2025 to 03-Nov-2025**, 15 daily rows, no gaps.

A platform in good health for eleven days, then a step change on 31-Oct that has
not recovered:

| | 20-Oct | 03-Nov |
|---|---:|---:|
| IDR resolution rate | 99.59% | 95.18% |
| IDR not resolved | 3,738 | 69,494 |
| Signed EDL − Kafka variance | +341,595 | +58,553 |
| Platform health score | 100 | 26 |

- **26-Oct** — an isolated precursor: `Kafka and Account` blips to 6x its
  baseline for one day, then clears. Flagged ACTION REQUIRED.
- **31-Oct** — onset. Resolution falls 2.5 points in a day, unresolved IDRs go
  up 8x, `Kafka and Account` jumps from ~700 to 19,802, and reconciliation drifts
  12.8 points. Five rules critical simultaneously: **MULTI-SIGNAL INCIDENT**.
- **01-Nov** — the signed variance goes **negative** on both total and unique.
  Kafka is now reporting more logins than EDL. Control breach.
- **02-Nov to 03-Nov** — variance returns positive but resolution stays at 95%
  and unresolved IDRs keep climbing. Not recovering.

The engine reaches all of this from the data. Nothing about these dates is
written into the model.
