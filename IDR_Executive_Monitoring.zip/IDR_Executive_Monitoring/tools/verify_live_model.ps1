<#
.SYNOPSIS
    Validates the semantic model against the real Analysis Services engine
    running inside an open Power BI Desktop session.

.DESCRIPTION
    tools/validate_data.py reimplements the DAX in Python and proves the logic
    is right.  This script proves the DAX itself is right: it connects to the
    workspace instance Power BI Desktop spins up, checks every measure and
    partition for errors, evaluates the headline measures, and compares them
    with docs/validation_summary.json.

    Open the project in Power BI Desktop first, then run:
        powershell -ExecutionPolicy Bypass -File tools\verify_live_model.ps1
#>

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

# --------------------------------------------------------------------------
# locate a live workspace instance
# --------------------------------------------------------------------------
if (-not (Get-Process PBIDesktop -ErrorAction SilentlyContinue)) {
    Write-Output 'Power BI Desktop is not running. Open IDR_Executive_Monitoring.pbip first.'
    exit 2
}

$adomd = 'C:\Program Files\Microsoft Power BI Desktop\bin\Microsoft.PowerBI.AdomdClient.dll'
if (-not (Test-Path $adomd)) {
    Write-Output "ADOMD client not found at $adomd"
    exit 2
}
[void][System.Reflection.Assembly]::LoadFrom($adomd)

$wsRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\Power BI Desktop\AnalysisServicesWorkspaces'
$conn = $null
$catalog = $null
foreach ($dir in (Get-ChildItem $wsRoot -Directory -ErrorAction SilentlyContinue |
                  Sort-Object LastWriteTime -Descending)) {
    $portFile = Join-Path $dir.FullName 'Data\msmdsrv.port.txt'
    if (-not (Test-Path $portFile)) { continue }
    # msmdsrv.port.txt is UTF-16; reading it as ANSI leaves NUL between digits,
    # so take the digits rather than trusting the encoding.
    $port = -join ((Get-Content $portFile -Raw).ToCharArray() | Where-Object { $_ -match '\d' })
    if (-not $port) { continue }
    try {
        $c = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port")
        $c.Open()
        $cmd = $c.CreateCommand()
        $cmd.CommandText = 'SELECT [CATALOG_NAME] FROM $SYSTEM.DBSCHEMA_CATALOGS'
        $r = $cmd.ExecuteReader()
        if ($r.Read()) { $catalog = $r.GetValue(0) }
        $r.Close(); $c.Close()
        if ($catalog) {
            $conn = New-Object Microsoft.AnalysisServices.AdomdClient.AdomdConnection("Data Source=localhost:$port;Catalog=$catalog")
            $conn.Open()
            Write-Output "connected: localhost:$port  catalog $catalog"
            break
        }
    } catch { }
}
if (-not $conn) { Write-Output 'No live workspace instance found.'; exit 2 }

$problems = 0

function Get-Rows($sql) {
    $cmd = $conn.CreateCommand(); $cmd.CommandText = $sql
    $rdr = $cmd.ExecuteReader(); $rows = @()
    while ($rdr.Read()) {
        $o = [ordered]@{}
        for ($i = 0; $i -lt $rdr.FieldCount; $i++) { $o[$rdr.GetName($i)] = $rdr.GetValue($i) }
        $rows += [pscustomobject]$o
    }
    $rdr.Close(); return $rows
}

# --------------------------------------------------------------------------
# 1. structure and load state
# --------------------------------------------------------------------------
$tables = Get-Rows 'SELECT [Name] FROM $SYSTEM.TMSCHEMA_TABLES'
$measures = Get-Rows 'SELECT [Name],[ErrorMessage] FROM $SYSTEM.TMSCHEMA_MEASURES'
$parts = Get-Rows 'SELECT [Name],[State],[ErrorMessage] FROM $SYSTEM.TMSCHEMA_PARTITIONS'

Write-Output ''
Write-Output "tables:     $($tables.Count)"
Write-Output "measures:   $($measures.Count)"

$badMeasures = $measures | Where-Object { $_.ErrorMessage -and "$($_.ErrorMessage)".Trim() -ne '' }
if ($badMeasures) {
    $problems += $badMeasures.Count
    Write-Output "MEASURE ERRORS: $($badMeasures.Count)"
    $badMeasures | Select-Object -First 20 | ForEach-Object {
        Write-Output ("   [{0}] {1}" -f $_.Name, $_.ErrorMessage)
    }
} else {
    Write-Output 'measure errors: none'
}

# State 1 = Ready
$badParts = $parts | Where-Object { $_.State -ne 1 }
if ($badParts) {
    $problems += $badParts.Count
    Write-Output "PARTITIONS NOT READY: $($badParts.Count)"
    $badParts | ForEach-Object { Write-Output ("   {0} state={1} {2}" -f $_.Name, $_.State, $_.ErrorMessage) }
} else {
    Write-Output "partitions: all $($parts.Count) ready"
}

# --------------------------------------------------------------------------
# 2. evaluate the measures the report actually depends on
# --------------------------------------------------------------------------
$checks = [ordered]@{
    'executive KPIs' = @'
EVALUATE ROW (
    "LatestDate", [Latest Business Date],
    "ResolutionRate", [IDR Resolution Rate (Current)],
    "NotResolved", [IDR Not Resolved (Current)],
    "VarianceTotal", [Total EDL vs Kafka Difference (Current)],
    "VarianceUnique", [Unique EDL vs Kafka Difference (Current)],
    "HealthScore", [IDR Platform Health Score],
    "HealthBand", [Health Score Band],
    "AlertFlag", [Alert Flag],
    "ActiveAlerts", [Active Alerts],
    "CriticalAlerts", [Critical Alerts],
    "DQStatus", [Data Quality Status]
)
'@
    'alert panel (rule dispatch)' = @'
EVALUATE
ORDER BY [Score] DESC
'@
    'narrative' = 'EVALUATE ROW ( "Summary", [Executive Summary Text], "Risk", [Current Risk Summary] )'
    'scorecard' = @'
EVALUATE
SELECTCOLUMNS ( 'Dim_Scorecard', "Metric", 'Dim_Scorecard'[Metric],
    "Value", [Scorecard Value], "Status", [Scorecard Status] )
'@
    'overlap segment ranking' = @'
EVALUATE
SELECTCOLUMNS ( 'Fact_Overlap_Daily', "Segment", 'Fact_Overlap_Daily'[Segment],
    "Current", [Overlap Segment Population (Current)],
    "VsBaseline", [Overlap Segment Population (vs 7D Baseline %)],
    "Rank", [Overlap Segment Sev Rank] )
'@
    'root cause metric watch' = @'
EVALUATE
SELECTCOLUMNS ( 'Dim_Metric_Watch', "Metric", 'Dim_Metric_Watch'[Metric],
    "Current", [Selected Metric Current], "Baseline", [Selected Metric 7D Baseline],
    "Status", [Selected Metric Severity] )
'@
    'data quality checks' = @'
EVALUATE
SELECTCOLUMNS ( 'Dim_DQ_Checks', "Check", 'Dim_DQ_Checks'[Check],
    "Count", [DQ Check Count], "Status", [DQ Check Status] )
'@
    'per-date severity' = @'
EVALUATE
SELECTCOLUMNS ( 'Dim_Date', "Date", 'Dim_Date'[Date], "Severity", [Date Severity] )
'@
}

# the alert-panel query needs the rule table in scope
$checks['alert panel (rule dispatch)'] = @'
EVALUATE
SELECTCOLUMNS (
    FILTER ( 'Dim_Alert_Rules', [Alert Priority Score] >= 2000 ),
    "Severity", [Rule Severity],
    "Rule", 'Dim_Alert_Rules'[Rule],
    "Value", [Rule Current Value],
    "Change", [Rule Change],
    "Score", [Alert Priority Score]
)
ORDER BY [Score] DESC
'@

$headline = @{}
foreach ($name in $checks.Keys) {
    Write-Output ''
    Write-Output "--- $name ---"
    try {
        $rows = Get-Rows $checks[$name]
        if ($rows.Count -eq 0) {
            Write-Output '   (no rows)'
        }
        foreach ($r in $rows | Select-Object -First 12) {
            $parts2 = @()
            foreach ($p in $r.PSObject.Properties) {
                $v = "$($p.Value)"
                if ($v.Length -gt 80) { $v = $v.Substring(0, 80) + '...' }
                $parts2 += $v
            }
            Write-Output ('   ' + ($parts2 -join '  |  '))
        }
        if ($rows.Count -gt 12) { Write-Output "   ... $($rows.Count - 12) more rows" }
        if ($name -eq 'executive KPIs') { $headline = $rows[0] }
    } catch {
        $problems++
        Write-Output "   QUERY FAILED: $($_.Exception.Message)"
    }
}

# --------------------------------------------------------------------------
# 3. cross-check against the Python validation
# --------------------------------------------------------------------------
$summaryPath = Join-Path $root 'docs\validation_summary.json'
if ((Test-Path $summaryPath) -and $headline) {
    $s = Get-Content $summaryPath -Raw | ConvertFrom-Json
    Write-Output ''
    Write-Output '--- engine vs python validation ---'
    $pairs = @(
        @('resolution rate', [double]$headline.'[ResolutionRate]', [double]$s.idr_resolution_rate, 1e-6),
        @('IDR not resolved', [double]$headline.'[NotResolved]', [double]$s.idr_not_resolved, 0.5),
        @('variance total', [double]$headline.'[VarianceTotal]', [double]$s.edl_vs_kafka_variance_total, 0.5),
        @('variance unique', [double]$headline.'[VarianceUnique]', [double]$s.edl_vs_kafka_variance_unique, 0.5),
        @('health score', [double]$headline.'[HealthScore]', [double]$s.platform_health_score, 0.1),
        @('active alerts', [double]$headline.'[ActiveAlerts]', [double]$s.active_alerts, 0.5)
    )
    foreach ($p in $pairs) {
        $ok = [math]::Abs($p[1] - $p[2]) -le $p[3]
        if (-not $ok) { $problems++ }
        Write-Output ("   {0,-18} engine={1,-22} python={2,-22} {3}" -f $p[0], $p[1], $p[2], $(if ($ok) { 'MATCH' } else { 'MISMATCH' }))
    }
}

$conn.Close()
Write-Output ''
if ($problems -gt 0) {
    Write-Output "LIVE VERIFICATION FAILED: $problems problem(s)"
    exit 1
}
Write-Output 'LIVE VERIFICATION PASSED - the engine agrees with the Python validation'
exit 0
