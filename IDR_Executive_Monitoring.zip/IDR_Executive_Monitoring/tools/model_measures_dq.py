"""Data quality layer, narrative measures and report-UX measures."""

from model_measures import (M, F_COUNT, F_COUNT_SIGNED, F_PCT, F_PCT2, F_PCT_SIGNED,
                            F_SCORE, F_Z, F_INT, F_DATE,
                            FLD_EXEC, FLD_IDR, FLD_RECON, FLD_VOL, FLD_OVR,
                            FLD_ALERT, FLD_DQ, FLD_CFG, FLD_NARR, FLD_UX)
from model_measures_alerts import C_GREEN, C_AMBER, C_RED, C_NEUTRAL, C_BLUE

# Every numeric column that must never be null.
NON_NULL_COLUMNS = [
    "Total EDL Logins", "Unique EDL Logins", "Total Kafka Logins Events",
    "Unique Kafka Logins at Profile", "Web IDR Resolved", "App IDR Resolved",
    "IDR Resolved", "IDR Not Resolved", "Web Only", "Kafka Only", "App Only",
    "Kafka and Web", "Kafka and Apps", "Web and Account", "Kafka and Account",
    "Apps and Account", "Difference Total EDL vs Kafka Logins",
    "Difference Unique EDL vs Kafka Logins",
    "Apps IDR Resolved EDL", "Web IDR Resolved EDL",
]
# Overall IDR Resolution Rate is deliberately not in the list above. The
# workbook ships that column empty because the dictionary says the rate is
# calculated over the selected date range, so treating the blank as a missing
# value raised a data-quality warning on every single date.

# Columns that are counts and therefore must never be negative.  The two
# difference columns are deliberately excluded: negative is meaningful there.
NON_NEGATIVE_COLUMNS = [c for c in NON_NULL_COLUMNS
                        if not c.startswith("Difference ")]


def _or_join(template, columns, sep="\n                      || "):
    return sep.join(template % c for c in columns)


def dq_measures():
    null_test = _or_join("ISBLANK ( 'Fact_IDR_Daily'[%s] )", NON_NULL_COLUMNS)
    neg_test = _or_join("'Fact_IDR_Daily'[%s] < 0", NON_NEGATIVE_COLUMNS)

    return [
        # ---- profile ------------------------------------------------------
        M("DQ Row Count", "COUNTROWS ( 'Fact_IDR_Daily' ) + 0", F_COUNT, FLD_DQ,
          "Rows loaded from the source file."),
        M("DQ Distinct Dates", "DISTINCTCOUNT ( 'Fact_IDR_Daily'[Event Date] ) + 0",
          F_COUNT, FLD_DQ, "Distinct Event Dates loaded."),

        # ---- structural defects -------------------------------------------
        M("DQ Missing Event Date",
          """
          COUNTROWS ( FILTER ( 'Fact_IDR_Daily', ISBLANK ( 'Fact_IDR_Daily'[Event Date] ) ) ) + 0
          """,
          F_INT, FLD_DQ, "Rows with no Event Date. Such rows cannot be placed on any trend."),

        M("DQ Duplicate Date Count",
          """
          -- More rows than distinct dates means the daily grain is broken and
          -- every SUM on this model is silently double counting.
          [DQ Row Count] - [DQ Distinct Dates]
          """,
          F_INT, FLD_DQ, "Rows in excess of one per Event Date. Anything above zero breaks the daily grain."),

        M("DQ Null Value Count",
          """
          COUNTROWS (
              FILTER (
                  'Fact_IDR_Daily',
                  {NULLTEST}
              )
          ) + 0
          """.replace("{NULLTEST}", null_test),
          F_INT, FLD_DQ, "Rows containing at least one null in a column that must always be populated."),

        M("DQ Negative Value Count",
          """
          -- The two difference columns are excluded on purpose: negative values
          -- are meaningful there and must not be reported as corruption.
          COUNTROWS (
              FILTER (
                  'Fact_IDR_Daily',
                  {NEGTEST}
              )
          ) + 0
          """.replace("{NEGTEST}", neg_test),
          F_INT, FLD_DQ, "Rows with a negative value in a column that can only be a count."),

        M("DQ IDR Consistency Breaches",
          """
          -- Web + App resolved should reconcile exactly to total resolved.
          COUNTROWS (
              FILTER (
                  'Fact_IDR_Daily',
                  'Fact_IDR_Daily'[Web IDR Resolved] + 'Fact_IDR_Daily'[App IDR Resolved]
                      <> 'Fact_IDR_Daily'[IDR Resolved]
              )
          ) + 0
          """,
          F_INT, FLD_DQ, "Dates where Web plus App resolved does not equal total IDR Resolved."),

        M("DQ Reconciliation Consistency Breaches",
          """
          -- The published difference columns should equal the difference we can
          -- recompute from the volume columns.
          COUNTROWS (
              FILTER (
                  'Fact_IDR_Daily',
                  ( 'Fact_IDR_Daily'[Total EDL Logins] - 'Fact_IDR_Daily'[Total Kafka Logins Events]
                      <> 'Fact_IDR_Daily'[Difference Total EDL vs Kafka Logins] )
                  || ( 'Fact_IDR_Daily'[Unique EDL Logins] - 'Fact_IDR_Daily'[Unique Kafka Logins at Profile]
                      <> 'Fact_IDR_Daily'[Difference Unique EDL vs Kafka Logins] )
              )
          ) + 0
          """,
          F_INT, FLD_DQ, "Dates where the published EDL/Kafka difference disagrees with the difference recomputed from the volume columns."),

        M("DQ Unexpected Resolution Rate Count",
          """
          -- Rows where the source ships no published rate are skipped: the
          -- workbook leaves that column empty on purpose, and an intentional
          -- blank is not a defect.
          COUNTROWS (
              FILTER (
                  'Fact_IDR_Daily',
                  NOT ISBLANK ( 'Fact_IDR_Daily'[Overall IDR Resolution Rate] )
                      && (
                          'Fact_IDR_Daily'[Overall IDR Resolution Rate] < 0
                              || 'Fact_IDR_Daily'[Overall IDR Resolution Rate] > 1
                      )
              )
          ) + 0
          """,
          F_INT, FLD_DQ, "Dates where the published resolution rate falls outside 0-100%."),

        M("DQ Rate Variance Breaches",
          """
          -- Published rate versus rate recalculated from the counts, judged
          -- against the configurable tolerance.
          VAR _tol = [THR Warn SOURCE_VS_CALC_RATE]
          RETURN
              COUNTROWS (
                  FILTER (
                      'Fact_IDR_Daily',
                      NOT ISBLANK ( 'Fact_IDR_Daily'[Overall IDR Resolution Rate] )
                          && ABS (
                              'Fact_IDR_Daily'[Overall IDR Resolution Rate]
                                  - DIVIDE (
                                      'Fact_IDR_Daily'[IDR Resolved],
                                      'Fact_IDR_Daily'[IDR Resolved] + 'Fact_IDR_Daily'[IDR Not Resolved]
                                  )
                          ) > _tol
                  )
              ) + 0
          """,
          F_INT, FLD_DQ, "Dates where the published resolution rate differs from the recalculated rate by more than tolerance."),

        M("DQ Missing Day Count",
          """
          -- Calendar days inside the loaded range that carry no fact row.
          VAR _min = [Earliest Business Date]
          VAR _max = [Latest Business Date]
          RETURN
              COUNTROWS (
                  FILTER (
                      'Dim_Date',
                      'Dim_Date'[Date] >= _min
                          && 'Dim_Date'[Date] <= _max
                          && ISBLANK ( CALCULATE ( COUNTROWS ( 'Fact_IDR_Daily' ) ) )
                  )
              ) + 0
          """,
          F_INT, FLD_DQ, "Days inside the loaded date range that have no data at all."),

        M("Data Quality Issue Count",
          """
          -- Structural defects only.  Analytical anomalies (volume and overlap
          -- movement) are handled by the alert engine so they are not counted
          -- twice against the health score.
          [DQ Missing Event Date] + [DQ Duplicate Date Count] + [DQ Null Value Count]
              + [DQ Negative Value Count] + [DQ IDR Consistency Breaches]
              + [DQ Reconciliation Consistency Breaches] + [DQ Unexpected Resolution Rate Count]
              + [DQ Rate Variance Breaches] + [DQ Missing Day Count]
          """,
          F_INT, FLD_DQ, "Total structural data-quality defects across the loaded data."),

        M("Data Quality Status",
          """
          -- Defects that break the grain or the arithmetic are Critical.
          -- Defects that only make a number untrustworthy are a Warning.
          -- Bad data is flagged, never silently corrected.
          VAR _hard = [DQ Missing Event Date] + [DQ Duplicate Date Count]
              + [DQ Negative Value Count] + [DQ IDR Consistency Breaches]
              + [DQ Reconciliation Consistency Breaches]
          VAR _soft = [DQ Null Value Count] + [DQ Unexpected Resolution Rate Count]
              + [DQ Rate Variance Breaches] + [DQ Missing Day Count]
          RETURN
              SWITCH (
                  TRUE ( ),
                  [DQ Row Count] = 0, "No Data",
                  _hard > 0, "Critical",
                  _soft > 0, "Warning",
                  "Healthy"
              )
          """,
          None, FLD_DQ, "Overall data-quality verdict: Healthy, Warning or Critical."),

        M("DQ_Status", "[Data Quality Status]", None, FLD_DQ,
          "Alias of Data Quality Status."),

        M("Data Quality Colour",
          """
          SWITCH ( [Data Quality Status], "Critical", "{RED}", "Warning", "{AMBER}",
              "Healthy", "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the data-quality verdict.", hidden=True),

        M("Data Quality Label",
          """
          "Data quality: " & [Data Quality Status]
              & IF ( [Data Quality Issue Count] > 0,
                  "  (" & FORMAT ( [Data Quality Issue Count], "0" ) & " issue(s))", "" )
          """,
          None, FLD_DQ, "Header caption for data-quality state."),

        M("Data Quality Issue Count (Selected Date)",
          """
          -- Structural defects attributable to the selected date only.
          -- The alert engine and the health score use this; the dataset-wide
          -- count drives the header caption and the Data Quality page.
          VAR _d = [Selected Business Date]
          RETURN
              IF (
                  NOT ISBLANK ( _d ),
                  CALCULATE (
                      [DQ Date Issue Count],
                      REMOVEFILTERS ( 'Dim_Date' ),
                      'Dim_Date'[Date] = _d
                  )
              ) + 0
          """,
          F_INT, FLD_DQ,
          "Structural data-quality defects on the selected business date."),

        M("Source vs Calculated Resolution Rate Variance (Selected Date)",
          """
          VAR _d = [Selected Business Date]
          RETURN
              IF (
                  NOT ISBLANK ( _d ),
                  CALCULATE (
                      [Source vs Calculated Resolution Rate Variance],
                      REMOVEFILTERS ( 'Dim_Date' ),
                      'Dim_Date'[Date] = _d
                  )
              )
          """,
          F_PCT_SIGNED, FLD_DQ,
          "Gap between the published and the recalculated resolution rate on the selected business date."),

        # ---- analytical anomalies (reported, not scored) --------------------
        M("DQ Unexpected Volume Movement Count",
          """
          -- Analytical, not structural: reported on the data-quality page but
          -- scored through alert Rule 6 rather than the data-quality component.
          VAR _c = [THR Crit VOLUME_ZSCORE]
          RETURN
              COUNTROWS (
                  FILTER (
                      VALUES ( 'Dim_Date'[Date] ),
                      NOT ISBLANK ( [Volume Worst Z-Score] ) && [Volume Worst Z-Score] >= _c
                  )
              ) + 0
          """,
          F_INT, FLD_DQ, "Dates whose login volumes moved beyond the critical z-score tolerance."),

        M("DQ Unexpected Overlap Movement Count",
          """
          VAR _c = [THR Crit OVERLAP_CHANGE_PCT]
          RETURN
              COUNTROWS (
                  FILTER (
                      VALUES ( 'Dim_Date'[Date] ),
                      NOT ISBLANK ( [Overlap Worst Change %] ) && [Overlap Worst Change %] >= _c
                  )
              ) + 0
          """,
          F_INT, FLD_DQ, "Dates where an identity overlap population moved beyond the critical tolerance."),

        M("DQ Unexpected Resolution Movement Count",
          """
          VAR _c = [THR Crit IDR_RESOLUTION_RATE]
          RETURN
              COUNTROWS (
                  FILTER (
                      VALUES ( 'Dim_Date'[Date] ),
                      NOT ISBLANK ( [IDR Resolution Rate (Current)] )
                          && [IDR Resolution Rate (Current)] < _c
                  )
              ) + 0
          """,
          F_INT, FLD_DQ, "Dates whose resolution rate fell below the critical threshold."),

        # ---- per-date detail (drives the Data Quality detail table) ---------
        M("DQ Date Issue Count",
          """
          -- Evaluated inside a single-date row context on the detail table.
          [DQ Missing Event Date] + [DQ Duplicate Date Count] + [DQ Null Value Count]
              + [DQ Negative Value Count] + [DQ IDR Consistency Breaches]
              + [DQ Reconciliation Consistency Breaches] + [DQ Unexpected Resolution Rate Count]
              + [DQ Rate Variance Breaches]
          """,
          F_INT, FLD_DQ, "Structural defects on the date in row context."),

        M("DQ Date Issue List",
          """
          VAR _parts =
              FILTER (
                  {
                      ( "Duplicate date row", [DQ Duplicate Date Count] ),
                      ( "Null in a required column", [DQ Null Value Count] ),
                      ( "Negative count value", [DQ Negative Value Count] ),
                      ( "Web + App does not equal IDR Resolved", [DQ IDR Consistency Breaches] ),
                      ( "Published difference disagrees with recomputed difference", [DQ Reconciliation Consistency Breaches] ),
                      ( "Published rate outside 0-100%", [DQ Unexpected Resolution Rate Count] ),
                      ( "Published rate differs from recalculated rate", [DQ Rate Variance Breaches] )
                  },
                  [Value2] > 0
              )
          VAR _txt = CONCATENATEX ( _parts, [Value1], "; " )
          RETURN IF ( ISBLANK ( _txt ) || _txt = "", "No issues", _txt )
          """,
          None, FLD_DQ, "Named list of the data-quality defects found on the date in row context."),

        M("DQ Date Status",
          """
          VAR _hard = [DQ Duplicate Date Count] + [DQ Negative Value Count]
              + [DQ IDR Consistency Breaches] + [DQ Reconciliation Consistency Breaches]
          VAR _soft = [DQ Null Value Count] + [DQ Unexpected Resolution Rate Count]
              + [DQ Rate Variance Breaches]
          RETURN
              SWITCH ( TRUE ( ), _hard > 0, "Critical", _soft > 0, "Warning", "Healthy" )
          """,
          None, FLD_DQ, "Data-quality verdict for the date in row context."),

        M("DQ Date Status Colour",
          """
          SWITCH ( [DQ Date Status], "Critical", "{RED}", "Warning", "{AMBER}", "{GREEN}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER).replace("{GREEN}", C_GREEN),
          None, FLD_UX, "Semantic colour for the per-date data-quality verdict.", hidden=True),
    ]


# --------------------------------------------------------------------------
# narrative
# --------------------------------------------------------------------------
def narrative_measures():
    return [
        M("Executive Summary Text",
          """
          -- Answers: what changed, how big, improving or deteriorating, and what
          -- is driving the risk.  Every number comes from a measure.
          VAR _d = [Selected Business Date]
          VAR _band = [Health Score Band]
          VAR _score = [IDR Platform Health Score]
          VAR _rate = [IDR Resolution Rate (Current)]
          VAR _ratePP = [IDR Resolution Rate (Delta pp)]
          VAR _nrPct = [IDR Not Resolved (vs 7D Baseline %)]
          VAR _nr = [IDR Not Resolved (Current)]
          VAR _dir = [Reconciliation Direction Change]
          VAR _driver = [Primary Risk Driver]
          VAR _trend = [IDR Resolution Rate (Trend)]
          VAR _direction =
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _ratePP ), "There is no prior day to compare against yet",
                  _ratePP < -0.1, "The trend is deteriorating",
                  _ratePP > 0.1, "The trend is improving",
                  "The trend is broadly flat"
              )
          RETURN
              IF (
                  ISBLANK ( _d ),
                  "No data is loaded.",
                  "As of " & FORMAT ( _d, "dd-MMM-yyyy" ) & ", IDR platform health is " & _band
                      & " at " & FORMAT ( _score, "0" ) & " out of 100. "
                      & "IDR resolution is " & FORMAT ( _rate, "0.0%" ) & " ("
                      & IF ( ISBLANK ( _ratePP ), "n/a", FORMAT ( _ratePP, "+0.0;-0.0;0" ) ) & " pp versus the previous day, "
                      & LOWER ( _trend ) & " against the 7-day baseline). "
                      & "IDR Not Resolved is " & FORMAT ( _nr, "#,##0" ) & ", "
                      & IF ( ISBLANK ( _nrPct ), "n/a", FORMAT ( _nrPct, "+0.0%;-0.0%;0.0%" ) )
                      & " versus the recent baseline. "
                      & "EDL/Kafka reconciliation is " & FORMAT ( [Total Reconciliation % (Current)], "0.0%" )
                      & " with signed variance " & FORMAT ( [Total EDL vs Kafka Difference (Current)], "+#,##0;-#,##0;0" )
                      & " (" & _dir & "). "
                      & _direction & ". Primary investigation focus: " & _driver & "."
              )
          """,
          None, FLD_NARR,
          "Dynamic executive narrative: what changed, how large, improving or deteriorating, and what is driving the risk."),

        M("Current Risk Summary",
          """
          VAR _crit = [Active Critical Signal Count]
          VAR _warn = [Active Warning Signal Count]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( [Selected Business Date] ), "No data loaded.",
                  _crit = 0 && _warn = 0,
                      "All monitored controls are inside tolerance. No action required.",
                  _crit = 0,
                      FORMAT ( _warn, "0" ) & " control(s) are in warning and should be watched. "
                          & "Highest priority: " & [Primary Risk Driver] & ".",
                  FORMAT ( _crit, "0" ) & " control(s) are critical and "
                      & FORMAT ( _warn, "0" ) & " are in warning. "
                      & IF ( _crit + _warn >= 3,
                          "The failures are correlated, which points to a single upstream cause rather than "
                              & "independent incidents. ", "" )
                      & "Start with: " & [Primary Risk Driver] & "."
              )
          """,
          None, FLD_NARR, "What is at risk right now and what to investigate first."),

        M("Trend Summary",
          """
          VAR _rateTrend = [IDR Resolution Rate (Trend)]
          VAR _nrTrend = [IDR Not Resolved (Trend)]
          VAR _volTrend = [Total EDL Logins (Trend)]
          VAR _reconTrend = [Total Reconciliation % (Trend)]
          RETURN
              "Resolution rate: " & _rateTrend
                  & "  |  Unresolved IDRs: " & _nrTrend
                  & "  |  EDL volume: " & _volTrend
                  & "  |  Reconciliation: " & _reconTrend
                  & "   (all against the trailing 7-day baseline)"
          """,
          None, FLD_NARR, "One-line direction of travel across the four headline metrics."),

        M("What Changed Summary",
          """
          -- Root Cause Explorer: the movement of every headline metric on the
          -- selected date against the previous day.
          VAR _d = [Selected Business Date]
          RETURN
              IF (
                  ISBLANK ( _d ), "Select a date to investigate.",
                  "On " & FORMAT ( _d, "dd-MMM-yyyy" ) & ": resolution "
                      & FORMAT ( [IDR Resolution Rate (Current)], "0.0%" ) & " ("
                      & IF ( ISBLANK ( [IDR Resolution Rate (Delta pp)] ), "n/a", FORMAT ( [IDR Resolution Rate (Delta pp)], "+0.0;-0.0;0" ) ) & " pp), "
                      & "unresolved " & FORMAT ( [IDR Not Resolved (Current)], "#,##0" ) & " ("
                      & IF ( ISBLANK ( [IDR Not Resolved (Delta %)] ), "n/a", FORMAT ( [IDR Not Resolved (Delta %)], "+0.0%;-0.0%;0.0%" ) ) & "), "
                      & "EDL " & FORMAT ( [Total EDL Logins (Current)], "#,##0" ) & " ("
                      & IF ( ISBLANK ( [Total EDL Logins (Delta %)] ), "n/a", FORMAT ( [Total EDL Logins (Delta %)], "+0.0%;-0.0%;0.0%" ) ) & "), "
                      & "Kafka " & FORMAT ( [Total Kafka Logins Events (Current)], "#,##0" ) & " ("
                      & IF ( ISBLANK ( [Total Kafka Logins Events (Delta %)] ), "n/a", FORMAT ( [Total Kafka Logins Events (Delta %)], "+0.0%;-0.0%;0.0%" ) ) & "), "
                      & "signed variance " & FORMAT ( [Total EDL vs Kafka Difference (Current)], "+#,##0;-#,##0;0" )
                      & ", web resolved " & FORMAT ( [Web IDR Resolved (Current)], "#,##0" )
                      & ", app resolved " & FORMAT ( [App IDR Resolved (Current)], "#,##0" )
                      & ", overlap population " & FORMAT ( [Overlap Population (Current)], "#,##0" ) & "."
              )
          """,
          None, FLD_NARR, "Root Cause Explorer: what moved on the selected date."),

        M("Why Flagged Explanation",
          """
          -- Root Cause Explorer: why the selected date is flagged, built only
          -- from the rules that are actually firing.
          VAR _t = ADDCOLUMNS ( ALL ( 'Dim_Alert_Rules' ), "@score", [Alert Priority Score] )
          VAR _firing = FILTER ( _t, [@score] >= 2000 )
          VAR _txt =
              CONCATENATEX (
                  TOPN ( 4, _firing, [@score], DESC ),
                  "- " & [Rule Severity] & ": " & [Rule Message],
                  UNICHAR ( 10 )
              )
          RETURN
              IF (
                  ISBLANK ( _txt ),
                  "This date is not flagged. All monitored controls are inside tolerance.",
                  "This date is flagged because:" & UNICHAR ( 10 ) & _txt
              )
          """,
          None, FLD_NARR, "Root Cause Explorer: the reasons the selected date is flagged, generated from the firing rules."),

        M("Abnormality Summary",
          """
          -- Root Cause Explorer: how the selected date compares with its
          -- previous day, its 7-day baseline and all history.
          "Versus previous day: resolution "
              & IF ( ISBLANK ( [IDR Resolution Rate (Delta pp)] ), "n/a", FORMAT ( [IDR Resolution Rate (Delta pp)], "+0.0;-0.0;0" ) ) & " pp, "
              & "unresolved " & IF ( ISBLANK ( [IDR Not Resolved (Delta %)] ), "n/a", FORMAT ( [IDR Not Resolved (Delta %)], "+0.0%;-0.0%;0.0%" ) ) & ".  "
              & "Versus 7-day baseline: resolution "
              & IF ( ISBLANK ( [IDR Resolution Rate (vs 7D Baseline pp)] ), "n/a", FORMAT ( [IDR Resolution Rate (vs 7D Baseline pp)], "+0.0;-0.0;0" ) ) & " pp, "
              & "unresolved " & IF ( ISBLANK ( [IDR Not Resolved (vs 7D Baseline %)] ), "n/a", FORMAT ( [IDR Not Resolved (vs 7D Baseline %)], "+0.0%;-0.0%;0.0%" ) )
              & " (z " & IF ( ISBLANK ( [IDR Not Resolved (Z-Score)] ), "n/a", FORMAT ( [IDR Not Resolved (Z-Score)], "0.00" ) ) & ").  "
              & "Versus all history: resolution average "
              & FORMAT ( [IDR Resolution Rate (Historical Avg)], "0.0%" )
              & ", range " & FORMAT ( [IDR Resolution Rate (Historical Min)], "0.0%" )
              & " to " & FORMAT ( [IDR Resolution Rate (Historical Max)], "0.0%" ) & "."
          """,
          None, FLD_NARR, "Root Cause Explorer: how abnormal the selected date is against three different baselines."),
    ]


# --------------------------------------------------------------------------
# report UX - dynamic titles, subtitles and card captions
# --------------------------------------------------------------------------
def ux_measures():
    return [
        M("Exec Header Title", '"IDR PLATFORM EXECUTIVE HEALTH"', None, FLD_UX,
          "Static executive page title, held as a measure so it can be themed centrally."),

        M("Exec Header Subtitle",
          """
          "EDL vs Kafka Reconciliation   |   IDR Resolution   |   Operational Risk"
          """,
          None, FLD_UX, "Executive page subtitle."),

        M("Exec Status Banner",
          """
          VAR _flag = [Alert Flag]
          RETURN
              _flag & "     " & [Data Through Label] & "     " & [Data Quality Label]
          """,
          None, FLD_UX, "Single-line status banner combining escalation state, business date and data quality."),

        M("Resolution Trend Title",
          """
          "IDR Resolution Trend   -   currently " & FORMAT ( [IDR Resolution Rate (Current)], "0.0%" )
              & ", warning at " & FORMAT ( [THR Warn IDR_RESOLUTION_RATE], "0.0%" )
              & ", critical at " & FORMAT ( [THR Crit IDR_RESOLUTION_RATE], "0.0%" )
          """,
          None, FLD_UX, "Dynamic title for the executive resolution trend chart."),

        M("Reconciliation Trend Title",
          """
          "EDL vs Kafka Signed Variance   -   " & [Reconciliation Direction]
              & " by " & FORMAT ( [Absolute Total Difference (Current)], "#,##0" )
              & " events (" & [Reconciliation Direction Change] & ")"
          """,
          None, FLD_UX, "Dynamic title for the signed variance trend chart."),

        M("Overlap Title",
          """
          "Identity Overlap Populations   -   largest move: " & [Worst Overlap Segment]
              & " " & IF ( ISBLANK ( [Overlap Worst Change %] ), "n/a", FORMAT ( [Overlap Worst Change %], "+0.0%;-0.0%;0.0%" ) )
              & " vs 7-day baseline"
          """,
          None, FLD_UX, "Dynamic title for the overlap composition chart."),

        M("Root Cause Title",
          """
          "Root Cause Explorer   -   " & FORMAT ( [Selected Business Date], "dd-MMM-yyyy" )
              & "   |   " & [Alert Flag]
          """,
          None, FLD_UX, "Dynamic title for the Root Cause Explorer page."),

        M("Watchlist Title",
          """
          "IDR Not Resolved Watchlist   -   " & FORMAT ( [DQ Unexpected Resolution Movement Count], "0" )
              & " date(s) below the critical resolution threshold"
          """,
          None, FLD_UX, "Dynamic title for the unresolved watchlist."),

        # ---- per-date severity used by the trend, heatmap and watchlist -----
        M("Date Severity Rank",
          """
          -- Severity of the date in row context.  Used by the heatmap, the
          -- watchlist and the anomaly markers on the trend charts.
          [Overall Severity Rank]
          """,
          F_INT, FLD_ALERT, "Worst alert severity on the date in row context."),

        M("Date Severity",
          """
          SWITCH ( [Date Severity Rank], 3, "CRITICAL", 2, "WARNING", 1, "HEALTHY", "NO DATA" )
          """,
          None, FLD_ALERT, "Alert severity of the date in row context, as text."),

        M("Date Severity Colour",
          """
          SWITCH ( [Date Severity Rank], 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the date in row context.", hidden=True),

        # ---- KPI card captions and colours ---------------------------------
        # Each executive card carries value, direction, delta and severity.  The
        # caption and the colour are measures so the card stays truthful as the
        # data moves, and so severity is never hard-coded into the layout.
        M("Card Caption Resolution",
          """
          VAR _d = [IDR Resolution Rate (Delta pp)]
          VAR _arrow = SWITCH ( TRUE ( ), ISBLANK ( _d ), "-", _d > 0, "^", _d < 0, "v", "=" )
          VAR _txt = IF ( ISBLANK ( _d ), "no prior day",
              _arrow & " " & FORMAT ( _d, "+0.00;-0.00;0.00" ) & " pp vs prev day" )
          RETURN _txt & "   |   " & SWITCH ( [Sev Rank IDR Resolution], 3, "CRITICAL", 2, "WARNING", 1, "HEALTHY", "NO DATA" )
          """,
          None, FLD_UX, "Caption for the IDR Resolution Rate executive card."),

        M("Card Caption Not Resolved",
          """
          VAR _d = [IDR Not Resolved (Delta %)]
          VAR _b = [IDR Not Resolved (vs 7D Baseline %)]
          VAR _arrow = SWITCH ( TRUE ( ), ISBLANK ( _d ), "-", _d > 0, "^", _d < 0, "v", "=" )
          VAR _txt = IF ( ISBLANK ( _d ), "no prior day",
              _arrow & " " & FORMAT ( _d, "+0.0%;-0.0%;0.0%" ) & " vs prev day" )
          VAR _base = IF ( ISBLANK ( _b ), "", "   |   " & FORMAT ( _b, "+0.0%;-0.0%;0.0%" ) & " vs 7D" )
          RETURN _txt & _base & "   |   " & SWITCH ( [Sev Rank IDR Not Resolved], 3, "CRITICAL", 2, "WARNING", 1, "HEALTHY", "NO DATA" )
          """,
          None, FLD_UX, "Caption for the IDR Not Resolved executive card."),

        M("Card Caption Health Score",
          """
          [Health Score Band] & "   |   " & FORMAT ( [Active Critical Signal Count], "0" )
              & " critical, " & FORMAT ( [Active Warning Signal Count], "0" ) & " warning signals"
          """,
          None, FLD_UX, "Caption for the platform health score card."),

        M("Card Caption Active Alerts",
          """
          VAR _c = [Critical Alerts]
          RETURN
              FORMAT ( _c, "0" ) & " critical   |   " & [Alert Flag]
          """,
          None, FLD_UX, "Caption for the active alerts card."),

        M("Card Caption EDL Logins",
          """
          VAR _d = [Total EDL Logins (Delta %)]
          VAR _z = [Total EDL Logins (Z-Score)]
          VAR _arrow = SWITCH ( TRUE ( ), ISBLANK ( _d ), "-", _d > 0, "^", _d < 0, "v", "=" )
          RETURN
              IF ( ISBLANK ( _d ), "no prior day",
                  _arrow & " " & FORMAT ( _d, "+0.0%;-0.0%;0.0%" ) & " vs prev day" )
              & IF ( ISBLANK ( _z ), "   |   baseline building",
                  "   |   z " & FORMAT ( _z, "0.00" ) )
          """,
          None, FLD_UX, "Caption for the EDL login volume card."),

        M("Card Caption Kafka Events",
          """
          VAR _d = [Total Kafka Logins Events (Delta %)]
          VAR _z = [Total Kafka Logins Events (Z-Score)]
          VAR _arrow = SWITCH ( TRUE ( ), ISBLANK ( _d ), "-", _d > 0, "^", _d < 0, "v", "=" )
          RETURN
              IF ( ISBLANK ( _d ), "no prior day",
                  _arrow & " " & FORMAT ( _d, "+0.0%;-0.0%;0.0%" ) & " vs prev day" )
              & IF ( ISBLANK ( _z ), "   |   baseline building",
                  "   |   z " & FORMAT ( _z, "0.00" ) )
          """,
          None, FLD_UX, "Caption for the Kafka login event volume card."),

        M("Card Caption Total Variance",
          """
          -- Direction is spelled out because the sign is the whole point.
          [Reconciliation Direction] & "   |   " & [Reconciliation Direction Change]
          """,
          None, FLD_UX, "Caption for the total EDL vs Kafka variance card."),

        M("Card Caption Unique Variance",
          """
          [Unique Reconciliation Direction] & "   |   recon "
              & FORMAT ( [Unique Reconciliation % (Current)], "0.0%" )
          """,
          None, FLD_UX, "Caption for the unique EDL vs Kafka variance card."),

        M("Colour IDR Resolution",
          """
          SWITCH ( [Sev Rank IDR Resolution], 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the resolution rate card.", hidden=True),

        M("Colour IDR Not Resolved",
          """
          SWITCH ( [Sev Rank IDR Not Resolved], 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the unresolved IDR card.", hidden=True),

        M("Colour Volume",
          """
          SWITCH ( [Sev Rank Volume], 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the volume cards.", hidden=True),

        M("Colour Reconciliation",
          """
          -- Worst of the drift rule and the direction rule: a reversal must not
          -- be masked by a reconciliation rate that happens to look healthy.
          VAR _r = MAXX ( { [Sev Rank Reconciliation], [Sev Rank Direction] }, [Value] )
          RETURN SWITCH ( _r, 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the reconciliation variance cards.", hidden=True),

        # ---- threshold reference lines -------------------------------------
        M("Target Resolution Rate", "[THR Warn IDR_RESOLUTION_RATE] + 0.01", F_PCT, FLD_CFG,
          "Target line for the resolution trend chart, set one point above the warning threshold."),
        M("Warning Resolution Rate", "[THR Warn IDR_RESOLUTION_RATE]", F_PCT, FLD_CFG,
          "Warning reference line for the resolution trend chart."),
        M("Critical Resolution Rate", "[THR Crit IDR_RESOLUTION_RATE]", F_PCT, FLD_CFG,
          "Critical reference line for the resolution trend chart."),
        M("Zero Reference Line", "0", F_COUNT, FLD_CFG,
          "Zero line for the signed variance chart. Above the line EDL exceeds Kafka; below it Kafka exceeds EDL."),

        # ---- scorecard support ---------------------------------------------
        M("Scorecard Value",
          """
          -- Management Summary scorecard: one row per metric, driven by the
          -- disconnected scorecard table.
          SWITCH (
              SELECTEDVALUE ( 'Dim_Scorecard'[Metric Key] ),
              "RESOLUTION", FORMAT ( [IDR Resolution Rate (Current)], "0.00%" ),
              "NON_RESOLUTION", FORMAT ( [IDR Non-Resolution Rate (Current)], "0.00%" ),
              "RECON_TOTAL", FORMAT ( [Total Reconciliation % (Current)], "0.0%" ),
              "RECON_UNIQUE", FORMAT ( [Unique Reconciliation % (Current)], "0.0%" ),
              "WEB_RES", FORMAT ( [Web Resolution % (Current)], "0.0%" ),
              "APP_RES", FORMAT ( [App Resolution % (Current)], "0.0%" ),
              "DATA_QUALITY", [Data Quality Status],
              "ACTIVE_ALERTS", FORMAT ( [Active Alerts], "0" ),
              BLANK ( )
          )
          """,
          None, FLD_UX, "Current value for the scorecard row in context."),

        M("Scorecard Target",
          """
          SWITCH (
              SELECTEDVALUE ( 'Dim_Scorecard'[Metric Key] ),
              "RESOLUTION", "at or above " & FORMAT ( [THR Warn IDR_RESOLUTION_RATE], "0.0%" ),
              "NON_RESOLUTION", "at or below " & FORMAT ( 1 - [THR Warn IDR_RESOLUTION_RATE], "0.0%" ),
              "RECON_TOTAL", "drift under " & FORMAT ( [THR Warn RECON_DRIFT_PP] * 100, "0.0" ) & " pp",
              "RECON_UNIQUE", "drift under " & FORMAT ( [THR Warn RECON_DRIFT_PP] * 100, "0.0" ) & " pp",
              "WEB_RES", "stable vs baseline",
              "APP_RES", "stable vs baseline",
              "DATA_QUALITY", "Healthy",
              "ACTIVE_ALERTS", "0",
              BLANK ( )
          )
          """,
          None, FLD_UX, "Target for the scorecard row in context."),

        M("Scorecard Trend",
          """
          SWITCH (
              SELECTEDVALUE ( 'Dim_Scorecard'[Metric Key] ),
              "RESOLUTION", [IDR Resolution Rate (Trend)],
              "NON_RESOLUTION", [IDR Non-Resolution Rate (Trend)],
              "RECON_TOTAL", [Total Reconciliation % (Trend)],
              "RECON_UNIQUE", [Unique Reconciliation % (Trend)],
              "WEB_RES", [Web Resolution % (Trend)],
              "APP_RES", [App Resolution % (Trend)],
              "DATA_QUALITY", IF ( [Data Quality Issue Count] > 0, "Rising", "Stable" ),
              "ACTIVE_ALERTS", IF ( [Active Alerts] > 0, "Rising", "Stable" ),
              BLANK ( )
          )
          """,
          None, FLD_UX, "Direction of travel for the scorecard row in context."),

        M("Scorecard Change",
          """
          SWITCH (
              SELECTEDVALUE ( 'Dim_Scorecard'[Metric Key] ),
              "RESOLUTION", IF ( ISBLANK ( [IDR Resolution Rate (Delta pp)] ), "n/a", FORMAT ( [IDR Resolution Rate (Delta pp)], "+0.0;-0.0;0" ) & " pp" ),
              "NON_RESOLUTION", IF ( ISBLANK ( [IDR Non-Resolution Rate (Delta pp)] ), "n/a", FORMAT ( [IDR Non-Resolution Rate (Delta pp)], "+0.0;-0.0;0" ) & " pp" ),
              "RECON_TOTAL", IF ( ISBLANK ( [Total Reconciliation % (Delta pp)] ), "n/a", FORMAT ( [Total Reconciliation % (Delta pp)], "+0.0;-0.0;0" ) & " pp" ),
              "RECON_UNIQUE", IF ( ISBLANK ( [Unique Reconciliation % (Delta pp)] ), "n/a", FORMAT ( [Unique Reconciliation % (Delta pp)], "+0.0;-0.0;0" ) & " pp" ),
              "WEB_RES", IF ( ISBLANK ( [Web Resolution % (Delta pp)] ), "n/a", FORMAT ( [Web Resolution % (Delta pp)], "+0.0;-0.0;0" ) & " pp" ),
              "APP_RES", IF ( ISBLANK ( [App Resolution % (Delta pp)] ), "n/a", FORMAT ( [App Resolution % (Delta pp)], "+0.0;-0.0;0" ) & " pp" ),
              "DATA_QUALITY", FORMAT ( [Data Quality Issue Count], "0" ) & " issue(s)",
              "ACTIVE_ALERTS", FORMAT ( [Critical Alerts], "0" ) & " critical",
              BLANK ( )
          )
          """,
          None, FLD_UX, "Movement for the scorecard row in context."),

        M("Scorecard Severity Rank",
          """
          SWITCH (
              SELECTEDVALUE ( 'Dim_Scorecard'[Metric Key] ),
              "RESOLUTION", [Sev Rank IDR Resolution],
              "NON_RESOLUTION", [Sev Rank IDR Resolution],
              "RECON_TOTAL", [Sev Rank Reconciliation],
              "RECON_UNIQUE", [Sev Rank Reconciliation],
              "WEB_RES", [Sev Rank IDR Resolution],
              "APP_RES", [Sev Rank IDR Resolution],
              "DATA_QUALITY", [Sev Rank Data Quality],
              "ACTIVE_ALERTS", [Overall Severity Rank],
              BLANK ( )
          )
          """,
          F_INT, FLD_UX, "Severity rank for the scorecard row in context.", hidden=True),

        M("Scorecard Status",
          """
          SWITCH ( [Scorecard Severity Rank], 3, "CRITICAL", 2, "WARNING", 1, "ON TARGET", "NO DATA" )
          """,
          None, FLD_UX, "Status for the scorecard row in context."),

        M("Scorecard Colour",
          """
          SWITCH ( [Scorecard Severity Rank], 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the scorecard row in context.", hidden=True),
    ]
