"""Generates docs/DATA_DICTIONARY.md from the semantic model itself, so the
documentation cannot drift away from the DAX.

Run:  python tools/gen_docs.py
"""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from gen_semantic_model import (collect_measures, FACT_COLUMNS, RENAMES,
                                OVERLAP_SEGMENTS, SCORECARD_ROWS, TIMEFRAMES,
                                RULE_DESCRIPTIONS)
from model_measures_alerts import ALERT_RULES
from model_measures_selector import WATCH_METRICS, DQ_CHECKS

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DOCS = os.path.join(ROOT, "docs")


def esc(s):
    return (s or "").replace("|", "\\|")


def main():
    measures = collect_measures()
    L = []
    a = L.append

    a("# Data Dictionary")
    a("")
    a("Generated from the semantic model by `tools/gen_docs.py`. "
      "Every entry below is read out of the TMDL that Power BI loads, so this "
      "document and the model cannot disagree.")
    a("")
    a("- **Tables:** 13")
    a("- **Measures:** %d" % len(measures))
    a("- **Grain:** one row per `Event Date` in `Fact_IDR_Daily`")
    a("")

    # ---- source mapping --------------------------------------------------
    a("## 1. Source column mapping")
    a("")
    a("Power Query renames the workbook headers into model names. "
      "`MissingField.Ignore` is used, so a header that is absent is skipped "
      "rather than breaking the refresh.")
    a("")
    a("| Workbook header | Model column | Type | Meaning |")
    a("|---|---|---|---|")
    desc = {c[0]: (c[1], c[3]) for c in FACT_COLUMNS}
    seen = set()
    for src, dst in RENAMES:
        if dst in seen:
            a("| `%s` | %s | | *alias, tolerated if present* |" % (esc(src), esc(dst)))
            continue
        seen.add(dst)
        t, d = desc.get(dst, ("", ""))
        a("| `%s` | %s | %s | %s |" % (esc(src), esc(dst), t, esc(d)))
    a("")
    a("> The workbook ships the resolved-count header as `_IDR_Resolved`, with a "
      "leading underscore. Both that and the plain `IDR_Resolved` spelling are "
      "mapped, so either is accepted.")
    a("")

    # ---- tables ----------------------------------------------------------
    a("## 2. Tables")
    a("")
    a("| Table | Kind | Purpose |")
    a("|---|---|---|")
    for name, kind, purpose in [
        ("Fact_IDR_Daily", "Import (Excel)", "Daily snapshot. One row per Event Date. All columns hidden; the measure layer is the only analytical surface."),
        ("Fact_Overlap_Daily", "Calculated", "The eight identity populations unpivoted to one row per date and segment. Makes segment-level anomaly ranking a single measure instead of eight."),
        ("Dim_Date", "Calculated", "Date dimension spanning exactly the loaded data. Marked as the model date table."),
        ("Dim_Thresholds", "Import (CSV)", "Business-editable alert thresholds and health-score weights."),
        ("Dim_Metric_Definitions", "Import (CSV)", "Business glossary driving the Metric Definitions page."),
        ("Dim_Alert_Rules", "Calculated", "Catalogue of the nine alert rules. Disconnected."),
        ("Dim_Scorecard", "Calculated", "Rows of the Management Summary scorecard. Disconnected."),
        ("Dim_Timeframe", "Calculated", "Timeframe selector for Historical Trends. Disconnected."),
        ("Dim_Metric_Watch", "Calculated", "Headline metric watchlist; row source of the Root Cause comparison table. Disconnected."),
        ("Dim_DQ_Checks", "Calculated", "Catalogue of data-quality checks. Disconnected."),
        ("Trend Metric", "Field parameter", "Metric selector for the Historical Trends chart."),
        ("Refresh Info", "Import (inline)", "Single-row model refresh timestamp."),
        ("_Metrics", "Calculated", "Home table for all %d explicit measures. Holds no data." % len(measures)),
    ]:
        a("| `%s` | %s | %s |" % (name, kind, esc(purpose)))
    a("")
    a("### Relationships")
    a("")
    a("| From | To | Cardinality | Direction |")
    a("|---|---|---|---|")
    a("| `Fact_IDR_Daily[Event Date]` | `Dim_Date[Date]` | many-to-one | single |")
    a("| `Fact_Overlap_Daily[Event Date]` | `Dim_Date[Date]` | many-to-one | single |")
    a("")
    a("Every other dimension is deliberately **disconnected**: it drives a "
      "`SWITCH` in the measure layer rather than filtering the fact table.")
    a("")

    # ---- overlap segments -------------------------------------------------
    a("## 3. Why resolution failed - the eight partial-match populations")
    a("")
    a("Resolution needs three events: (web or app) + kafka + account. Each row is")
    a("a population that carried only part of that evidence. They sum exactly to")
    a("IDR Not Resolved on every loaded row.")
    a("")
    a("| Segment | Evidence held | Missing event | Order |")
    a("|---|---|---|---|")
    for seg, evidence, missing, order in OVERLAP_SEGMENTS:
        a("| %s | %s | %s | %d |" % (seg, evidence, missing, order))
    a("")

    # ---- alert rules ------------------------------------------------------
    a("## 4. Alert rules")
    a("")
    a("| Key | Rule | Domain | Priority | What it detects |")
    a("|---|---|---|---|---|")
    for key, name, cat, prio in sorted(ALERT_RULES, key=lambda r: r[3]):
        a("| `%s` | %s | %s | %d | %s |"
          % (key, name, cat, prio, esc(RULE_DESCRIPTIONS[key])))
    a("")
    a("Severity ranks: `0` no data, `1` healthy, `2` warning, `3` critical. "
      "`Alert Priority Score = rank x 1000 + (100 - priority)`, so severity "
      "always dominates and priority only breaks ties inside a severity.")
    a("")

    # ---- thresholds -------------------------------------------------------
    a("## 5. Threshold configuration")
    a("")
    a("Read from `data/Thresholds.csv` at refresh. Edit that file and refresh; "
      "no DAX change is required.")
    a("")
    path = os.path.join(ROOT, "data", "Thresholds.csv")
    with open(path, encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    a("| Key | Metric | Warning | Critical | Direction | Health weight | Unit |")
    a("|---|---|---:|---:|---|---:|---|")
    for r in rows:
        a("| `%s` | %s | %s | %s | %s | %s | %s |"
          % (r["Metric Key"], esc(r["Metric"]), r["Warning Threshold"],
             r["Critical Threshold"], r["Direction"], r["Weight"], r["Unit"]))
    a("")
    a("Health-score weights sum to 100 across the six scored components. "
      "A weight of `0` means the metric drives alerting but not the score.")
    a("")

    # ---- data quality -----------------------------------------------------
    a("## 6. Data-quality checks")
    a("")
    a("| Key | Check | Category | Measure | Detects |")
    a("|---|---|---|---|---|")
    for key, name, cat, meas, d in DQ_CHECKS:
        a("| `%s` | %s | %s | `[%s]` | %s |" % (key, esc(name), cat, meas, esc(d)))
    a("")
    a("**Structural**, **Arithmetic**, **Trust** and **Completeness** checks "
      "count toward `Data Quality Issue Count` and the health score. "
      "**Analytical** findings are surfaced here but alerted through the rule "
      "engine, so nothing is scored twice.")
    a("")

    # ---- trend pattern ----------------------------------------------------
    a("## 7. Trend-intelligence pattern")
    a("")
    a("Every headline KPI carries the same set of derived measures, so any "
      "metric can be read the same way anywhere in the report.")
    a("")
    a("| Suffix | Meaning |")
    a("|---|---|")
    for suf, mean in [
        ("(Current)", "Value on the selected business date."),
        ("(Previous Day)", "Value on the previous date **that has data** (gap-safe)."),
        ("(Delta)", "Day-on-day movement."),
        ("(Delta %)", "Day-on-day movement as a percentage."),
        ("(Delta pp)", "Day-on-day movement in percentage points (rate metrics only)."),
        ("(7D Avg)", "Rolling seven-day average **including** the selected date."),
        ("(7D Baseline)", "Mean of the seven days **before** the selected date. Excluding the day under judgement is what makes a single-day spike detectable."),
        ("(vs 7D Baseline)", "Movement against that baseline."),
        ("(vs 7D Baseline %)", "Movement against that baseline, as a percentage."),
        ("(vs 7D Baseline pp)", "Movement against that baseline, in percentage points (rate metrics only)."),
        ("(7D StDev)", "Volatility over the baseline window. Hidden."),
        ("(Z-Score)", "Standard deviations from the baseline. **Blank** until the baseline holds `MIN_BASELINE_DAYS` observations."),
        ("(Historical Avg / Min / Max)", "Across all history up to the selected date."),
        ("(Volatility)", "Coefficient of variation over the baseline window."),
        ("(Trend)", "Rising / Falling / Stable against the baseline."),
    ]:
        a("| `%s` | %s |" % (suf, esc(mean)))
    a("")
    a("Metrics carrying the full pattern:")
    a("")
    for label, fmt, sev in WATCH_METRICS:
        a("- `%s` (format `%s`%s)" % (label, fmt,
                                      ", governed by `[%s]`" % sev if sev else ""))
    a("")

    # ---- measures ---------------------------------------------------------
    a("## 8. Measure catalogue")
    a("")
    folders = {}
    for m in measures:
        top = m["folder"].split("\\")[0]
        folders.setdefault(top, []).append(m)
    a("| Display folder | Measures |")
    a("|---|---:|")
    for f in sorted(folders):
        a("| %s | %d |" % (f, len(folders[f])))
    a("| **Total** | **%d** |" % len(measures))
    a("")
    for f in sorted(folders):
        if f.startswith("08"):
            a("### %s" % f)
            a("")
            a("%d measures: the trend pattern above applied to each of the %d "
              "headline metrics. Not listed individually."
              % (len(folders[f]), len(WATCH_METRICS)))
            a("")
            continue
        a("### %s" % f)
        a("")
        a("| Measure | Format | Description |")
        a("|---|---|---|")
        for m in sorted(folders[f], key=lambda x: x["name"]):
            a("| %s`%s` | %s | %s |"
              % ("*(hidden)* " if m["hidden"] else "", m["name"],
                 "`%s`" % esc(m["fmt"]) if m["fmt"] else "text",
                 esc(m["desc"])))
        a("")

    # ---- reference tables -------------------------------------------------
    a("## 9. Disconnected selector contents")
    a("")
    a("**Dim_Scorecard**")
    a("")
    a("| Key | Metric | Order |")
    a("|---|---|---|")
    for k, n, o in SCORECARD_ROWS:
        a("| `%s` | %s | %d |" % (k, n, o))
    a("")
    a("**Dim_Timeframe** — windows are measured back from `[Latest Business Date]`, "
      "never from `TODAY()`.")
    a("")
    a("| Timeframe | Days | Order |")
    a("|---|---:|---:|")
    for n, d, o in TIMEFRAMES:
        a("| %s | %s | %d |" % (n, d if d else "all", o))
    a("")

    os.makedirs(DOCS, exist_ok=True)
    out = os.path.join(DOCS, "DATA_DICTIONARY.md")
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(L) + "\n")
    print("wrote %s (%d lines)" % (out, len(L)))


if __name__ == "__main__":
    main()
