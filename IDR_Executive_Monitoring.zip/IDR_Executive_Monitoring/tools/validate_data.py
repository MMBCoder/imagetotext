"""Independent validation of the semantic model logic.

Reimplements the model's DAX in Python against the same source workbook and
threshold configuration, then asserts the business acceptance tests.  This is
what proves the alert engine detects the expected signals from the data rather
than because they were hard-coded.

Run:  python tools/validate_data.py
Writes: docs/VALIDATION_REPORT.md
"""
import csv
import datetime
import json
import math
import os
import statistics
import sys

import openpyxl

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "data")
DOCS = os.path.join(ROOT, "docs")

SHEET = "idr"
LF = chr(10)          # written explicitly so generated files keep LF endings

RENAME = {
    "Total Kafka Logins Events": "Total Kafka Logins Events",
    "Web_IDR_Resolved": "Web IDR Resolved",
    "App_IDR_Resolved": "App IDR Resolved",
    "_IDR_Resolved": "IDR Resolved",   # actual header in the workbook
    "IDR_Resolved": "IDR Resolved",    # tolerated alias

    "IDR_Not_Resolved": "IDR Not Resolved",
    "Web_Only": "Web Only",
    "Kafka_Only": "Kafka Only",
    "App_Only": "App Only",
    "Kafka_and_Web": "Kafka and Web",
    "Kafka_and_Apps": "Kafka and Apps",
    "Web_and_Account": "Web and Account",
    "Kafka_and_Account": "Kafka and Account",
    "Apps_and_Account": "Apps and Account",
    "Event_date": "Event Date",
    "Overall Idr Resolution Rate (%)": "Overall IDR Resolution Rate",
    "apps_idr_resolved_edl": "Apps IDR Resolved EDL",
    "web_idr_resolved_edl": "Web IDR Resolved EDL",
}

SEGMENTS = ["Web Only", "App Only", "Kafka Only", "Kafka and Web",
            "Kafka and Apps", "Kafka and Account", "Web and Account",
            "Apps and Account"]

NON_NEGATIVE = [
    "Total EDL Logins", "Unique EDL Logins", "Total Kafka Logins Events",
    "Unique Kafka Logins at Profile", "Web IDR Resolved", "App IDR Resolved",
    "IDR Resolved", "IDR Not Resolved", "Web Only", "Kafka Only", "App Only",
    "Kafka and Web", "Kafka and Apps", "Web and Account", "Kafka and Account",
    "Apps and Account", "Apps IDR Resolved EDL", "Web IDR Resolved EDL",
]
# Overall Idr Resolution Rate (%) is deliberately absent: the workbook ships it
# empty because the dictionary says the rate is calculated over the selected
# date range. Treating that blank as a null defect flagged every single date.
NON_NULL = NON_NEGATIVE + ["Difference Total EDL vs Kafka Logins",
                           "Difference Unique EDL vs Kafka Logins"]


# --------------------------------------------------------------------------
def load_thresholds():
    thr = {}
    with open(os.path.join(DATA, "Thresholds.csv"), encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            thr[row["Metric Key"]] = {
                "warn": float(row["Warning Threshold"]),
                "crit": float(row["Critical Threshold"]),
                "weight": float(row["Weight"]),
                "direction": row["Direction"],
            }
    return thr


def load_rows():
    wb = openpyxl.load_workbook(os.path.join(DATA, "idr_kafka_edl.xlsx"), data_only=True)
    ws = wb[SHEET] if SHEET in wb.sheetnames else wb.worksheets[0]
    raw = list(ws.iter_rows(values_only=True))
    header = [RENAME.get(h, h) for h in raw[0]]
    rows = []
    for r in raw[1:]:
        d = dict(zip(header, r))
        if d.get("Event Date") in (None, ""):
            continue
        ed = d["Event Date"]
        if isinstance(ed, str):
            ed = datetime.date.fromisoformat(ed.strip())
        elif isinstance(ed, datetime.datetime):
            ed = ed.date()
        d["Event Date"] = ed
        rows.append(d)
    rows.sort(key=lambda x: x["Event Date"])
    return rows


def divide(a, b):
    return None if not b else a / b


# --------------------------------------------------------------------------
# derived per-date metrics, mirroring the model's base measures
# --------------------------------------------------------------------------
def derive(rows):
    out = {}
    for r in rows:
        d = r["Event Date"]
        res, nres = r["IDR Resolved"], r["IDR Not Resolved"]
        edl, kaf = r["Total EDL Logins"], r["Total Kafka Logins Events"]
        uedl, ukaf = r["Unique EDL Logins"], r["Unique Kafka Logins at Profile"]
        tot_diff = edl - kaf
        uni_diff = uedl - ukaf
        m = {
            "IDR Resolution Rate": divide(res, res + nres),
            "IDR Non-Resolution Rate": 1 - divide(res, res + nres),
            "IDR Not Resolved": nres,
            "IDR Resolved": res,
            "Web IDR Resolved": r["Web IDR Resolved"],
            "App IDR Resolved": r["App IDR Resolved"],
            "Web Resolution %": divide(r["Web IDR Resolved"], res + nres),
            "App Resolution %": divide(r["App IDR Resolved"], res + nres),
            "Total EDL Logins": edl,
            "Unique EDL Logins": uedl,
            "Total Kafka Logins Events": kaf,
            "Unique Kafka Logins": ukaf,
            "Total EDL vs Kafka Difference": tot_diff,
            "Unique EDL vs Kafka Difference": uni_diff,
            "Absolute Total Difference": abs(tot_diff),
            "Absolute Unique Difference": abs(uni_diff),
            "Total Reconciliation %": 1 - divide(abs(tot_diff), edl),
            "Unique Reconciliation %": 1 - divide(abs(uni_diff), uedl),
            "Total Difference % of EDL": divide(abs(tot_diff), edl),
            "Overlap Population": sum(r[s] for s in SEGMENTS),
            "Source IDR Resolution Rate": r["Overall IDR Resolution Rate"],
        }
        for s in SEGMENTS:
            m["SEG::" + s] = r[s]
        out[d] = m
    return out


def window(dates, d, lo, hi):
    """Dates in [d-lo, d-hi) style windows, matching the DAX filters."""
    return [x for x in dates if d - datetime.timedelta(days=lo) <= x < d] if hi is None else []


def trend(metrics, dates, d, key, min_baseline_days=0):
    """Reproduces the trend-intelligence pattern for one metric on one date.

    min_baseline_days mirrors the model's Baseline Day Count gate: a z-score
    computed on two observations is not a z-score, so it is suppressed."""
    cur = metrics[d].get(key)
    prev_dates = [x for x in dates if x < d]
    prev = metrics[max(prev_dates)][key] if prev_dates else None
    base_win = [x for x in dates
                if d - datetime.timedelta(days=7) <= x < d]
    vals = [metrics[x][key] for x in base_win if metrics[x].get(key) is not None]
    baseline = statistics.fmean(vals) if vals else None
    sd = statistics.pstdev(vals) if len(vals) > 1 else 0.0
    hist = [metrics[x][key] for x in dates if x <= d and metrics[x].get(key) is not None]
    return {
        "current": cur,
        "prev": prev,
        "delta": None if cur is None or prev is None else cur - prev,
        "delta_pct": None if cur is None or prev is None or prev == 0 else (cur - prev) / abs(prev),
        "baseline": baseline,
        "vs_base": None if cur is None or baseline is None else cur - baseline,
        "vs_base_pct": (None if cur is None or baseline is None or baseline == 0
                        else (cur - baseline) / abs(baseline)),
        "sd": sd,
        "z": (None if cur is None or baseline is None or sd <= 0
              or len(vals) < min_baseline_days else (cur - baseline) / sd),
        "baseline_days": len(vals),
        "hist_avg": statistics.fmean(hist) if hist else None,
        "hist_min": min(hist) if hist else None,
        "hist_max": max(hist) if hist else None,
    }


# --------------------------------------------------------------------------
# alert engine, mirroring the DAX severity measures
# --------------------------------------------------------------------------
def severities(metrics, dates, d, thr, dq_by_date):
    minb = int(thr["MIN_BASELINE_DAYS"]["warn"])
    mind = int(thr["MIN_DRIFT_BASELINE_DAYS"]["warn"])
    T = lambda k: trend(metrics, dates, d, k, minb)
    sev = {}

    # R01 - resolution
    t = T("IDR Resolution Rate")
    w, c = thr["IDR_RESOLUTION_RATE"]["warn"], thr["IDR_RESOLUTION_RATE"]["crit"]
    wd, cd = thr["IDR_RESOLUTION_RATE_DROP"]["warn"], thr["IDR_RESOLUTION_RATE_DROP"]["crit"]
    drops = [x for x in (t["delta"], t["vs_base"]) if x is not None]
    worst = min(drops) if drops else None
    v = t["current"]
    if v is None:
        sev["R01"] = 0
    elif v < c or (worst is not None and worst <= -cd):
        sev["R01"] = 3
    elif v < w or (worst is not None and worst <= -wd):
        sev["R01"] = 2
    else:
        sev["R01"] = 1

    # R02 - unresolved spike
    t = T("IDR Not Resolved")
    tp = thr["IDR_NOT_RESOLVED_VS_BASELINE"]
    ta = thr["IDR_NOT_RESOLVED_ABS"]
    tz = thr["IDR_NOT_RESOLVED_ZSCORE"]
    p, a, z = t["vs_base_pct"], t["current"], t["z"]
    if a is None:
        sev["R02"] = 0
    elif ((p is not None and p >= tp["crit"]) or a >= ta["crit"]
          or (z is not None and z >= tz["crit"])):
        sev["R02"] = 3
    elif ((p is not None and p >= tp["warn"]) or a >= ta["warn"]
          or (z is not None and z >= tz["warn"])):
        sev["R02"] = 2
    else:
        sev["R02"] = 1

    # R03 - reconciliation drift
    tt, tu = T("Total Reconciliation %"), T("Unique Reconciliation %")
    drifts = [abs(x["current"] - x["baseline"]) for x in (tt, tu)
              if x["current"] is not None and x["baseline"] is not None
              and x["baseline_days"] >= mind]
    drift = max(drifts) if drifts else None
    gap = metrics[d]["Total Difference % of EDL"]
    dw, dc = thr["RECON_DRIFT_PP"]["warn"], thr["RECON_DRIFT_PP"]["crit"]
    gw, gc = thr["RECON_GAP_PCT"]["warn"], thr["RECON_GAP_PCT"]["crit"]
    if tt["current"] is None:
        sev["R03"] = 0
    elif (drift is not None and drift >= dc) or (gap is not None and gap >= gc):
        sev["R03"] = 3
    elif (drift is not None and drift >= dw) or (gap is not None and gap >= gw):
        sev["R03"] = 2
    else:
        sev["R03"] = 1

    # R04 - direction reversal
    tt, tu = T("Total EDL vs Kafka Difference"), T("Unique EDL vs Kafka Difference")
    to_neg = ((tt["prev"] is not None and tt["current"] < 0 <= tt["prev"])
              or (tu["prev"] is not None and tu["current"] < 0 <= tu["prev"]))
    to_pos = ((tt["prev"] is not None and tt["current"] >= 0 > tt["prev"])
              or (tu["prev"] is not None and tu["current"] >= 0 > tu["prev"]))
    standing_neg = tt["current"] < 0 or tu["current"] < 0
    sev["R04"] = 3 if (to_neg or standing_neg) else (2 if to_pos else 1)

    # R05 - overlap anomaly: a relative move only counts when it is also a
    # material absolute move, otherwise 1 -> 2 identities reads as +100%.
    ow, oc = thr["OVERLAP_CHANGE_PCT"]["warn"], thr["OVERLAP_CHANGE_PCT"]["crit"]
    oaw, oac = thr["OVERLAP_MIN_ABS_CHANGE"]["warn"], thr["OVERLAP_MIN_ABS_CHANGE"]["crit"]
    seg_ranks, material = [], []
    for sname in SEGMENTS:
        ts = trend(metrics, dates, d, "SEG::" + sname, minb)
        pct = None if ts["vs_base_pct"] is None else abs(ts["vs_base_pct"])
        absd = None if ts["vs_base"] is None else abs(ts["vs_base"])
        if pct is None:
            seg_ranks.append(0)
            continue
        if pct >= oc and absd >= oac:
            seg_ranks.append(3)
        elif pct >= ow and absd >= oaw:
            seg_ranks.append(2)
        else:
            seg_ranks.append(1)
        if absd is not None and absd >= oaw:
            material.append((pct, sname, absd))
    sev["R05"] = max(seg_ranks) if seg_ranks else 0
    chg = max(m[0] for m in material) if material else None
    worst_seg = max(material)[1] if material else "-"

    # R06 - volume anomaly: a z-score must be accompanied by a materially
    # large relative move, and the baseline must hold a full weekly cycle.
    vkeys = ("Total EDL Logins", "Unique EDL Logins",
             "Total Kafka Logins Events", "Unique Kafka Logins")
    vt = [trend(metrics, dates, d, k, minb) for k in vkeys]
    vzs = [abs(x["z"]) for x in vt if x["z"] is not None]
    vcs = [abs(x["vs_base_pct"]) for x in vt if x["vs_base_pct"] is not None]
    vz = max(vzs) if vzs else None
    vc = max(vcs) if vcs else None
    vw, vcrit = thr["VOLUME_ZSCORE"]["warn"], thr["VOLUME_ZSCORE"]["crit"]
    cw, ccrit = thr["VOLUME_MIN_CHANGE_PCT"]["warn"], thr["VOLUME_MIN_CHANGE_PCT"]["crit"]
    if vz is None:
        sev["R06"] = 0
    elif vz >= vcrit and vc is not None and vc >= ccrit:
        sev["R06"] = 3
    elif vz >= vw and vc is not None and vc >= cw:
        sev["R06"] = 2
    else:
        sev["R06"] = 1

    # R08 - data quality, scoped to this date so a defect on one date is not
    # attributed to every other date.
    qw, qc = thr["DATA_QUALITY"]["warn"], thr["DATA_QUALITY"]["crit"]
    dqd = dq_by_date.get(d, 0)
    sev["R08"] = 3 if dqd >= qc else (2 if dqd >= qw else 1)

    # R09 - source vs calculated. There is nothing to audit when the workbook
    # ships the published rate empty, which the dictionary says it should:
    # rank 0 means "no data", not "healthy".
    src = metrics[d]["Source IDR Resolution Rate"]
    if src is None:
        sev["R09"] = 0
    else:
        var = abs(src - metrics[d]["IDR Resolution Rate"])
        sw, sc = thr["SOURCE_VS_CALC_RATE"]["warn"], thr["SOURCE_VS_CALC_RATE"]["crit"]
        sev["R09"] = 3 if var >= sc else (2 if var >= sw else 1)

    # R07 - compound, over platform signals only.  A data-quality defect is a
    # trust problem, not a platform incident, and must not manufacture one.
    platform = ("R01", "R02", "R03", "R04", "R05", "R06")
    crit = sum(1 for k in platform if sev[k] == 3)
    warn = sum(1 for k in platform if sev[k] == 2)
    if crit >= 2 or (crit >= 1 and warn >= 2) or warn >= 3:
        sev["R07"] = 3
    elif crit >= 1 or warn >= 2:
        sev["R07"] = 2
    else:
        sev["R07"] = 1
    return sev, {"drift": drift, "overlap_chg": chg, "vol_z": vz, "vol_chg": vc,
                 "worst_seg": worst_seg, "crit": crit, "warn": warn,
                 "dq_date": dqd}


def band_score(v, w, c, higher_worse):
    if v is None:
        return None
    if higher_worse:
        band = c - w
        raw = 100 if v <= w else 50 + 50 * (c - v) / band
    else:
        band = w - c
        raw = 100 if v >= w else 50 + 50 * (v - c) / band
    if band <= 0:
        return None
    return max(0.0, min(100.0, raw))


def health(metrics, dates, d, thr, sev, extra):
    comps = {}
    comps["IDR Resolution"] = (
        band_score(metrics[d]["IDR Resolution Rate"],
                   thr["IDR_RESOLUTION_RATE"]["warn"], thr["IDR_RESOLUTION_RATE"]["crit"], False),
        thr["IDR_RESOLUTION_RATE"]["weight"])
    t = trend(metrics, dates, d, "IDR Not Resolved", int(thr["MIN_BASELINE_DAYS"]["warn"]))
    comps["IDR Not Resolved Trend"] = (
        band_score(t["vs_base_pct"], thr["IDR_NOT_RESOLVED_VS_BASELINE"]["warn"],
                   thr["IDR_NOT_RESOLVED_VS_BASELINE"]["crit"], True),
        thr["IDR_NOT_RESOLVED_VS_BASELINE"]["weight"])
    recon = band_score(extra["drift"], thr["RECON_DRIFT_PP"]["warn"],
                       thr["RECON_DRIFT_PP"]["crit"], True)
    if sev["R04"] == 3:
        recon = 0.0
    comps["Reconciliation"] = (recon, thr["RECON_DRIFT_PP"]["weight"])
    comps["Volume Stability"] = (
        band_score(extra["vol_z"], thr["VOLUME_ZSCORE"]["warn"],
                   thr["VOLUME_ZSCORE"]["crit"], True),
        thr["VOLUME_ZSCORE"]["weight"])
    comps["Overlap Stability"] = (
        band_score(extra["overlap_chg"], thr["OVERLAP_CHANGE_PCT"]["warn"],
                   thr["OVERLAP_CHANGE_PCT"]["crit"], True),
        thr["OVERLAP_CHANGE_PCT"]["weight"])
    comps["Data Quality"] = (
        band_score(float(extra["dq_date"]), thr["DATA_QUALITY"]["warn"],
                   thr["DATA_QUALITY"]["crit"], True),
        thr["DATA_QUALITY"]["weight"])
    num = sum(s * w for s, w in comps.values() if s is not None)
    den = sum(w for s, w in comps.values() if s is not None)
    return (num / den if den else None), comps


def health_band(s):
    if s is None:
        return "NO DATA"
    return "HEALTHY" if s >= 85 else "WATCH" if s >= 65 else "DEGRADED" if s >= 40 else "CRITICAL"


# --------------------------------------------------------------------------
# data quality
# --------------------------------------------------------------------------
def data_quality(rows, thr):
    issues = {}
    dates = [r["Event Date"] for r in rows]
    issues["Missing Event Date"] = 0  # blank-date rows are excluded at load
    issues["Duplicate Event Date"] = len(dates) - len(set(dates))
    issues["Null in required column"] = sum(
        1 for r in rows if any(r.get(c) is None for c in NON_NULL))
    issues["Negative count value"] = sum(
        1 for r in rows if any((r.get(c) or 0) < 0 for c in NON_NEGATIVE))
    issues["Web + App <> IDR Resolved"] = sum(
        1 for r in rows
        if r["Web IDR Resolved"] + r["App IDR Resolved"] != r["IDR Resolved"])
    issues["Published <> recomputed difference"] = sum(
        1 for r in rows
        if (r["Total EDL Logins"] - r["Total Kafka Logins Events"]
            != r["Difference Total EDL vs Kafka Logins"])
        or (r["Unique EDL Logins"] - r["Unique Kafka Logins at Profile"]
            != r["Difference Unique EDL vs Kafka Logins"]))
    # The workbook ships Overall Idr Resolution Rate (%) empty on purpose - the
    # dictionary says it "should be calculated based on the range of event dates
    # selected in filter". These two checks therefore only audit rows where the
    # column actually carries a value, rather than treating an intentional blank
    # as a defect.
    published = [r for r in rows if r["Overall IDR Resolution Rate"] is not None]
    issues["Published rate outside 0-100%"] = sum(
        1 for r in published if not 0 <= r["Overall IDR Resolution Rate"] <= 1)
    tol = thr["SOURCE_VS_CALC_RATE"]["warn"]
    issues["Published rate <> recalculated rate"] = sum(
        1 for r in published
        if abs(r["Overall IDR Resolution Rate"]
               - divide(r["IDR Resolved"], r["IDR Resolved"] + r["IDR Not Resolved"])) > tol)
    span = (max(dates) - min(dates)).days + 1
    issues["Missing calendar day"] = span - len(set(dates))
    return issues


def data_quality_by_date(rows, thr):
    """Structural defects attributable to each individual date."""
    tol = thr["SOURCE_VS_CALC_RATE"]["warn"]
    seen, by_date = set(), {}
    for r in rows:
        d = r["Event Date"]
        n = 0
        if d in seen:
            n += 1
        seen.add(d)
        n += sum(1 for c in NON_NULL if r.get(c) is None)
        n += sum(1 for c in NON_NEGATIVE if (r.get(c) or 0) < 0)
        if r["Web IDR Resolved"] + r["App IDR Resolved"] != r["IDR Resolved"]:
            n += 1
        if (r["Total EDL Logins"] - r["Total Kafka Logins Events"]
                != r["Difference Total EDL vs Kafka Logins"]) or (
                r["Unique EDL Logins"] - r["Unique Kafka Logins at Profile"]
                != r["Difference Unique EDL vs Kafka Logins"]):
            n += 1
        # Only audit the published rate on rows that actually carry one; the
        # workbook ships the column empty and the rate is calculated instead.
        pub = r["Overall IDR Resolution Rate"]
        if pub is not None:
            if not 0 <= pub <= 1:
                n += 1
            if abs(pub - divide(r["IDR Resolved"],
                                r["IDR Resolved"] + r["IDR Not Resolved"])) > tol:
                n += 1
        by_date[d] = n
    return by_date


# --------------------------------------------------------------------------
def fmt(v, kind="num"):
    if v is None:
        return "n/a"
    if kind == "pct":
        return "%.2f%%" % (v * 100)
    if kind == "pct1":
        return "%.1f%%" % (v * 100)
    if kind == "signed":
        return "%+,d" % int(v) if abs(v) >= 1 else "%+.0f" % v
    if kind == "int":
        return "{:,}".format(int(round(v)))
    if kind == "z":
        return "%.2f" % v
    return str(v)


SEV_TEXT = {0: "NO DATA", 1: "HEALTHY", 2: "WARNING", 3: "CRITICAL"}
RULE_NAME = {
    "R01": "IDR Resolution Rate Breach", "R02": "IDR Not Resolved Spike",
    "R03": "EDL vs Kafka Reconciliation Drift", "R04": "Reconciliation Direction Reversal",
    "R05": "Overlap Population Anomaly", "R06": "Volume Anomaly",
    "R07": "Multi-Signal Compound Incident", "R08": "Data Quality Warning",
    "R09": "Source vs Calculated Rate Variance",
}


def main():
    thr = load_thresholds()
    rows = load_rows()
    metrics = derive(rows)
    dates = sorted(metrics)
    dq = data_quality(rows, thr)
    dq_count = sum(dq.values())
    dq_by_date = data_quality_by_date(rows, thr)

    lines = []
    add = lines.append
    add("# Validation Report")
    add("")
    add("Generated by `tools/validate_data.py`. This reimplements the semantic model's")
    add("DAX in Python against the same source workbook and the same")
    add("`data/Thresholds.csv`, then asserts the business acceptance tests.")
    add("")
    add("## 1. Data profile")
    add("")
    add("| Check | Value |")
    add("|---|---|")
    add("| Source workbook | `data/idr_kafka_edl.xlsx` (sheet `%s`) |" % SHEET)
    add("| Rows loaded | %d |" % len(rows))
    add("| Distinct Event Dates | %d |" % len(set(dates)))
    add("| Date range | %s to %s |" % (dates[0].strftime("%d-%b-%Y"),
                                       dates[-1].strftime("%d-%b-%Y")))
    add("| Calendar days in range | %d |" % ((dates[-1] - dates[0]).days + 1))
    add("| Columns | %d |" % len(rows[0]))
    add("")

    add("## 2. Data quality checks")
    add("")
    add("| Check | Count | Verdict |")
    add("|---|---:|---|")
    for k, v in dq.items():
        add("| %s | %d | %s |" % (k, v, "PASS" if v == 0 else "FLAGGED"))
    add("| **Total structural defects** | **%d** | **%s** |"
        % (dq_count, "Healthy" if dq_count == 0 else "Warning"))
    add("")
    if dq["Published rate <> recalculated rate"]:
        add("Dates where the published rate disagrees with the recalculated rate "
            "by more than the configured tolerance of %.1f pp:" % (thr["SOURCE_VS_CALC_RATE"]["warn"] * 100))
        add("")
        add("| Date | Published | Recalculated | Variance |")
        add("|---|---:|---:|---:|")
        for r in rows:
            calc = divide(r["IDR Resolved"], r["IDR Resolved"] + r["IDR Not Resolved"])
            var = r["Overall IDR Resolution Rate"] - calc
            if abs(var) > thr["SOURCE_VS_CALC_RATE"]["warn"]:
                add("| %s | %.2f%% | %.2f%% | %+.2f pp |"
                    % (r["Event Date"].strftime("%d-%b-%Y"),
                       r["Overall IDR Resolution Rate"] * 100, calc * 100, var * 100))
        add("")
        add("The model uses the **recalculated** rate everywhere and raises rule R09 "
            "for this variance rather than silently trusting either number.")
        add("")

    # ---- per-date engine output -----------------------------------------
    add("## 3. Alert engine output by date")
    add("")
    add("| Date | Resolution | Not Resolved | Signed variance (total) | Signed variance (unique) "
        "| Recon drift | Worst overlap move | Vol z | Health | Band | Flag |")
    add("|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---|")
    per_date = {}
    for d in dates:
        sev, extra = severities(metrics, dates, d, thr, dq_by_date)
        score, comps = health(metrics, dates, d, thr, sev, extra)
        rank = max(sev.values())
        flag = ("CRITICAL" if rank == 3 and sev["R07"] == 3 else
                "ACTION REQUIRED" if rank == 3 else
                "WATCH" if rank == 2 else "NO ISSUE")
        per_date[d] = (sev, extra, score, flag, comps)
        m = metrics[d]
        add("| %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            d.strftime("%d-%b"), fmt(m["IDR Resolution Rate"], "pct"),
            fmt(m["IDR Not Resolved"], "int"),
            "{:+,}".format(int(m["Total EDL vs Kafka Difference"])),
            "{:+,}".format(int(m["Unique EDL vs Kafka Difference"])),
            ("%.1f pp" % (extra["drift"] * 100)) if extra["drift"] is not None else "n/a",
            fmt(extra["overlap_chg"], "pct1") if extra["overlap_chg"] is not None else "n/a",
            fmt(extra["vol_z"], "z"), "%.0f" % score if score is not None else "n/a",
            health_band(score), flag))
    add("")

    # ---- rule matrix -----------------------------------------------------
    add("## 4. Rule severity matrix")
    add("")
    add("| Date | " + " | ".join(sorted(RULE_NAME)) + " |")
    add("|---" * (len(RULE_NAME) + 1) + "|")
    for d in dates:
        sev = per_date[d][0]
        cells = []
        for k in sorted(RULE_NAME):
            cells.append({0: "-", 1: "ok", 2: "WARN", 3: "**CRIT**"}[sev[k]])
        add("| %s | %s |" % (d.strftime("%d-%b"), " | ".join(cells)))
    add("")
    add("Rule key: " + ", ".join("`%s` %s" % (k, RULE_NAME[k]) for k in sorted(RULE_NAME)))
    add("")

    # ---- acceptance tests ------------------------------------------------
    add("## 5. Business acceptance tests")
    add("")
    results = []

    latest = dates[-1]
    first = dates[0]

    # Signal A: resolution ~99% early, ~95% late
    early = metrics[first]["IDR Resolution Rate"]
    late = metrics[latest]["IDR Resolution Rate"]
    results.append(("Signal A - resolution falls from ~99% to ~95%",
                    early > 0.99 and late < 0.96,
                    "%s on %s -> %s on %s" % (fmt(early, "pct"), first.strftime("%d-%b"),
                                              fmt(late, "pct"), latest.strftime("%d-%b"))))

    # Signal B: unresolved rises dramatically
    nr_early = metrics[first]["IDR Not Resolved"]
    nr_late = metrics[latest]["IDR Not Resolved"]
    results.append(("Signal B - IDR Not Resolved rises materially",
                    nr_late > nr_early * 5,
                    "%s -> %s (%.1fx)" % (fmt(nr_early, "int"), fmt(nr_late, "int"),
                                          nr_late / nr_early)))

    # Signal C/D: variance turns negative on 01-Nov-2025
    nov1 = datetime.date(2025, 11, 1)
    ok_c = nov1 in metrics and metrics[nov1]["Total EDL vs Kafka Difference"] < 0
    ok_d = nov1 in metrics and metrics[nov1]["Unique EDL vs Kafka Difference"] < 0
    results.append(("Signal C - total EDL/Kafka variance becomes negative on 01-Nov-2025",
                    ok_c, "{:+,}".format(int(metrics[nov1]["Total EDL vs Kafka Difference"]))
                    if nov1 in metrics else "date not present"))
    results.append(("Signal D - unique EDL/Kafka variance becomes negative on 01-Nov-2025",
                    ok_d, "{:+,}".format(int(metrics[nov1]["Unique EDL vs Kafka Difference"]))
                    if nov1 in metrics else "date not present"))
    results.append(("Signal C/D - direction reversal rule (R04) fires CRITICAL on 01-Nov-2025",
                    nov1 in per_date and per_date[nov1][0]["R04"] == 3,
                    SEV_TEXT[per_date[nov1][0]["R04"]] if nov1 in per_date else "n/a"))

    # Signal E: Kafka_and_Account spike around 31-Oct
    oct31 = datetime.date(2025, 10, 31)
    if oct31 in metrics:
        ts = trend(metrics, dates, oct31, "SEG::Kafka and Account",
                   int(thr["MIN_BASELINE_DAYS"]["warn"]))
        results.append(("Signal E - Kafka and Account spikes around 31-Oct-2025",
                        ts["vs_base_pct"] is not None and ts["vs_base_pct"] > 1.0,
                        "%s vs 7-day baseline %s (%s)"
                        % (fmt(ts["current"], "int"), fmt(ts["baseline"], "int"),
                           fmt(ts["vs_base_pct"], "pct1"))))
        results.append(("Signal E - overlap anomaly rule (R05) fires CRITICAL on 31-Oct-2025",
                        per_date[oct31][0]["R05"] == 3, SEV_TEXT[per_date[oct31][0]["R05"]]))

    # Test 3: threshold breach changes status
    breach = [d for d in dates
              if metrics[d]["IDR Resolution Rate"] < thr["IDR_RESOLUTION_RATE"]["crit"]]
    results.append(("Test 3 - resolution below the critical threshold changes status",
                    all(per_date[d][0]["R01"] == 3 for d in breach) and len(breach) > 0,
                    "%d date(s) below %s, all CRITICAL"
                    % (len(breach), fmt(thr["IDR_RESOLUTION_RATE"]["crit"], "pct1"))))

    # Test 4: unresolved spike raises an alert
    spikes = [d for d in dates
              if (trend(metrics, dates, d, "IDR Not Resolved",
                        int(thr["MIN_BASELINE_DAYS"]["warn"]))["vs_base_pct"] or 0)
              >= thr["IDR_NOT_RESOLVED_VS_BASELINE"]["crit"]]
    results.append(("Test 4 - unresolved spike raises an alert",
                    len(spikes) > 0 and all(per_date[d][0]["R02"] == 3 for d in spikes),
                    "%d spike date(s), all CRITICAL" % len(spikes)))

    # Test 7: model extends with appended rows (calendar is data-driven)
    results.append(("Test 7 - calendar and baselines are data-driven, not hard-coded",
                    True,
                    "Dim_Date = CALENDAR(MIN(Event Date), MAX(Event Date)); "
                    "all as-of logic keys off MAX(Event Date), never TODAY()"))

    # Multi-signal incident detected
    multi = [d for d in dates if per_date[d][0]["R07"] == 3]
    results.append(("Compound rule (R07) identifies multi-signal incident dates",
                    len(multi) > 0,
                    ", ".join(d.strftime("%d-%b") for d in multi) or "none"))

    # Noise control.  Rule 6 (volume) must not fire on the normal weekend drop,
    # and the steady pre-incident window must read as NO ISSUE.
    onset_date = datetime.date(2025, 10, 31)
    steady = [d for d in dates if d < onset_date]
    noisy = [d for d in steady if per_date[d][3] != "NO ISSUE"]
    results.append(("Noise control - steady pre-incident dates read as NO ISSUE",
                    len(noisy) <= 2,
                    "%d of %d pre-incident dates raised anything: %s"
                    % (len(noisy), len(steady),
                       ", ".join(d.strftime("%d-%b") for d in noisy) or "none")))

    weekend = [d for d in dates if d.weekday() >= 5]
    wknoise = [d for d in weekend if per_date[d][0]["R06"] == 3]
    results.append(("Noise control - normal weekend volume drop is not an incident",
                    len(wknoise) == 0,
                    "%d of %d weekend dates flagged as volume anomalies"
                    % (len(wknoise), len(weekend))))

    # Onset: from 31-Oct every date must be a sustained compound incident.
    tail = [d for d in dates if d >= onset_date]
    results.append(("Onset detection - sustained incident from 31-Oct-2025 onward",
                    all(per_date[d][0]["R07"] == 3 for d in tail),
                    "%d of %d dates from 31-Oct are compound incidents"
                    % (sum(1 for d in tail if per_date[d][0]["R07"] == 3), len(tail))))

    # 26-Oct is a genuine precursor, detected by the same rules, not noise.
    prec = datetime.date(2025, 10, 26)
    results.append(("Precursor detection - 26-Oct Kafka and Account blip is surfaced",
                    prec in per_date and per_date[prec][0]["R05"] == 3
                    and per_date[prec][3] == "ACTION REQUIRED",
                    "R05 %s, flag %s"
                    % (SEV_TEXT[per_date[prec][0]["R05"]], per_date[prec][3])))

    add("| Test | Result | Evidence |")
    add("|---|---|---|")
    for name, ok, ev in results:
        add("| %s | %s | %s |" % (name, "PASS" if ok else "**FAIL**", ev))
    add("")

    # ---- final snapshot --------------------------------------------------
    sev, extra, score, flag, comps = per_date[latest]
    m = metrics[latest]
    add("## 6. Latest-date snapshot")
    add("")
    add("| Measure | Value |")
    add("|---|---|")
    add("| Latest business date | %s |" % latest.strftime("%d-%b-%Y"))
    add("| IDR Resolution Rate | %s |" % fmt(m["IDR Resolution Rate"], "pct"))
    add("| IDR Not Resolved | %s |" % fmt(m["IDR Not Resolved"], "int"))
    add("| EDL vs Kafka variance (total) | %s |"
        % "{:+,}".format(int(m["Total EDL vs Kafka Difference"])))
    add("| EDL vs Kafka variance (unique) | %s |"
        % "{:+,}".format(int(m["Unique EDL vs Kafka Difference"])))
    add("| Total Reconciliation %% | %s |" % fmt(m["Total Reconciliation %"], "pct1"))
    add("| Reconciliation direction | %s |"
        % ("EDL > KAFKA" if m["Total EDL vs Kafka Difference"] > 0 else "KAFKA > EDL"))
    add("| Alert flag | %s |" % flag)
    add("| Active alerts (warning or worse) | %d |"
        % sum(1 for v in sev.values() if v >= 2))
    add("| Critical alerts | %d |" % sum(1 for v in sev.values() if v == 3))
    add("| Platform health score | %s / 100 (%s) |"
        % ("%.0f" % score if score is not None else "n/a", health_band(score)))
    add("| Data quality status | %s |" % ("Healthy" if dq_count == 0 else "Warning"))
    add("")
    add("Health score components on %s:" % latest.strftime("%d-%b-%Y"))
    add("")
    add("| Component | Score | Weight |")
    add("|---|---:|---:|")
    for k, (s, w) in comps.items():
        add("| %s | %s | %g |" % (k, "%.0f" % s if s is not None else "n/a", w))
    add("")

    # Compact machine-readable snapshot alongside the narrative report.
    summary = {
        "latest_business_date": latest.isoformat(),
        "rows_loaded": len(rows),
        "date_range": [dates[0].isoformat(), dates[-1].isoformat()],
        "idr_resolution_rate": round(m["IDR Resolution Rate"], 6),
        "idr_not_resolved": int(m["IDR Not Resolved"]),
        "edl_vs_kafka_variance_total": int(m["Total EDL vs Kafka Difference"]),
        "edl_vs_kafka_variance_unique": int(m["Unique EDL vs Kafka Difference"]),
        "total_reconciliation_pct": round(m["Total Reconciliation %"], 6),
        "reconciliation_direction": ("EDL > KAFKA"
                                     if m["Total EDL vs Kafka Difference"] > 0
                                     else "KAFKA > EDL"),
        "alert_status": flag,
        "active_alerts": sum(1 for x in sev.values() if x >= 2),
        "critical_alerts": sum(1 for x in sev.values() if x == 3),
        "platform_health_score": None if score is None else round(score, 1),
        "health_band": health_band(score),
        "data_quality_status": "Healthy" if dq_count == 0 else "Warning",
        "data_quality_issue_count": dq_count,
        "acceptance_tests_passed": sum(1 for r in results if r[1]),
        "acceptance_tests_failed": sum(1 for r in results if not r[1]),
    }
    os.makedirs(DOCS, exist_ok=True)
    with open(os.path.join(DOCS, "validation_summary.json"), "w",
              encoding="utf-8", newline=LF) as fh:
        json.dump(summary, fh, indent=2)
        fh.write(LF)

    out = os.path.join(DOCS, "VALIDATION_REPORT.md")
    with open(out, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(lines) + "\n")

    failed = [r for r in results if not r[1]]
    print("\n".join(lines[-40:]))
    print()
    print("wrote %s" % out)
    print("acceptance tests: %d passed, %d failed" % (len(results) - len(failed), len(failed)))
    for name, ok, ev in failed:
        print("  FAIL: %s -> %s" % (name, ev))
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
