"""Threshold lookups, alert engine, health score, data quality and narrative
measures for the IDR Executive Monitoring semantic model."""

from model_measures import (M, F_COUNT, F_COUNT_SIGNED, F_PCT, F_PCT2, F_PCT_SIGNED,
                            F_PP, F_SCORE, F_Z, F_INT,
                            FLD_EXEC, FLD_IDR, FLD_RECON, FLD_VOL, FLD_OVR,
                            FLD_ALERT, FLD_DQ, FLD_CFG, FLD_HEALTH, FLD_NARR, FLD_UX)

# --------------------------------------------------------------------------
# semantic colour palette - single source of truth for status colour in DAX
# --------------------------------------------------------------------------
C_GREEN = "#24C38E"
C_AMBER = "#F5A623"
C_RED = "#FF4D5E"
C_NEUTRAL = "#6B7B93"
C_BLUE = "#3E8BFF"

THRESHOLD_KEYS = [
    "IDR_RESOLUTION_RATE", "IDR_RESOLUTION_RATE_DROP", "IDR_NOT_RESOLVED_VS_BASELINE",
    "IDR_NOT_RESOLVED_ABS", "IDR_NOT_RESOLVED_ZSCORE", "RECON_DRIFT_PP", "RECON_GAP_PCT",
    "RECON_DIRECTION", "VOLUME_ZSCORE", "OVERLAP_CHANGE_PCT", "OVERLAP_ZSCORE",
    "DATA_QUALITY", "SOURCE_VS_CALC_RATE", "MIN_BASELINE_DAYS",
    "MIN_DRIFT_BASELINE_DAYS", "OVERLAP_MIN_ABS_CHANGE", "VOLUME_MIN_CHANGE_PCT",
]

# rules: key, name, category, priority (1 = most urgent)
ALERT_RULES = [
    ("R07", "Multi-Signal Compound Incident", "Compound", 1),
    ("R01", "IDR Resolution Rate Breach", "IDR", 2),
    ("R02", "IDR Not Resolved Spike", "IDR", 3),
    ("R04", "Reconciliation Direction Reversal", "Reconciliation", 4),
    ("R03", "EDL vs Kafka Reconciliation Drift", "Reconciliation", 5),
    ("R06", "Volume Anomaly", "Volume", 6),
    ("R05", "Overlap Population Anomaly", "Overlap", 7),
    ("R08", "Data Quality Warning", "Data Quality", 8),
    ("R09", "Source vs Calculated Rate Variance", "Data Quality", 9),
]


# --------------------------------------------------------------------------
# 4. threshold lookups - hidden plumbing over the disconnected config table
# --------------------------------------------------------------------------
def threshold_measures():
    out = []
    for key in THRESHOLD_KEYS:
        for label, col in (("Warn", "Warning Threshold"),
                           ("Crit", "Critical Threshold"),
                           ("Weight", "Weight")):
            out.append(M(
                "THR %s %s" % (label, key),
                """
                LOOKUPVALUE ( 'Dim_Thresholds'[{COL}], 'Dim_Thresholds'[Metric Key], "{KEY}" )
                """.replace("{COL}", col).replace("{KEY}", key),
                None, FLD_CFG,
                "%s threshold for %s, read from data/Thresholds.csv." % (label, key),
                hidden=True))
    return out


# --------------------------------------------------------------------------
# 5. severity engine - one rank measure per business rule
#    0 = no data, 1 = healthy, 2 = warning, 3 = critical
# --------------------------------------------------------------------------
def severity_measures():
    return [
        # ---- Rule 1: IDR resolution deterioration -------------------------
        M("Sev Rank IDR Resolution",
          """
          -- RULE 1.  Breach of the absolute rate, OR a material fall against
          -- yesterday, OR a material fall against the 7-day baseline.
          -- Any one of the three is enough; the worst one wins.
          VAR _v = [IDR Resolution Rate (Current)]
          VAR _w = [THR Warn IDR_RESOLUTION_RATE]
          VAR _c = [THR Crit IDR_RESOLUTION_RATE]
          VAR _wDrop = [THR Warn IDR_RESOLUTION_RATE_DROP]
          VAR _cDrop = [THR Crit IDR_RESOLUTION_RATE_DROP]
          VAR _dod = [IDR Resolution Rate (Delta)]
          VAR _base = [IDR Resolution Rate (vs 7D Baseline)]
          VAR _worstDrop = MINX ( { _dod, _base }, [Value] )
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _v ), 0,
                  _v < _c, 3,
                  NOT ISBLANK ( _worstDrop ) && _worstDrop <= - _cDrop, 3,
                  _v < _w, 2,
                  NOT ISBLANK ( _worstDrop ) && _worstDrop <= - _wDrop, 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 1 severity: IDR resolution rate against its absolute thresholds and against day-on-day and baseline drops.",
          hidden=True),

        # ---- Rule 2: IDR not resolved spike -------------------------------
        M("Sev Rank IDR Not Resolved",
          """
          -- RULE 2.  Unresolved volume judged three ways: growth against the
          -- 7-day baseline, an absolute ceiling, and a z-score.  Worst wins.
          VAR _abs = [IDR Not Resolved (Current)]
          VAR _pct = [IDR Not Resolved (vs 7D Baseline %)]
          VAR _z = [IDR Not Resolved (Z-Score)]
          VAR _wPct = [THR Warn IDR_NOT_RESOLVED_VS_BASELINE]
          VAR _cPct = [THR Crit IDR_NOT_RESOLVED_VS_BASELINE]
          VAR _wAbs = [THR Warn IDR_NOT_RESOLVED_ABS]
          VAR _cAbs = [THR Crit IDR_NOT_RESOLVED_ABS]
          VAR _wZ = [THR Warn IDR_NOT_RESOLVED_ZSCORE]
          VAR _cZ = [THR Crit IDR_NOT_RESOLVED_ZSCORE]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _abs ), 0,
                  ( NOT ISBLANK ( _pct ) && _pct >= _cPct ) || _abs >= _cAbs
                      || ( NOT ISBLANK ( _z ) && _z >= _cZ ), 3,
                  ( NOT ISBLANK ( _pct ) && _pct >= _wPct ) || _abs >= _wAbs
                      || ( NOT ISBLANK ( _z ) && _z >= _wZ ), 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 2 severity: unresolved IDR volume against baseline growth, an absolute ceiling and a z-score.",
          hidden=True),

        # ---- Rule 3: reconciliation drift ---------------------------------
        M("Recon Drift",
          """
          -- Absolute movement of the reconciliation rate against its own
          -- baseline, in ratio terms (0.05 = 5 percentage points).
          -- Regime independent: works whether the standing gap is 2% or 25%.
          VAR _c = [Total Reconciliation % (Current)]
          VAR _b = [Total Reconciliation % (7D Baseline)]
          VAR _n = [Baseline Day Count]
          RETURN
              IF (
                  NOT ( ISBLANK ( _c ) || ISBLANK ( _b ) )
                      && _n >= [THR Warn MIN_DRIFT_BASELINE_DAYS],
                  ABS ( _c - _b )
              )
          """,
          F_PCT, FLD_RECON,
          "Absolute drift of the total reconciliation rate against its 7-day baseline."),

        M("Unique Recon Drift",
          """
          VAR _c = [Unique Reconciliation % (Current)]
          VAR _b = [Unique Reconciliation % (7D Baseline)]
          VAR _n = [Baseline Day Count]
          RETURN
              IF (
                  NOT ( ISBLANK ( _c ) || ISBLANK ( _b ) )
                      && _n >= [THR Warn MIN_DRIFT_BASELINE_DAYS],
                  ABS ( _c - _b )
              )
          """,
          F_PCT, FLD_RECON,
          "Absolute drift of the unique reconciliation rate against its 7-day baseline."),

        M("Sev Rank Reconciliation",
          """
          -- RULE 3.  Drift of the reconciliation rate against its own baseline,
          -- on both the total and the unique population, plus a secondary check
          -- on the absolute size of the gap.
          VAR _drift = MAXX ( { [Recon Drift], [Unique Recon Drift] }, [Value] )
          VAR _gap = [Total Difference % of EDL (Current)]
          VAR _w = [THR Warn RECON_DRIFT_PP]
          VAR _c = [THR Crit RECON_DRIFT_PP]
          VAR _wGap = [THR Warn RECON_GAP_PCT]
          VAR _cGap = [THR Crit RECON_GAP_PCT]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( [Total Reconciliation % (Current)] ), 0,
                  ( NOT ISBLANK ( _drift ) && _drift >= _c ) || ( NOT ISBLANK ( _gap ) && _gap >= _cGap ), 3,
                  ( NOT ISBLANK ( _drift ) && _drift >= _w ) || ( NOT ISBLANK ( _gap ) && _gap >= _wGap ), 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 3 severity: EDL/Kafka reconciliation drift against baseline, plus an absolute gap check.",
          hidden=True),

        # ---- Rule 4: direction reversal -----------------------------------
        M("Reconciliation Direction Change",
          """
          -- RULE 4.  A sign flip in the signed variance is a control breach,
          -- not a magnitude problem, so it is detected separately from drift.
          VAR _c = [Total EDL vs Kafka Difference (Current)]
          VAR _p = [Total EDL vs Kafka Difference (Previous Day)]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _c ) || ISBLANK ( _p ), "NO BASELINE",
                  SIGN ( _c ) = SIGN ( _p ), "STABLE - " & [Reconciliation Direction],
                  _c < 0 && _p >= 0, "NORMAL -> NEGATIVE VARIANCE",
                  _c >= 0 && _p < 0, "NEGATIVE -> NORMAL VARIANCE",
                  "DIRECTION CHANGE"
              )
          """,
          None, FLD_RECON,
          "Detects a sign flip in the signed EDL/Kafka variance versus the previous day. A move to negative means Kafka now exceeds EDL."),

        M("Unique Reconciliation Direction Change",
          """
          VAR _c = [Unique EDL vs Kafka Difference (Current)]
          VAR _p = [Unique EDL vs Kafka Difference (Previous Day)]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _c ) || ISBLANK ( _p ), "NO BASELINE",
                  SIGN ( _c ) = SIGN ( _p ), "STABLE - " & [Unique Reconciliation Direction],
                  _c < 0 && _p >= 0, "NORMAL -> NEGATIVE VARIANCE",
                  _c >= 0 && _p < 0, "NEGATIVE -> NORMAL VARIANCE",
                  "DIRECTION CHANGE"
              )
          """,
          None, FLD_RECON,
          "Sign-flip detection on the unique EDL/Kafka variance."),

        M("Sev Rank Direction",
          """
          -- RULE 4 severity.  Flipping to negative (Kafka exceeding EDL) is
          -- critical.  Flipping back to positive is still a regime change and
          -- is raised as a warning rather than silently cleared.
          VAR _t = [Total EDL vs Kafka Difference (Current)]
          VAR _tp = [Total EDL vs Kafka Difference (Previous Day)]
          VAR _u = [Unique EDL vs Kafka Difference (Current)]
          VAR _up = [Unique EDL vs Kafka Difference (Previous Day)]
          VAR _toNeg = ( NOT ISBLANK ( _tp ) && _t < 0 && _tp >= 0 )
                    || ( NOT ISBLANK ( _up ) && _u < 0 && _up >= 0 )
          VAR _toPos = ( NOT ISBLANK ( _tp ) && _t >= 0 && _tp < 0 )
                    || ( NOT ISBLANK ( _up ) && _u >= 0 && _up < 0 )
          VAR _standingNeg = ( NOT ISBLANK ( _t ) && _t < 0 ) || ( NOT ISBLANK ( _u ) && _u < 0 )
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _t ), 0,
                  _toNeg, 3,
                  _standingNeg, 3,
                  _toPos, 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 4 severity: reconciliation direction reversal. Critical whenever Kafka exceeds EDL.",
          hidden=True),

        # ---- Rule 5: overlap anomaly --------------------------------------
        M("Overlap Segment Sev Rank",
          """
          -- RULE 5, evaluated per identity population.
          -- A percentage move only counts as an anomaly when it is also a
          -- material move in absolute identities.  Without that second test a
          -- population going from 1 to 2 registers as a 100% spike and the rule
          -- fires every day on noise.
          VAR _pct = ABS ( [Overlap Segment Population (vs 7D Baseline %)] )
          VAR _abs = ABS ( [Overlap Segment Population (vs 7D Baseline)] )
          VAR _wPct = [THR Warn OVERLAP_CHANGE_PCT]
          VAR _cPct = [THR Crit OVERLAP_CHANGE_PCT]
          VAR _wAbs = [THR Warn OVERLAP_MIN_ABS_CHANGE]
          VAR _cAbs = [THR Crit OVERLAP_MIN_ABS_CHANGE]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _pct ), 0,
                  _pct >= _cPct && _abs >= _cAbs, 3,
                  _pct >= _wPct && _abs >= _wAbs, 2,
                  1
              )
          """,
          F_INT, FLD_OVR,
          "Severity of the identity population in row context, judged on relative and absolute movement together.",
          hidden=True),

        M("Overlap Worst Change %",
          """
          -- Restricted to populations that also moved materially in absolute
          -- terms, so the headline number an executive reads is a real one.
          MAXX (
              FILTER (
                  VALUES ( 'Fact_Overlap_Daily'[Segment] ),
                  ABS ( [Overlap Segment Population (vs 7D Baseline)] )
                      >= [THR Warn OVERLAP_MIN_ABS_CHANGE]
              ),
              ABS ( [Overlap Segment Population (vs 7D Baseline %)] )
          )
          """,
          F_PCT, FLD_OVR,
          "Largest material movement of any identity overlap population against its 7-day baseline."),

        M("Overlap Worst Absolute Change",
          """
          MAXX (
              VALUES ( 'Fact_Overlap_Daily'[Segment] ),
              ABS ( [Overlap Segment Population (vs 7D Baseline)] )
          )
          """,
          F_COUNT, FLD_OVR,
          "Largest absolute movement in identities across the eight overlap populations."),

        M("Overlap Worst Z-Score",
          """
          MAXX (
              VALUES ( 'Fact_Overlap_Daily'[Segment] ),
              ABS ( [Overlap Segment Population (Z-Score)] )
          )
          """,
          F_Z, FLD_OVR,
          "Largest absolute z-score across the eight identity overlap populations."),

        M("Worst Overlap Segment",
          """
          VAR _t =
              ADDCOLUMNS (
                  FILTER (
                      VALUES ( 'Fact_Overlap_Daily'[Segment] ),
                      ABS ( [Overlap Segment Population (vs 7D Baseline)] )
                          >= [THR Warn OVERLAP_MIN_ABS_CHANGE]
                  ),
                  "@chg", ABS ( [Overlap Segment Population (vs 7D Baseline %)] )
              )
          VAR _top = TOPN ( 1, FILTER ( _t, NOT ISBLANK ( [@chg] ) ), [@chg], DESC )
          RETURN
              COALESCE ( CONCATENATEX ( _top, 'Fact_Overlap_Daily'[Segment], ", " ), "-" )
          """,
          None, FLD_OVR,
          "Name of the identity population moving furthest from its baseline. The first place to look during an overlap anomaly."),

        M("Overlap Segments In Breach",
          """
          COUNTROWS (
              FILTER ( VALUES ( 'Fact_Overlap_Daily'[Segment] ), [Overlap Segment Sev Rank] >= 2 )
          ) + 0
          """,
          F_INT, FLD_OVR,
          "How many of the eight identity populations are outside their warning tolerance."),

        M("Sev Rank Overlap",
          """
          -- Worst-population wins, so a large swing in one population cannot be
          -- averaged away by the seven that are behaving normally.
          MAXX ( VALUES ( 'Fact_Overlap_Daily'[Segment] ), [Overlap Segment Sev Rank] )
          """,
          F_INT, FLD_ALERT,
          "Rule 5 severity: anomalous movement in any identity overlap population.",
          hidden=True),

        # ---- Rule 6: volume anomaly ---------------------------------------
        M("Volume Worst Z-Score",
          """
          -- Rolling-baseline z-score, so ordinary weekday/weekend swings do not
          -- register as failures - only moves outside the recent noise band do.
          VAR _hasBase = NOT ISBLANK ( [Total EDL Logins (7D Baseline)] )
          VAR _z =
              MAXX (
                  {
                      ABS ( [Total EDL Logins (Z-Score)] ),
                      ABS ( [Unique EDL Logins (Z-Score)] ),
                      ABS ( [Total Kafka Logins Events (Z-Score)] ),
                      ABS ( [Unique Kafka Logins (Z-Score)] )
                  },
                  [Value]
              )
          RETURN IF ( _hasBase, _z )
          """,
          F_Z, FLD_VOL,
          "Largest absolute volume z-score across EDL total/unique and Kafka total/unique."),

        M("Worst Volume Metric",
          """
          VAR _vals =
              UNION (
                  ROW ( "@metric", "Total EDL Logins", "@z", ABS ( [Total EDL Logins (Z-Score)] ) ),
                  ROW ( "@metric", "Unique EDL Logins", "@z", ABS ( [Unique EDL Logins (Z-Score)] ) ),
                  ROW ( "@metric", "Total Kafka Logins Events", "@z", ABS ( [Total Kafka Logins Events (Z-Score)] ) ),
                  ROW ( "@metric", "Unique Kafka Logins", "@z", ABS ( [Unique Kafka Logins (Z-Score)] ) )
              )
          VAR _top = TOPN ( 1, FILTER ( _vals, NOT ISBLANK ( [@z] ) ), [@z], DESC )
          RETURN COALESCE ( CONCATENATEX ( _top, [@metric], ", " ), "-" )
          """,
          None, FLD_VOL,
          "Which volume stream is furthest from its baseline."),

        M("Volume Worst Change %",
          """
          MAXX (
              {
                  ABS ( [Total EDL Logins (vs 7D Baseline %)] ),
                  ABS ( [Unique EDL Logins (vs 7D Baseline %)] ),
                  ABS ( [Total Kafka Logins Events (vs 7D Baseline %)] ),
                  ABS ( [Unique Kafka Logins (vs 7D Baseline %)] )
              },
              [Value]
          )
          """,
          F_PCT, FLD_VOL,
          "Largest relative volume movement against the 7-day baseline."),

        M("Sev Rank Volume",
          """
          -- RULE 6.  Baseline-relative, never absolute, so genuine growth is not
          -- reported as an incident.  A z-score alone is not enough: it must be
          -- accompanied by a materially large relative move, otherwise a very
          -- steady metric raises an alert over an operationally trivial wobble.
          VAR _z = [Volume Worst Z-Score]
          VAR _chg = [Volume Worst Change %]
          VAR _w = [THR Warn VOLUME_ZSCORE]
          VAR _c = [THR Crit VOLUME_ZSCORE]
          VAR _wChg = [THR Warn VOLUME_MIN_CHANGE_PCT]
          VAR _cChg = [THR Crit VOLUME_MIN_CHANGE_PCT]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _z ), 0,
                  _z >= _c && _chg >= _cChg, 3,
                  _z >= _w && _chg >= _wChg, 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 6 severity: volume movement outside the recent noise band and materially large.",
          hidden=True),

        # ---- Rule 8 / 9: data quality -------------------------------------
        M("Sev Rank Data Quality",
          """
          -- Date-scoped on purpose.  A defect on one date must not be attributed
          -- to every other date; the dataset-wide verdict lives in the header.
          VAR _n = [Data Quality Issue Count (Selected Date)]
          VAR _w = [THR Warn DATA_QUALITY]
          VAR _c = [THR Crit DATA_QUALITY]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _n ), 0,
                  _n >= _c, 3,
                  _n >= _w, 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 8 severity: number of data-quality defects detected in the loaded data.",
          hidden=True),

        M("Sev Rank Source Rate Variance",
          """
          VAR _v = ABS ( [Source vs Calculated Resolution Rate Variance (Selected Date)] )
          VAR _w = [THR Warn SOURCE_VS_CALC_RATE]
          VAR _c = [THR Crit SOURCE_VS_CALC_RATE]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _v ), 0,
                  _v >= _c, 3,
                  _v >= _w, 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 9 severity: disagreement between the published and recalculated resolution rate.",
          hidden=True),

        # ---- Rule 7: compound ---------------------------------------------
        M("Active Critical Signal Count",
          """
          -- Counted from the individual rule measures, never from the rule table,
          -- so the compound rule cannot reference itself.
          -- Platform signals only: a data-quality defect is a trust problem, not
          -- a platform incident, and must not manufacture a compound incident.
          IF ( [Sev Rank IDR Resolution] = 3, 1, 0 ) + IF ( [Sev Rank IDR Not Resolved] = 3, 1, 0 )
              + IF ( [Sev Rank Reconciliation] = 3, 1, 0 ) + IF ( [Sev Rank Direction] = 3, 1, 0 )
              + IF ( [Sev Rank Volume] = 3, 1, 0 ) + IF ( [Sev Rank Overlap] = 3, 1, 0 )
          """,
          F_INT, FLD_ALERT,
          "How many alert rules are simultaneously critical on the selected date."),

        M("Active Warning Signal Count",
          """
          IF ( [Sev Rank IDR Resolution] = 2, 1, 0 ) + IF ( [Sev Rank IDR Not Resolved] = 2, 1, 0 )
              + IF ( [Sev Rank Reconciliation] = 2, 1, 0 ) + IF ( [Sev Rank Direction] = 2, 1, 0 )
              + IF ( [Sev Rank Volume] = 2, 1, 0 ) + IF ( [Sev Rank Overlap] = 2, 1, 0 )
          """,
          F_INT, FLD_ALERT,
          "How many alert rules are simultaneously in warning on the selected date."),

        M("Sev Rank Compound",
          """
          -- RULE 7.  Correlated failures are worse than the sum of their parts.
          -- The bar for declaring an incident is deliberately high: one isolated
          -- critical alongside a single warning is an anomaly to action, not a
          -- multi-signal incident.  If CRITICAL is used loosely it stops
          -- carrying information for the person reading it.
          VAR _crit = [Active Critical Signal Count]
          VAR _warn = [Active Warning Signal Count]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( [Selected Business Date] ), 0,
                  _crit >= 2, 3,
                  _crit >= 1 && _warn >= 2, 3,
                  _warn >= 3, 3,
                  _crit >= 1 || _warn >= 2, 2,
                  1
              )
          """,
          F_INT, FLD_ALERT,
          "Rule 7 severity: escalation when several independent signals fail on the same date.",
          hidden=True),
    ]


# --------------------------------------------------------------------------
# 6. alert surface - rule table dispatch and executive messaging
# --------------------------------------------------------------------------
def alert_measures():
    sev_dispatch = """
          SWITCH (
              SELECTEDVALUE ( 'Dim_Alert_Rules'[Rule Key] ),
              "R01", [Sev Rank IDR Resolution],
              "R02", [Sev Rank IDR Not Resolved],
              "R03", [Sev Rank Reconciliation],
              "R04", [Sev Rank Direction],
              "R05", [Sev Rank Overlap],
              "R06", [Sev Rank Volume],
              "R07", [Sev Rank Compound],
              "R08", [Sev Rank Data Quality],
              "R09", [Sev Rank Source Rate Variance],
              BLANK ( )
          )
    """
    _all = [
        M("Rule Severity Rank", sev_dispatch, F_INT, FLD_ALERT,
          "Severity rank of the alert rule in row context: 0 no data, 1 healthy, 2 warning, 3 critical."),

        M("Rule Severity",
          """
          SWITCH ( [Rule Severity Rank], 3, "CRITICAL", 2, "WARNING", 1, "HEALTHY", "NO DATA" )
          """,
          None, FLD_ALERT, "Severity of the alert rule in row context, as text."),

        M("Rule Severity Colour",
          """
          SWITCH ( [Rule Severity Rank], 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_ALERT, "Semantic colour for the alert rule in row context.", hidden=True),

        M("Rule Current Value",
          """
          -- Every rule reports its own headline number in its own natural unit.
          SWITCH (
              SELECTEDVALUE ( 'Dim_Alert_Rules'[Rule Key] ),
              "R01", FORMAT ( [IDR Resolution Rate (Current)], "0.00%" ),
              "R02", FORMAT ( [IDR Not Resolved (Current)], "#,##0" ),
              "R03", FORMAT ( [Total Reconciliation % (Current)], "0.0%" ),
              "R04", [Reconciliation Direction],
              "R05", [Worst Overlap Segment] & ": " & FORMAT ( [Overlap Worst Change %], "+0.0%;-0.0%;0.0%" ),
              "R06", [Worst Volume Metric] & ": z " & FORMAT ( [Volume Worst Z-Score], "0.00" ),
              "R07", FORMAT ( [Active Critical Signal Count], "0" ) & " critical / "
                  & FORMAT ( [Active Warning Signal Count], "0" ) & " warning",
              "R08", FORMAT ( [Data Quality Issue Count (Selected Date)], "0" ) & " issue(s) on this date",
              "R09", FORMAT ( [Source vs Calculated Resolution Rate Variance (Selected Date)], "+0.00%;-0.00%;0.00%" ),
              BLANK ( )
          )
          """,
          None, FLD_ALERT, "Headline value for the alert rule in row context."),

        M("Rule Baseline",
          """
          SWITCH (
              SELECTEDVALUE ( 'Dim_Alert_Rules'[Rule Key] ),
              "R01", FORMAT ( [IDR Resolution Rate (7D Baseline)], "0.00%" ),
              "R02", FORMAT ( [IDR Not Resolved (7D Baseline)], "#,##0" ),
              "R03", FORMAT ( [Total Reconciliation % (7D Baseline)], "0.0%" ),
              "R04", [Reconciliation Direction Change],
              "R05", "7D baseline",
              "R06", "z tolerance " & FORMAT ( [THR Warn VOLUME_ZSCORE], "0.0" ),
              "R07", "single-signal",
              "R08", "0 issues",
              "R09", "tolerance " & FORMAT ( [THR Warn SOURCE_VS_CALC_RATE], "0.0%" ),
              BLANK ( )
          )
          """,
          None, FLD_ALERT, "Baseline the alert rule is judged against."),

        M("Rule Change",
          """
          SWITCH (
              SELECTEDVALUE ( 'Dim_Alert_Rules'[Rule Key] ),
              "R01", FORMAT ( [IDR Resolution Rate (vs 7D Baseline pp)], "+0.0;-0.0;0" ) & " pp",
              "R02", FORMAT ( [IDR Not Resolved (vs 7D Baseline %)], "+0.0%;-0.0%;0.0%" ),
              "R03", FORMAT ( [Recon Drift] * 100, "0.0" ) & " pp drift",
              "R04", FORMAT ( [Total EDL vs Kafka Difference (Current)], "+#,##0;-#,##0;0" ),
              "R05", FORMAT ( [Overlap Worst Change %], "+0.0%;-0.0%;0.0%" ),
              "R06", FORMAT ( [Volume Worst Z-Score], "0.00" ) & " sigma",
              "R07", FORMAT ( [Active Critical Signal Count] + [Active Warning Signal Count], "0" ) & " signals",
              "R08", FORMAT ( [Data Quality Issue Count (Selected Date)], "+0;-0;0" ),
              "R09", FORMAT ( [Source vs Calculated Resolution Rate Variance (Selected Date)] * 100, "+0.00;-0.00;0.00" ) & " pp",
              BLANK ( )
          )
          """,
          None, FLD_ALERT, "Movement that triggered the alert rule."),

        M("Rule Message",
          """
          -- Business interpretation.  Every number is read from a measure so the
          -- text stays true when the data changes.
          VAR _k = SELECTEDVALUE ( 'Dim_Alert_Rules'[Rule Key] )
          VAR _rank = [Rule Severity Rank]
          RETURN
              SWITCH (
                  _k,
                  "R01",
                      IF ( _rank <= 1, "Resolution is within tolerance.",
                          "IDR resolution is " & FORMAT ( [IDR Resolution Rate (Current)], "0.0%" )
                          & " against a warning threshold of " & FORMAT ( [THR Warn IDR_RESOLUTION_RATE], "0.0%" )
                          & ". That is " & FORMAT ( [IDR Resolution Rate (vs 7D Baseline pp)], "+0.0;-0.0;0" )
                          & " pp versus the 7-day baseline. Investigate the identity resolution pipeline." ),
                  "R02",
                      IF ( _rank <= 1, "Unresolved volume is in line with the recent baseline.",
                          "IDR Not Resolved is " & FORMAT ( [IDR Not Resolved (Current)], "#,##0" )
                          & " against a 7-day baseline of " & FORMAT ( [IDR Not Resolved (7D Baseline)], "#,##0" )
                          & " (" & FORMAT ( [IDR Not Resolved (vs 7D Baseline %)], "+0.0%;-0.0%;0.0%" )
                          & "). Unresolved identities are accumulating faster than normal." ),
                  "R03",
                      IF ( _rank <= 1, "EDL and Kafka are reconciling within their normal band.",
                          "EDL/Kafka reconciliation moved " & FORMAT ( [Recon Drift] * 100, "0.0" )
                          & " pp against its 7-day baseline, now at "
                          & FORMAT ( [Total Reconciliation % (Current)], "0.0%" )
                          & ". A shift of this size means one of the two feeds changed behaviour." ),
                  "R04",
                      IF ( _rank <= 1, "Reconciliation direction is stable.",
                          "Reconciliation direction is " & [Reconciliation Direction] & " ("
                          & [Reconciliation Direction Change] & "). Signed variance is "
                          & FORMAT ( [Total EDL vs Kafka Difference (Current)], "+#,##0;-#,##0;0" )
                          & " on total and " & FORMAT ( [Unique EDL vs Kafka Difference (Current)], "+#,##0;-#,##0;0" )
                          & " on unique. Kafka reporting more than EDL is a control breach, not a rounding gap." ),
                  "R05",
                      IF ( _rank <= 1, "Identity overlap populations are stable.",
                          "Overlap population " & [Worst Overlap Segment] & " moved "
                          & FORMAT ( [Overlap Worst Change %], "+0.0%;-0.0%;0.0%" )
                          & " against its 7-day baseline, with " & FORMAT ( [Overlap Segments In Breach], "0" )
                          & " population(s) outside tolerance. Sudden overlap growth normally precedes resolution failures." ),
                  "R06",
                      IF ( _rank <= 1, "Login volumes are inside the normal range.",
                          "Volume anomaly on " & [Worst Volume Metric] & " at "
                          & FORMAT ( [Volume Worst Z-Score], "0.00" )
                          & " standard deviations from the 7-day baseline. Confirm whether this is genuine demand or a pipeline duplication." ),
                  "R07",
                      IF ( _rank <= 1, "No correlated failures detected.",
                          "MULTI-SIGNAL INCIDENT: " & FORMAT ( [Active Critical Signal Count], "0" )
                          & " critical and " & FORMAT ( [Active Warning Signal Count], "0" )
                          & " warning signals are firing on the same date. Correlated failures across resolution, reconciliation and identity matching point to a single upstream cause." ),
                  "R08",
                      IF ( _rank <= 1, "No data quality defects detected.",
                          FORMAT ( [Data Quality Issue Count (Selected Date)], "0" )
                          & " data quality issue(s) detected on this date: " & [DQ Date Issue List]
                          & ". Treat the KPIs for this date as provisional until resolved." ),
                  "R09",
                      IF ( _rank <= 1, "Published and recalculated resolution rates agree.",
                          "The resolution rate published in the source differs from the recalculated rate by "
                          & FORMAT ( [Source vs Calculated Resolution Rate Variance (Selected Date)] * 100, "+0.00;-0.00;0.00" )
                          & " pp. The recalculated rate is used everywhere on this report." ),
                  BLANK ( )
              )
          """,
          None, FLD_ALERT, "Plain-language business interpretation of the alert rule in row context."),

        M("Alert Priority Score",
          """
          -- Severity dominates; rule priority only breaks ties within a severity.
          VAR _rank = [Rule Severity Rank]
          VAR _prio = SELECTEDVALUE ( 'Dim_Alert_Rules'[Rule Priority] )
          RETURN IF ( NOT ISBLANK ( _rank ), _rank * 1000 + ( 100 - _prio ) )
          """,
          F_INT, FLD_ALERT,
          "Ranking score for the executive alert panel. Severity dominates, rule priority breaks ties."),

        M("Active Alerts",
          """
          COUNTROWS ( FILTER ( ALL ( 'Dim_Alert_Rules' ), [Rule Severity Rank] >= 2 ) ) + 0
          """,
          F_INT, FLD_EXEC,
          "Number of alert rules at warning or critical on the selected date."),

        M("Critical Alerts",
          """
          COUNTROWS ( FILTER ( ALL ( 'Dim_Alert_Rules' ), [Rule Severity Rank] = 3 ) ) + 0
          """,
          F_INT, FLD_EXEC,
          "Number of alert rules at critical on the selected date."),

        M("Overall Severity Rank",
          """
          MAXX ( ALL ( 'Dim_Alert_Rules' ), [Rule Severity Rank] )
          """,
          F_INT, FLD_ALERT,
          "Worst severity across every alert rule.", hidden=True),

        M("Alert Severity",
          """
          SWITCH ( [Overall Severity Rank], 3, "Red", 2, "Amber", 1, "Green", "No Data" )
          """,
          None, FLD_EXEC,
          "Overall traffic-light state of the platform: Green healthy, Amber warning, Red critical."),

        M("Alert Flag",
          """
          -- CRITICAL is deliberately reserved for correlated failures so the word
          -- keeps its meaning when an executive sees it.
          VAR _rank = [Overall Severity Rank]
          VAR _compound = [Sev Rank Compound]
          RETURN
              SWITCH (
                  TRUE ( ),
                  _rank = 0 || ISBLANK ( _rank ), "NO DATA",
                  _rank = 3 && _compound = 3, "CRITICAL",
                  _rank = 3, "ACTION REQUIRED",
                  _rank = 2, "WATCH",
                  "NO ISSUE"
              )
          """,
          None, FLD_EXEC,
          "Escalation state: NO ISSUE, WATCH, ACTION REQUIRED or CRITICAL."),

        M("Alert Severity Colour",
          """
          SWITCH ( [Overall Severity Rank], 3, "{RED}", 2, "{AMBER}", 1, "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the overall platform state.", hidden=True),

        M("Primary Risk Driver",
          """
          VAR _t = ADDCOLUMNS ( ALL ( 'Dim_Alert_Rules' ), "@score", [Alert Priority Score] )
          VAR _top = TOPN ( 1, FILTER ( _t, [@score] >= 2000 ), [@score], DESC )
          RETURN
              COALESCE ( CONCATENATEX ( _top, 'Dim_Alert_Rules'[Rule], ", " ), "No material risk driver" )
          """,
          None, FLD_ALERT,
          "The single highest-priority failing rule. Drives the 'investigate first' guidance."),

        M("Executive Alert Message",
          """
          -- The one sentence an executive reads first.
          VAR _flag = [Alert Flag]
          VAR _t = ADDCOLUMNS ( ALL ( 'Dim_Alert_Rules' ), "@score", [Alert Priority Score] )
          VAR _top = TOPN ( 1, FILTER ( _t, [@score] >= 2000 ), [@score], DESC )
          VAR _msg = CONCATENATEX ( _top, [Rule Message], " " )
          RETURN
              IF (
                  ISBLANK ( _msg ),
                  "NO ISSUE - all monitored signals are inside tolerance for "
                      & FORMAT ( [Selected Business Date], "dd-MMM-yyyy" ) & ".",
                  _flag & " - " & _msg
              )
          """,
          None, FLD_EXEC,
          "Human-readable headline alert, generated from the highest-priority failing rule."),
    ]
    return _only_when_firing(_all)


# The alert panel is a list of what is wrong, not a list of every control.
# Blanking the surface measures for a rule that is not firing makes Power BI
# drop the row, which is what a visual-level filter on the ranking measure used
# to do - except that a legacy visual filter on a measure is evaluated outside
# the Dim_Alert_Rules row context and silently empties the whole table.
PANEL_MEASURES = ("Rule Severity", "Rule Current Value", "Rule Baseline",
                  "Rule Change", "Rule Message", "Alert Priority Score")


LF = chr(10)


def _only_when_firing(measures):
    for m in measures:
        if m["name"] in PANEL_MEASURES:
            body = m["dax"].strip(LF).rstrip()
            m["dax"] = LF.join([
                "",
                "          -- Blank unless this rule is at warning or critical, so",
                "          -- the alert panel lists only what is actually wrong.",
                "          IF (",
                "              [Rule Severity Rank] >= 2,",
                body,
                "          )",
                "          ",
            ])
    return measures


# --------------------------------------------------------------------------
# 7. health score
# --------------------------------------------------------------------------
def health_measures():
    # scoring helper text reused across components
    lower_worse = """
          -- 100 at or above the warning threshold, 50 at critical, 0 one full
          -- band below critical.  Linear between, clamped to 0-100.
          VAR _band = _w - _c
          VAR _raw = IF ( _v >= _w, 100, 50 + 50 * DIVIDE ( _v - _c, _band ) )
          RETURN IF ( ISBLANK ( _v ) || _band <= 0, BLANK ( ), MAX ( 0, MIN ( 100, _raw ) ) )
    """
    higher_worse = """
          -- 100 at or below the warning threshold, 50 at critical, 0 one full
          -- band above critical.  Linear between, clamped to 0-100.
          VAR _band = _c - _w
          VAR _raw = IF ( _v <= _w, 100, 50 + 50 * DIVIDE ( _c - _v, _band ) )
          RETURN IF ( ISBLANK ( _v ) || _band <= 0, BLANK ( ), MAX ( 0, MIN ( 100, _raw ) ) )
    """

    return [
        M("Health Component IDR Resolution",
          """
          VAR _v = [IDR Resolution Rate (Current)]
          VAR _w = [THR Warn IDR_RESOLUTION_RATE]
          VAR _c = [THR Crit IDR_RESOLUTION_RATE]
          """ + lower_worse,
          F_SCORE, FLD_HEALTH,
          "0-100 score for IDR resolution health."),

        M("Health Component IDR Not Resolved Trend",
          """
          VAR _v = [IDR Not Resolved (vs 7D Baseline %)]
          VAR _w = [THR Warn IDR_NOT_RESOLVED_VS_BASELINE]
          VAR _c = [THR Crit IDR_NOT_RESOLVED_VS_BASELINE]
          """ + higher_worse,
          F_SCORE, FLD_HEALTH,
          "0-100 score for the trend in unresolved IDR volume."),

        M("Health Component Reconciliation",
          """
          -- Reconciliation health is drift-based, but a direction reversal is a
          -- control breach and collapses the component regardless of magnitude.
          VAR _reversal = [Sev Rank Direction] = 3
          VAR _v = MAXX ( { [Recon Drift], [Unique Recon Drift] }, [Value] )
          VAR _w = [THR Warn RECON_DRIFT_PP]
          VAR _c = [THR Crit RECON_DRIFT_PP]
          VAR _band = _c - _w
          VAR _raw = IF ( _v <= _w, 100, 50 + 50 * DIVIDE ( _c - _v, _band ) )
          VAR _score = IF ( ISBLANK ( _v ) || _band <= 0, BLANK ( ), MAX ( 0, MIN ( 100, _raw ) ) )
          RETURN IF ( _reversal, 0, _score )
          """,
          F_SCORE, FLD_HEALTH,
          "0-100 score for EDL/Kafka reconciliation. Collapses to zero on a direction reversal."),

        M("Health Component Volume Stability",
          """
          VAR _v = [Volume Worst Z-Score]
          VAR _w = [THR Warn VOLUME_ZSCORE]
          VAR _c = [THR Crit VOLUME_ZSCORE]
          """ + higher_worse,
          F_SCORE, FLD_HEALTH,
          "0-100 score for volume stability against the rolling baseline."),

        M("Health Component Overlap Stability",
          """
          VAR _v = [Overlap Worst Change %]
          VAR _w = [THR Warn OVERLAP_CHANGE_PCT]
          VAR _c = [THR Crit OVERLAP_CHANGE_PCT]
          """ + higher_worse,
          F_SCORE, FLD_HEALTH,
          "0-100 score for stability of the identity overlap populations."),

        M("Health Component Data Quality",
          """
          VAR _v = [Data Quality Issue Count (Selected Date)] + 0
          VAR _w = [THR Warn DATA_QUALITY]
          VAR _c = [THR Crit DATA_QUALITY]
          """ + higher_worse,
          F_SCORE, FLD_HEALTH,
          "0-100 score for data quality of the loaded data."),

        M("IDR Platform Health Score",
          """
          -- Weighted mean of the six components, with weights read from the
          -- configuration table.  Components with no baseline yet are excluded
          -- from both numerator and denominator rather than scored as perfect.
          VAR _s1 = [Health Component IDR Resolution]
          VAR _s2 = [Health Component IDR Not Resolved Trend]
          VAR _s3 = [Health Component Reconciliation]
          VAR _s4 = [Health Component Volume Stability]
          VAR _s5 = [Health Component Overlap Stability]
          VAR _s6 = [Health Component Data Quality]
          VAR _w1 = [THR Weight IDR_RESOLUTION_RATE]
          VAR _w2 = [THR Weight IDR_NOT_RESOLVED_VS_BASELINE]
          VAR _w3 = [THR Weight RECON_DRIFT_PP]
          VAR _w4 = [THR Weight VOLUME_ZSCORE]
          VAR _w5 = [THR Weight OVERLAP_CHANGE_PCT]
          VAR _w6 = [THR Weight DATA_QUALITY]
          VAR _num =
              IF ( ISBLANK ( _s1 ), 0, _s1 * _w1 ) + IF ( ISBLANK ( _s2 ), 0, _s2 * _w2 )
                  + IF ( ISBLANK ( _s3 ), 0, _s3 * _w3 ) + IF ( ISBLANK ( _s4 ), 0, _s4 * _w4 )
                  + IF ( ISBLANK ( _s5 ), 0, _s5 * _w5 ) + IF ( ISBLANK ( _s6 ), 0, _s6 * _w6 )
          VAR _den =
              IF ( ISBLANK ( _s1 ), 0, _w1 ) + IF ( ISBLANK ( _s2 ), 0, _w2 )
                  + IF ( ISBLANK ( _s3 ), 0, _w3 ) + IF ( ISBLANK ( _s4 ), 0, _w4 )
                  + IF ( ISBLANK ( _s5 ), 0, _w5 ) + IF ( ISBLANK ( _s6 ), 0, _w6 )
          RETURN IF ( _den > 0, DIVIDE ( _num, _den ) )
          """,
          F_SCORE, FLD_EXEC,
          "Weighted 0-100 composite health score across resolution, unresolved trend, reconciliation, volume, overlap and data quality."),

        M("Health Score Band",
          """
          VAR _s = [IDR Platform Health Score]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _s ), "NO DATA",
                  _s >= 85, "HEALTHY",
                  _s >= 65, "WATCH",
                  _s >= 40, "DEGRADED",
                  "CRITICAL"
              )
          """,
          None, FLD_EXEC, "Health score banded into HEALTHY / WATCH / DEGRADED / CRITICAL."),

        M("Health Score Colour",
          """
          VAR _s = [IDR Platform Health Score]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _s ), "{NEUTRAL}",
                  _s >= 85, "{GREEN}",
                  _s >= 65, "{AMBER}",
                  "{RED}"
              )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
          None, FLD_UX, "Semantic colour for the health score.", hidden=True),

        M("Health Score Label",
          """
          VAR _s = [IDR Platform Health Score]
          RETURN IF ( ISBLANK ( _s ), "-", FORMAT ( _s, "0" ) & " / 100  " & [Health Score Band] )
          """,
          None, FLD_EXEC, "Health score formatted for a card subtitle."),
    ]
