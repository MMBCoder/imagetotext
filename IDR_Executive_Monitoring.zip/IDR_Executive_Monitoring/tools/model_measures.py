"""Measure catalogue for the IDR Executive Monitoring semantic model.

Every measure in the model is declared here as data so that the DAX stays
reviewable in one place and the TMDL is generated deterministically.

A measure is a dict:
    name        measure name (must be unique across the model)
    dax         DAX expression, written with 4-space indentation
    fmt         formatString, or None for text measures
    folder      display folder
    desc        description surfaced in the field list and in Excel/Copilot
    hidden      True to hide the measure from report authors
"""

# --------------------------------------------------------------------------
# format strings
# --------------------------------------------------------------------------
F_COUNT = "#,##0"
F_COUNT_SIGNED = "+#,##0;-#,##0;0"
F_PCT = "0.0%"
F_PCT2 = "0.00%"
F_PCT_SIGNED = "+0.0%;-0.0%;0.0%"
F_PP = '+0.0" pp";-0.0" pp";0.0" pp"'
F_SCORE = "0"
F_Z = "0.00"
F_DATE = "dd-mmm-yyyy"
F_INT = "0"


def M(name, dax, fmt, folder, desc, hidden=False):
    return {"name": name, "dax": dax.strip("\n"), "fmt": fmt,
            "folder": folder, "desc": desc, "hidden": hidden}


# --------------------------------------------------------------------------
# folders
# --------------------------------------------------------------------------
FLD_EXEC = "01 - Executive KPIs"
FLD_IDR = "02 - IDR"
FLD_RECON = "03 - Reconciliation"
FLD_VOL = "04 - Volume"
FLD_OVR = "05 - Overlap"
FLD_ALERT = "06 - Alerts"
FLD_DQ = "07 - Data Quality"
FLD_TREND = "08 - Trend Intelligence"
FLD_CFG = "09 - Configuration"
FLD_HEALTH = "10 - Health Score"
FLD_NARR = "11 - Narrative"
FLD_UX = "12 - Report UX"


# --------------------------------------------------------------------------
# 1. date context - everything downstream keys off these
# --------------------------------------------------------------------------
def date_context():
    return [
        M("Latest Business Date",
          """
          -- Maximum Event Date present in the data, ignoring every report filter.
          -- Never uses TODAY(): the report is "as of" the data, not the calendar.
          CALCULATE ( MAX ( 'Fact_IDR_Daily'[Event Date] ), REMOVEFILTERS ( ) )
          """,
          F_DATE, FLD_EXEC,
          "Latest Event Date available in the source data, ignoring all filters. The report is always as-of the data, never as-of the calendar."),

        M("Earliest Business Date",
          "CALCULATE ( MIN ( 'Fact_IDR_Daily'[Event Date] ), REMOVEFILTERS ( ) )",
          F_DATE, FLD_EXEC,
          "Earliest Event Date available in the source data."),

        M("Selected Business Date",
          """
          -- The date the executive cards report on.
          -- Defaults to the latest loaded date; honours a narrower date selection
          -- so a manager can rewind the whole page to any historical day.
          VAR _maxData = CALCULATE ( MAX ( 'Fact_IDR_Daily'[Event Date] ), REMOVEFILTERS ( 'Dim_Date' ) )
          VAR _maxCtx = MAX ( 'Dim_Date'[Date] )
          RETURN
              IF ( ISBLANK ( _maxCtx ), _maxData, MIN ( _maxCtx, _maxData ) )
          """,
          F_DATE, FLD_EXEC,
          "The date all executive KPI cards evaluate at. Latest loaded date by default, or the end of the current date selection."),

        M("Previous Business Date",
          """
          -- Previous date that actually has data, not simply the selected date
          -- minus one, so gaps in the feed do not silently produce blank deltas.
          VAR _d = [Selected Business Date]
          RETURN
              CALCULATE (
                  MAX ( 'Fact_IDR_Daily'[Event Date] ),
                  REMOVEFILTERS ( 'Dim_Date' ),
                  'Fact_IDR_Daily'[Event Date] < _d
              )
          """,
          F_DATE, FLD_EXEC,
          "Previous date with data before the selected date. Gap-safe: skips missing days rather than returning blanks."),

        M("Data Through Label",
          """
          VAR _d = [Selected Business Date]
          RETURN
              IF ( ISBLANK ( _d ), "Data through: no data loaded",
                  "Data through: " & FORMAT ( _d, "dd-MMM-yyyy" ) )
          """,
          None, FLD_EXEC,
          "Header caption stating the business date the page is reporting on."),

        M("Date Range Label",
          """
          VAR _a = [Earliest Business Date]
          VAR _b = [Latest Business Date]
          RETURN
              IF ( ISBLANK ( _a ), "No data",
                  FORMAT ( _a, "dd-MMM-yyyy" ) & "  to  " & FORMAT ( _b, "dd-MMM-yyyy" )
                  & "   (" & FORMAT ( DATEDIFF ( _a, _b, DAY ) + 1, "#,##0" ) & " days)" )
          """,
          None, FLD_EXEC,
          "Full span of loaded history."),

        M("Last Refresh",
          """
          -- Model refresh timestamp, captured by the Power Query 'RefreshStamp'
          -- expression at load time.  Distinct from the business date.
          MAX ( 'Refresh Info'[Refreshed At] )
          """,
          "dd-mmm-yyyy hh:nn", FLD_EXEC,
          "Timestamp of the last semantic model refresh (local time of the refreshing machine)."),

        M("Last Refresh Label",
          """
          VAR _t = [Last Refresh]
          RETURN
              IF ( ISBLANK ( _t ), "Last refresh: unknown",
                  "Last refresh: " & FORMAT ( _t, "dd-MMM-yyyy HH:mm" ) )
          """,
          None, FLD_EXEC,
          "Header caption showing when the model last refreshed."),

        M("Baseline Day Count",
          """
          -- How many days of data actually sit in the 7-day baseline window.
          -- Statistical rules refuse to fire below the configured minimum: a
          -- z-score computed on two observations is not a z-score.
          VAR _d = [Selected Business Date]
          RETURN
              CALCULATE (
                  DISTINCTCOUNT ( 'Fact_IDR_Daily'[Event Date] ),
                  REMOVEFILTERS ( 'Dim_Date' ),
                  'Dim_Date'[Date] >= _d - 7 && 'Dim_Date'[Date] < _d
              ) + 0
          """,
          F_INT, FLD_CFG,
          "Number of days with data inside the 7-day baseline window. Gates every z-score and drift rule.",
          hidden=True),

        M("Timeframe Filter",
          """
          -- Disconnected timeframe slicer.  Windows are measured back from the
          -- latest loaded business date, never from TODAY(), so the report keeps
          -- working when the feed is a few days behind.
          VAR _days = SELECTEDVALUE ( 'Dim_Timeframe'[Days], 0 )
          VAR _max = [Latest Business Date]
          VAR _d = MAX ( 'Dim_Date'[Date] )
          RETURN
              SWITCH (
                  TRUE ( ),
                  _days = 0, 1,
                  ISBLANK ( _d ), 0,
                  _d > _max - _days && _d <= _max, 1,
                  0
              )
          """,
          F_INT, FLD_CFG,
          "Returns 1 when a date falls inside the selected timeframe window. Applied as a visual filter on the Historical Trends page.",
          hidden=True),
    ]


# --------------------------------------------------------------------------
# 2. base business measures
# --------------------------------------------------------------------------
def base_measures():
    out = []

    # ---- volume -----------------------------------------------------------
    vol = [
        ("Total EDL Logins", "Total EDL Logins", "All login events recorded in EDL."),
        ("Unique EDL Logins", "Unique EDL Logins", "Distinct logins recorded in EDL."),
        ("Total Kafka Logins Events", "Total Kafka Logins Events", "All login events observed on the Kafka stream."),
        ("Unique Kafka Logins", "Unique Kafka Logins at Profile", "Distinct Kafka logins matched at profile level."),
    ]
    for name, col, desc in vol:
        out.append(M(name, "SUM ( 'Fact_IDR_Daily'[%s] )" % col, F_COUNT, FLD_VOL, desc))

    # ---- IDR --------------------------------------------------------------
    idr = [
        ("IDR Resolved", "IDR Resolved", "Identity-resolution requests successfully resolved."),
        ("IDR Not Resolved", "IDR Not Resolved", "Identity-resolution requests that could not be resolved. The primary customer-impact signal."),
        ("Web IDR Resolved", "Web IDR Resolved", "Identities resolved through the web channel."),
        ("App IDR Resolved", "App IDR Resolved", "Identities resolved through the app channel."),
        ("Apps IDR Resolved EDL", "Apps IDR Resolved EDL", "App-resolved identities as counted on the EDL side."),
        ("Web IDR Resolved EDL", "Web IDR Resolved EDL", "Web-resolved identities as counted on the EDL side."),
    ]
    for name, col, desc in idr:
        out.append(M(name, "SUM ( 'Fact_IDR_Daily'[%s] )" % col, F_COUNT, FLD_IDR, desc))

    out += [
        M("IDR Total Requests",
          "[IDR Resolved] + [IDR Not Resolved]", F_COUNT, FLD_IDR,
          "Denominator for every resolution ratio: resolved plus unresolved requests."),

        M("Calculated IDR Resolution Rate",
          """
          -- Authoritative rate.  Recalculated from the underlying counts rather
          -- than read from the source percentage column, so an upstream
          -- reporting defect cannot mask a real deterioration.
          DIVIDE ( [IDR Resolved], [IDR Total Requests] )
          """,
          F_PCT2, FLD_IDR,
          "Resolution rate recalculated from resolved and unresolved counts. This is the rate every alert is judged against."),

        M("IDR Resolution Rate",
          "[Calculated IDR Resolution Rate]", F_PCT, FLD_IDR,
          "Share of IDR requests successfully resolved. Alias of the calculated rate, used everywhere in the report."),

        M("Source IDR Resolution Rate",
          """
          -- Volume-weighted average of the percentage published in the source file.
          -- The workbook ships that column empty on purpose - the dictionary
          -- says the rate is calculated over the selected range - so with no
          -- published value anywhere this is BLANK rather than zero. Returning
          -- zero would make the audit below read as a 100-point disagreement.
          VAR _rows =
              COUNTROWS (
                  FILTER ( 'Fact_IDR_Daily',
                           NOT ISBLANK ( 'Fact_IDR_Daily'[Overall IDR Resolution Rate] ) )
              )
          RETURN
              IF (
                  _rows > 0,
                  DIVIDE (
                      SUMX (
                          FILTER ( 'Fact_IDR_Daily',
                                   NOT ISBLANK ( 'Fact_IDR_Daily'[Overall IDR Resolution Rate] ) ),
                          'Fact_IDR_Daily'[Overall IDR Resolution Rate]
                              * ( 'Fact_IDR_Daily'[IDR Resolved] + 'Fact_IDR_Daily'[IDR Not Resolved] )
                      ),
                      CALCULATE (
                          [IDR Total Requests],
                          FILTER ( 'Fact_IDR_Daily',
                                   NOT ISBLANK ( 'Fact_IDR_Daily'[Overall IDR Resolution Rate] ) )
                      )
                  )
              )
          """,
          F_PCT2, FLD_IDR,
          "Volume-weighted average of the resolution rate as published in the source file. Used only to audit the source."),

        M("Source vs Calculated Resolution Rate Variance",
          """
          -- BLANK when there is nothing published to audit. Subtracting
          -- directly would not do: DAX reads BLANK as zero in arithmetic, so an
          -- empty source column would surface as a full-scale disagreement and
          -- fire rule R09 as critical every day.
          VAR _src = [Source IDR Resolution Rate]
          VAR _calc = [Calculated IDR Resolution Rate]
          RETURN IF ( NOT ISBLANK ( _src ), _src - _calc )
          """,
          F_PCT_SIGNED, FLD_IDR,
          "Gap between the published rate and the independently recalculated rate. Beyond tolerance the source percentage cannot be trusted."),

        M("IDR Non-Resolution Rate",
          """
          VAR _r = [Calculated IDR Resolution Rate]
          RETURN IF ( NOT ISBLANK ( _r ), 1 - _r )
          """,
          F_PCT, FLD_IDR,
          "Share of requests that failed to resolve."),

        M("Web Resolution %", "DIVIDE ( [Web IDR Resolved], [IDR Total Requests] )",
          F_PCT, FLD_IDR, "Web-resolved identities as a share of all IDR requests."),
        M("App Resolution %", "DIVIDE ( [App IDR Resolved], [IDR Total Requests] )",
          F_PCT, FLD_IDR, "App-resolved identities as a share of all IDR requests."),
        M("Web Contribution %", "DIVIDE ( [Web IDR Resolved], [IDR Resolved] )",
          F_PCT, FLD_IDR, "Web share of successfully resolved identities. Reveals channel mix shifts."),
        M("App Contribution %", "DIVIDE ( [App IDR Resolved], [IDR Resolved] )",
          F_PCT, FLD_IDR, "App share of successfully resolved identities."),
        M("IDR Not Resolved %", "DIVIDE ( [IDR Not Resolved], [IDR Total Requests] )",
          F_PCT2, FLD_IDR, "Unresolved requests as a share of all requests."),
    ]

    # ---- reconciliation ---------------------------------------------------
    out += [
        M("Total EDL vs Kafka Difference",
          """
          -- Signed on purpose.  Positive = EDL exceeds Kafka (the normal regime).
          -- Negative = Kafka exceeds EDL, which is a reconciliation control breach.
          [Total EDL Logins] - [Total Kafka Logins Events]
          """,
          F_COUNT_SIGNED, FLD_RECON,
          "Signed difference: EDL total minus Kafka total. Positive means EDL exceeds Kafka; negative means Kafka exceeds EDL."),

        M("Unique EDL vs Kafka Difference",
          "[Unique EDL Logins] - [Unique Kafka Logins]",
          F_COUNT_SIGNED, FLD_RECON,
          "Signed difference at identity level: unique EDL minus unique Kafka."),

        M("Source Total Difference",
          "SUM ( 'Fact_IDR_Daily'[Difference Total EDL vs Kafka Logins] )",
          F_COUNT_SIGNED, FLD_RECON,
          "Total difference as published in the source file. Audited against the recalculated difference."),

        M("Source Unique Difference",
          "SUM ( 'Fact_IDR_Daily'[Difference Unique EDL vs Kafka Logins] )",
          F_COUNT_SIGNED, FLD_RECON,
          "Unique difference as published in the source file."),

        M("Absolute Total Difference", "ABS ( [Total EDL vs Kafka Difference] )",
          F_COUNT, FLD_RECON, "Magnitude of the EDL/Kafka total gap, direction discarded."),
        M("Absolute Unique Difference", "ABS ( [Unique EDL vs Kafka Difference] )",
          F_COUNT, FLD_RECON, "Magnitude of the EDL/Kafka unique gap, direction discarded."),

        M("Total Reconciliation %",
          """
          -- Agreement rate.  1.0 means the two ecosystems agree exactly.
          VAR _edl = [Total EDL Logins]
          RETURN IF ( _edl > 0, 1 - DIVIDE ( [Absolute Total Difference], _edl ) )
          """,
          F_PCT, FLD_RECON,
          "How closely Kafka and EDL agree on total volume. Judged by drift against its own baseline, because the standing gap is structural."),

        M("Unique Reconciliation %",
          """
          VAR _edl = [Unique EDL Logins]
          RETURN IF ( _edl > 0, 1 - DIVIDE ( [Absolute Unique Difference], _edl ) )
          """,
          F_PCT, FLD_RECON,
          "How closely Kafka and EDL agree on unique identities."),

        M("Kafka to EDL Coverage %",
          "DIVIDE ( [Total Kafka Logins Events], [Total EDL Logins] )",
          F_PCT, FLD_RECON,
          "Kafka volume expressed as a share of EDL volume. Above 100% means Kafka is reporting more than EDL."),

        M("Total Difference % of EDL",
          "DIVIDE ( [Absolute Total Difference], [Total EDL Logins] )",
          F_PCT, FLD_RECON,
          "Absolute EDL/Kafka gap as a share of EDL volume."),

        M("Reconciliation Direction",
          """
          VAR _d = [Total EDL vs Kafka Difference]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _d ), "NO DATA",
                  _d < 0, "KAFKA > EDL",
                  _d > 0, "EDL > KAFKA",
                  "BALANCED"
              )
          """,
          None, FLD_RECON,
          "Plain-language direction of the total reconciliation gap."),

        M("Unique Reconciliation Direction",
          """
          VAR _d = [Unique EDL vs Kafka Difference]
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _d ), "NO DATA",
                  _d < 0, "KAFKA > EDL",
                  _d > 0, "EDL > KAFKA",
                  "BALANCED"
              )
          """,
          None, FLD_RECON,
          "Plain-language direction of the unique reconciliation gap."),
    ]

    # ---- overlap ----------------------------------------------------------
    ovr = [
        ("Web Only", "Web Only", "Identities seen only on web."),
        ("Kafka Only", "Kafka Only", "Identities seen only on the Kafka stream."),
        ("App Only", "App Only", "Identities seen only in the app."),
        ("Kafka and Web", "Kafka and Web", "Identities seen in both Kafka and web."),
        ("Kafka and Apps", "Kafka and Apps", "Identities seen in both Kafka and the app."),
        ("Web and Account", "Web and Account", "Identities seen in both web and the account system."),
        ("Kafka and Account", "Kafka and Account", "Identities seen in both Kafka and the account system."),
        ("Apps and Account", "Apps and Account", "Identities seen in both the app and the account system."),
    ]
    for name, col, desc in ovr:
        out.append(M(name, "SUM ( 'Fact_IDR_Daily'[%s] )" % col, F_COUNT, FLD_OVR, desc))

    out += [
        M("Overlap Population",
          """
          [Web Only] + [Kafka Only] + [App Only] + [Kafka and Web]
              + [Kafka and Apps] + [Web and Account] + [Kafka and Account] + [Apps and Account]
          """,
          F_COUNT, FLD_OVR,
          "Total identities across all eight exclusive and overlap populations."),

        M("Overlap Segment Population",
          "SUM ( 'Fact_Overlap_Daily'[Population] )", F_COUNT, FLD_OVR,
          "Population of the identity segment currently in context. Driven by the unpivoted overlap table."),

        M("Overlap Segment Share %",
          """
          DIVIDE (
              [Overlap Segment Population],
              CALCULATE ( [Overlap Segment Population], REMOVEFILTERS ( 'Fact_Overlap_Daily'[Segment] ) )
          )
          """,
          F_PCT, FLD_OVR,
          "Segment population as a share of the total overlap population for the same day."),

        M("Overlap Population %",
          "DIVIDE ( [Overlap Population], [Unique EDL Logins] )", F_PCT2, FLD_OVR,
          "Overlap population as a share of unique EDL logins - how much of the identity base sits in an ambiguous state."),
    ]
    return out


# --------------------------------------------------------------------------
# 3. trend-intelligence pattern
# --------------------------------------------------------------------------
# KPIs that receive the full pattern.  kind drives format strings and whether
# percentage-point variants are generated.
TREND_KPIS = [
    ("IDR Resolution Rate", "rate", FLD_IDR),
    ("IDR Non-Resolution Rate", "rate", FLD_IDR),
    ("IDR Not Resolved", "count", FLD_IDR),
    ("IDR Resolved", "count", FLD_IDR),
    ("Web IDR Resolved", "count", FLD_IDR),
    ("App IDR Resolved", "count", FLD_IDR),
    ("Web Resolution %", "rate", FLD_IDR),
    ("App Resolution %", "rate", FLD_IDR),
    ("Total EDL Logins", "count", FLD_VOL),
    ("Unique EDL Logins", "count", FLD_VOL),
    ("Total Kafka Logins Events", "count", FLD_VOL),
    ("Unique Kafka Logins", "count", FLD_VOL),
    ("Total EDL vs Kafka Difference", "signed", FLD_RECON),
    ("Unique EDL vs Kafka Difference", "signed", FLD_RECON),
    ("Total Reconciliation %", "rate", FLD_RECON),
    ("Total Difference % of EDL", "rate", FLD_RECON),
    ("Absolute Total Difference", "count", FLD_RECON),
    ("Absolute Unique Difference", "count", FLD_RECON),
    ("Unique Reconciliation %", "rate", FLD_RECON),
    ("Overlap Population", "count", FLD_OVR),
    ("Overlap Segment Population", "count", FLD_OVR),
]

_FMT_BY_KIND = {"rate": F_PCT, "count": F_COUNT, "signed": F_COUNT_SIGNED}
_FMT_DELTA_BY_KIND = {"rate": F_PCT_SIGNED, "count": F_COUNT_SIGNED, "signed": F_COUNT_SIGNED}


def trend_pattern(kpi, kind, folder):
    """Standard trend-intelligence set for one KPI.

    Every measure is gap-safe (uses the previous date that actually has data),
    baseline-safe (the 7-day baseline excludes the day being judged so an
    anomaly cannot dilute its own baseline) and blank-safe.
    """
    base = _FMT_BY_KIND[kind]
    dfmt = _FMT_DELTA_BY_KIND[kind]
    sub = "%s\\%s" % (FLD_TREND, kpi)
    q = "[%s]" % kpi
    out = []

    out.append(M("%s (Current)" % kpi,
                 """
                 VAR _d = [Selected Business Date]
                 RETURN
                     IF (
                         NOT ISBLANK ( _d ),
                         CALCULATE ( {Q}, REMOVEFILTERS ( 'Dim_Date' ), 'Dim_Date'[Date] = _d )
                     )
                 """.replace("{Q}", q),
                 base, sub, "%s on the selected business date." % kpi))

    out.append(M("%s (Previous Day)" % kpi,
                 """
                 VAR _d = [Previous Business Date]
                 RETURN
                     IF (
                         NOT ISBLANK ( _d ),
                         CALCULATE ( {Q}, REMOVEFILTERS ( 'Dim_Date' ), 'Dim_Date'[Date] = _d )
                     )
                 """.replace("{Q}", q),
                 base, sub, "%s on the previous date that has data." % kpi))

    out.append(M("%s (Delta)" % kpi,
                 """
                 VAR _c = [{K} (Current)]
                 VAR _p = [{K} (Previous Day)]
                 RETURN IF ( NOT ( ISBLANK ( _c ) || ISBLANK ( _p ) ), _c - _p )
                 """.replace("{K}", kpi),
                 dfmt, sub, "Day-on-day movement in %s." % kpi))

    out.append(M("%s (Delta %%)" % kpi,
                 """
                 VAR _c = [{K} (Current)]
                 VAR _p = [{K} (Previous Day)]
                 -- ABS on the denominator keeps the sign of the change meaningful
                 -- when the previous value is itself negative.
                 RETURN IF ( NOT ( ISBLANK ( _c ) || ISBLANK ( _p ) ), DIVIDE ( _c - _p, ABS ( _p ) ) )
                 """.replace("{K}", kpi),
                 F_PCT_SIGNED, sub, "Day-on-day percentage movement in %s." % kpi))

    out.append(M("%s (7D Avg)" % kpi,
                 """
                 VAR _d = [Selected Business Date]
                 RETURN
                     CALCULATE (
                         AVERAGEX ( VALUES ( 'Dim_Date'[Date] ), {Q} ),
                         REMOVEFILTERS ( 'Dim_Date' ),
                         'Dim_Date'[Date] > _d - 7 && 'Dim_Date'[Date] <= _d
                     )
                 """.replace("{Q}", q),
                 base, sub, "Rolling 7-day average of %s including the selected date." % kpi))

    out.append(M("%s (7D Baseline)" % kpi,
                 """
                 -- The seven days BEFORE the selected date.  Excluding the day under
                 -- judgement is what lets a single-day spike be detected at all.
                 VAR _d = [Selected Business Date]
                 RETURN
                     CALCULATE (
                         AVERAGEX ( VALUES ( 'Dim_Date'[Date] ), {Q} ),
                         REMOVEFILTERS ( 'Dim_Date' ),
                         'Dim_Date'[Date] >= _d - 7 && 'Dim_Date'[Date] < _d
                     )
                 """.replace("{Q}", q),
                 base, sub, "Mean of %s over the seven days before the selected date, excluding the selected date." % kpi))

    out.append(M("%s (vs 7D Baseline)" % kpi,
                 """
                 VAR _c = [{K} (Current)]
                 VAR _b = [{K} (7D Baseline)]
                 RETURN IF ( NOT ( ISBLANK ( _c ) || ISBLANK ( _b ) ), _c - _b )
                 """.replace("{K}", kpi),
                 dfmt, sub, "Movement of %s against its 7-day baseline." % kpi))

    out.append(M("%s (vs 7D Baseline %%)" % kpi,
                 """
                 VAR _c = [{K} (Current)]
                 VAR _b = [{K} (7D Baseline)]
                 RETURN IF ( NOT ( ISBLANK ( _c ) || ISBLANK ( _b ) ), DIVIDE ( _c - _b, ABS ( _b ) ) )
                 """.replace("{K}", kpi),
                 F_PCT_SIGNED, sub, "Percentage movement of %s against its 7-day baseline." % kpi))

    out.append(M("%s (7D StDev)" % kpi,
                 """
                 VAR _d = [Selected Business Date]
                 RETURN
                     CALCULATE (
                         STDEVX.P ( VALUES ( 'Dim_Date'[Date] ), {Q} ),
                         REMOVEFILTERS ( 'Dim_Date' ),
                         'Dim_Date'[Date] >= _d - 7 && 'Dim_Date'[Date] < _d
                     )
                 """.replace("{Q}", q),
                 base, sub, "Volatility of %s over the 7-day baseline window." % kpi, hidden=True))

    out.append(M("%s (Z-Score)" % kpi,
                 """
                 -- Blank rather than zero when there is no usable baseline, so a
                 -- brand new dataset cannot masquerade as "perfectly normal".
                 -- Also blank until the baseline window holds enough observations:
                 -- on two or three days the standard deviation is meaninglessly
                 -- small and every ordinary move looks like a five-sigma event.
                 VAR _s = [{K} (7D StDev)]
                 VAR _b = [{K} (7D Baseline)]
                 VAR _c = [{K} (Current)]
                 VAR _n = [Baseline Day Count]
                 RETURN
                     IF (
                         NOT ISBLANK ( _b ) && NOT ISBLANK ( _c ) && _s > 0
                             && _n >= [THR Warn MIN_BASELINE_DAYS],
                         DIVIDE ( _c - _b, _s )
                     )
                 """.replace("{K}", kpi),
                 F_Z, sub, "Standard deviations between the current %s and its 7-day baseline." % kpi))

    out.append(M("%s (Historical Avg)" % kpi,
                 """
                 VAR _d = [Selected Business Date]
                 RETURN
                     CALCULATE (
                         AVERAGEX ( VALUES ( 'Dim_Date'[Date] ), {Q} ),
                         REMOVEFILTERS ( 'Dim_Date' ),
                         'Dim_Date'[Date] <= _d
                     )
                 """.replace("{Q}", q),
                 base, sub, "Average of %s across all history up to the selected date." % kpi))

    out.append(M("%s (Historical Min)" % kpi,
                 """
                 VAR _d = [Selected Business Date]
                 RETURN
                     CALCULATE (
                         MINX ( VALUES ( 'Dim_Date'[Date] ), {Q} ),
                         REMOVEFILTERS ( 'Dim_Date' ),
                         'Dim_Date'[Date] <= _d
                     )
                 """.replace("{Q}", q),
                 base, sub, "Lowest observed %s up to the selected date." % kpi))

    out.append(M("%s (Historical Max)" % kpi,
                 """
                 VAR _d = [Selected Business Date]
                 RETURN
                     CALCULATE (
                         MAXX ( VALUES ( 'Dim_Date'[Date] ), {Q} ),
                         REMOVEFILTERS ( 'Dim_Date' ),
                         'Dim_Date'[Date] <= _d
                     )
                 """.replace("{Q}", q),
                 base, sub, "Highest observed %s up to the selected date." % kpi))

    out.append(M("%s (Trend)" % kpi,
                 """
                 VAR _chg = [{K} (vs 7D Baseline %)]
                 RETURN
                     SWITCH (
                         TRUE ( ),
                         ISBLANK ( _chg ), "-- no baseline",
                         _chg > 0.02, "Rising",
                         _chg < -0.02, "Falling",
                         "Stable"
                     )
                 """.replace("{K}", kpi),
                 None, sub, "Direction of travel for %s against its 7-day baseline." % kpi))

    out.append(M("%s (Volatility)" % kpi,
                 """
                 -- Coefficient of variation over the baseline window: how noisy this
                 -- metric normally is, used to judge whether a move is meaningful.
                 VAR _s = [{K} (7D StDev)]
                 VAR _b = [{K} (7D Baseline)]
                 RETURN IF ( _b <> 0, DIVIDE ( _s, ABS ( _b ) ) )
                 """.replace("{K}", kpi),
                 F_PCT, sub, "Coefficient of variation of %s over the baseline window." % kpi))

    if kind == "rate":
        out.append(M("%s (Delta pp)" % kpi,
                     "VAR _d = [{K} (Delta)] RETURN IF ( NOT ISBLANK ( _d ), _d * 100 )".replace("{K}", kpi),
                     F_PP, sub, "Day-on-day movement in %s expressed in percentage points." % kpi))
        out.append(M("%s (vs 7D Baseline pp)" % kpi,
                     "VAR _d = [{K} (vs 7D Baseline)] RETURN IF ( NOT ISBLANK ( _d ), _d * 100 )".replace("{K}", kpi),
                     F_PP, sub, "Movement of %s against its 7-day baseline, in percentage points." % kpi))
    return out


def trend_measures():
    out = []
    for kpi, kind, folder in TREND_KPIS:
        out += trend_pattern(kpi, kind, folder)
    return out
