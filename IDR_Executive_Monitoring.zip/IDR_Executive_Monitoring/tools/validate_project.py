"""Validates the generated PBIP project.

Three layers of checking:

  1. Schema      - every JSON file in the report is validated against the
                   official Microsoft PBIR schema (vendored in tools/schemas).
  2. References  - every measure and column the report binds to must exist in
                   the TMDL semantic model; every navigation target, tooltip
                   page and bookmark reference must exist.
  3. Layout      - visuals must sit inside their page, and no two content
                   visuals may overlap.

Run:  python tools/validate_project.py
Exit code 0 when clean, 1 when any problem is found.
"""
import glob
import json
import os
import re
import sys

from jsonschema import Draft7Validator
from referencing import Registry, Resource
from referencing.jsonschema import DRAFT7

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "IDR_Executive_Monitoring"
REPORT = os.path.join(ROOT, PROJECT + ".Report")
# PBIR is staged rather than shipped - Power BI Desktop reads the legacy
# report.json - so the structural checks run against the staging tree.
STAGE = os.path.join(ROOT, "build", "pbir")
MODEL = os.path.join(ROOT, PROJECT + ".SemanticModel")
SCHEMA_DIR = os.path.join(ROOT, "tools", "schemas")
BASE = "https://developer.microsoft.com/json-schemas/fabric/"

problems = []
notes = []

# Every project file that Power BI validates on open, mapped to the schema it
# must declare.  Power BI refuses to open the project when a $schema is missing
# or points at the wrong path, and the failure is fatal rather than cosmetic --
# so these are asserted explicitly rather than only validated when present.
REQUIRED_SCHEMAS = {
    "IDR_Executive_Monitoring.SemanticModel/definition.pbism":
        "item/semanticModel/definitionProperties/1.0.0/schema.json",
    "IDR_Executive_Monitoring.SemanticModel/.platform":
        "gitIntegration/platformProperties/2.0.0/schema.json",
    "IDR_Executive_Monitoring.Report/.platform":
        "gitIntegration/platformProperties/2.0.0/schema.json",
    "build/pbir/definition/report.json":
        "item/report/definition/report/1.0.0/schema.json",
    "build/pbir/definition/version.json":
        "item/report/definition/versionMetadata/1.0.0/schema.json",
    "build/pbir/definition/pages/pages.json":
        "item/report/definition/pagesMetadata/1.0.0/schema.json",
}

# Present only when the corresponding report feature is enabled.
OPTIONAL_SCHEMAS = {
    "build/pbir/definition/bookmarks/bookmarks.json":
        "item/report/definition/bookmarksMetadata/1.0.0/schema.json",
}


def fail(kind, path, msg):
    problems.append((kind, os.path.relpath(path, ROOT), msg))


# --------------------------------------------------------------------------
# schema registry from the vendored copies
# --------------------------------------------------------------------------
def build_registry():
    resources = {}
    for path in glob.glob(os.path.join(SCHEMA_DIR, "**", "*.json"), recursive=True):
        rel = os.path.relpath(path, SCHEMA_DIR).replace(os.sep, "/")
        doc = json.load(open(path, encoding="utf-8"))
        uri = BASE + rel
        resources[uri] = Resource.from_contents(doc, default_specification=DRAFT7)
        if "$id" in doc:
            resources[doc["$id"]] = resources[uri]
    return Registry().with_resources(resources.items())


REGISTRY = build_registry()
_validators = {}


def validate_against_schema(path, doc):
    uri = doc.get("$schema")
    if not uri:
        return
    if not uri.startswith(BASE):
        return
    rel = uri[len(BASE):]
    local = os.path.join(SCHEMA_DIR, *rel.split("/"))
    if not os.path.isfile(local):
        notes.append("no vendored schema for %s (skipped)" % rel)
        return
    if uri not in _validators:
        schema = json.load(open(local, encoding="utf-8"))
        _validators[uri] = Draft7Validator(schema, registry=REGISTRY)
    for err in sorted(_validators[uri].iter_errors(doc), key=lambda e: e.path):
        loc = "/".join(str(p) for p in err.absolute_path) or "(root)"
        fail("schema", path, "%s: %s" % (loc, err.message[:200]))


def check_required_schemas():
    """Assert the declared $schema on every file Power BI validates on open."""
    import re
    checks = [(r, sc, True) for r, sc in REQUIRED_SCHEMAS.items()]
    checks += [(r, sc, False) for r, sc in OPTIONAL_SCHEMAS.items()]
    for rel, schema_rel, required in sorted(checks):
        path = os.path.join(ROOT, *rel.split("/"))
        if not os.path.isfile(path):
            if required:
                fail("missing", path, "required project file not found")
            continue
        try:
            doc = json.load(open(path, encoding="utf-8"))
        except ValueError as e:
            fail("schema", path, "not valid JSON: %s" % e)
            continue
        declared = doc.get("$schema")
        if not declared:
            fail("schema", path,
                 "missing $schema; Power BI requires it and will refuse to open "
                 "the project. Expected %s%s" % (BASE, schema_rel))
            continue
        local = os.path.join(SCHEMA_DIR, *schema_rel.split("/"))
        if not os.path.isfile(local):
            notes.append("no vendored schema for %s (declaration unchecked)" % schema_rel)
            continue
        schema = json.load(open(local, encoding="utf-8"))
        pattern = schema.get("properties", {}).get("$schema", {}).get("pattern")
        if pattern and not re.match(pattern, declared):
            fail("schema", path,
                 "$schema is %s which does not match the required pattern %s"
                 % (declared, pattern))
            continue
        if not pattern and declared != BASE + schema_rel:
            fail("schema", path, "$schema is %s, expected %s"
                 % (declared, BASE + schema_rel))
            continue
        validate_against_schema(path, doc)


# --------------------------------------------------------------------------
# model inventory from the TMDL
# --------------------------------------------------------------------------
def model_inventory():
    tables, measures = {}, set()
    for path in glob.glob(os.path.join(MODEL, "definition", "tables", "*.tmdl")):
        txt = open(path, encoding="utf-8").read()
        m = re.search(r"^table (?:'([^']+)'|(\S+))", txt, re.M)
        name = m.group(1) or m.group(2)
        cols = set()
        for c in re.finditer(r"^\tcolumn (?:'([^']+)'|(\S+))", txt, re.M):
            cols.add(c.group(1) or c.group(2))
        tables[name] = cols
        for mm in re.finditer(r"^\tmeasure (?:'([^']+)'|(\S+))", txt, re.M):
            measures.add(mm.group(1) or mm.group(2))
    return tables, measures


# --------------------------------------------------------------------------
def walk_expressions(node, out):
    """Collect every Measure / Column reference in a visual or page document."""
    if isinstance(node, dict):
        for key in ("Measure", "Column", "HierarchyLevel", "Aggregation"):
            if key in node and isinstance(node[key], dict):
                ref = node[key]
                ent = (ref.get("Expression", {}).get("SourceRef", {}) or {}).get("Entity")
                prop = ref.get("Property")
                if ent and prop:
                    out.append((key, ent, prop))
        for v in node.values():
            walk_expressions(v, out)
    elif isinstance(node, list):
        for v in node:
            walk_expressions(v, out)


def main():
    tables, measures = model_inventory()
    print("model: %d tables, %d measures" % (len(tables), len(measures)))

    # ---- declared schemas on every file Power BI validates on open -------
    check_required_schemas()

    pages_meta = json.load(open(os.path.join(STAGE, "definition", "pages",
                                             "pages.json"), encoding="utf-8"))
    page_order = pages_meta["pageOrder"]

    # ---- pages and visuals ----------------------------------------------
    page_ids, visual_names = set(), {}
    tooltip_pages, drillthrough_pages = set(), set()
    nav_targets, tooltip_refs, bookmark_refs = [], [], []
    per_page_visuals = {}

    for pdir in sorted(glob.glob(os.path.join(STAGE, "definition", "pages", "*"))):
        if not os.path.isdir(pdir):
            continue
        ppath = os.path.join(pdir, "page.json")
        if not os.path.isfile(ppath):
            fail("missing", ppath, "page folder without page.json")
            continue
        pdoc = json.load(open(ppath, encoding="utf-8"))
        validate_against_schema(ppath, pdoc)
        pid = pdoc["name"]
        page_ids.add(pid)
        if pdoc.get("type") == "Tooltip":
            tooltip_pages.add(pid)
        if pdoc.get("type") == "Drillthrough":
            drillthrough_pages.add(pid)
        if os.path.basename(pdir) != pid:
            fail("naming", ppath, "folder %s does not match page name %s"
                 % (os.path.basename(pdir), pid))

        refs = []
        walk_expressions(pdoc, refs)

        pw, ph = pdoc["width"], pdoc["height"]
        boxes = []
        vis_docs = []
        for vpath in sorted(glob.glob(os.path.join(pdir, "visuals", "*", "visual.json"))):
            vdoc = json.load(open(vpath, encoding="utf-8"))
            validate_against_schema(vpath, vdoc)
            vis_docs.append((vpath, vdoc))
            name = vdoc["name"]
            if name in visual_names:
                fail("naming", vpath, "duplicate visual name %s (also in %s)"
                     % (name, visual_names[name]))
            visual_names[name] = pid
            if os.path.basename(os.path.dirname(vpath)) != name:
                fail("naming", vpath, "folder does not match visual name")

            pos = vdoc["position"]
            x, y, w, h = pos["x"], pos["y"], pos["width"], pos["height"]
            if x < 0 or y < 0 or x + w > pw + 0.5 or y + h > ph + 0.5:
                fail("layout", vpath,
                     "visual %s (%g,%g %gx%g) falls outside page %gx%g"
                     % (name, x, y, w, h, pw, ph))
            vtype = vdoc["visual"]["visualType"]
            # background panels and the header band are meant to sit behind
            is_backdrop = pos.get("z", 0) == 0 and vtype == "textbox"
            if not is_backdrop:
                boxes.append((name, x, y, w, h, vtype))

            walk_expressions(vdoc, refs)

            cont = vdoc["visual"].get("visualContainerObjects", {})
            for link in cont.get("visualLink", []):
                props = link.get("properties", {})
                t = props.get("type", {}).get("expr", {}).get("Literal", {}).get("Value", "")
                if "PageNavigation" in t:
                    target = props["navigationSection"]["expr"]["Literal"]["Value"].strip("'")
                    nav_targets.append((vpath, target))
                if "Bookmark" in t:
                    bookmark_refs.append(
                        (vpath, props["bookmark"]["expr"]["Literal"]["Value"].strip("'")))
            for tt in cont.get("visualTooltip", []):
                sect = tt.get("properties", {}).get("section")
                if sect:
                    tooltip_refs.append(
                        (vpath, sect["expr"]["Literal"]["Value"].strip("'")))

        per_page_visuals[pid] = len(vis_docs)

        # overlap check between foreground visuals
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                n1, x1, y1, w1, h1, t1 = boxes[i]
                n2, x2, y2, w2, h2, t2 = boxes[j]
                ox = min(x1 + w1, x2 + w2) - max(x1, x2)
                oy = min(y1 + h1, y2 + h2) - max(y1, y2)
                if ox > 1 and oy > 1:
                    area = ox * oy
                    smaller = min(w1 * h1, w2 * h2)
                    if area > 0.25 * smaller:
                        fail("layout", ppath,
                             "visuals overlap: %s (%s) and %s (%s), %g x %g px"
                             % (n1, t1, n2, t2, ox, oy))

        # reference check
        for kind, entity, prop in refs:
            if entity not in tables:
                fail("reference", ppath, "unknown table '%s' (property %s)" % (entity, prop))
            elif kind == "Measure":
                if prop not in measures:
                    fail("reference", ppath, "unknown measure [%s]" % prop)
            elif kind == "Column":
                if prop not in tables[entity]:
                    fail("reference", ppath, "unknown column %s[%s]" % (entity, prop))

    # ---- cross references ------------------------------------------------
    for path, target in nav_targets:
        if target not in page_ids:
            fail("reference", path, "navigation target page '%s' does not exist" % target)
    for path, target in tooltip_refs:
        if target not in page_ids:
            fail("reference", path, "tooltip page '%s' does not exist" % target)
        elif target not in tooltip_pages:
            fail("reference", path, "page '%s' is used as a tooltip but is not typed Tooltip" % target)

    bm_dir = os.path.join(STAGE, "definition", "bookmarks")
    bm_names = set()
    if os.path.isdir(bm_dir):
        meta = json.load(open(os.path.join(bm_dir, "bookmarks.json"), encoding="utf-8"))
        declared = {i["name"] for i in meta.get("items", [])}
        for bpath in glob.glob(os.path.join(bm_dir, "*.bookmark.json")):
            bdoc = json.load(open(bpath, encoding="utf-8"))
            validate_against_schema(bpath, bdoc)
            bm_names.add(bdoc["name"])
            for sect in bdoc["explorationState"]["sections"]:
                if sect not in page_ids:
                    fail("reference", bpath, "bookmark references unknown page '%s'" % sect)
        missing = declared - bm_names
        if missing:
            fail("reference", os.path.join(bm_dir, "bookmarks.json"),
                 "declared bookmarks with no definition file: %s" % ", ".join(sorted(missing)))
    for path, target in bookmark_refs:
        if target not in bm_names:
            fail("reference", path, "bookmark '%s' does not exist" % target)

    # ---- page order ------------------------------------------------------
    if set(page_order) != page_ids:
        fail("consistency", os.path.join(STAGE, "definition", "pages", "pages.json"),
             "pageOrder %s does not match the pages on disk %s"
             % (sorted(page_order), sorted(page_ids)))

    # ---- semantic model files -------------------------------------------
    for rel in ["definition/model.tmdl", "definition/database.tmdl",
                "definition/relationships.tmdl", "definition/expressions.tmdl",
                "definition.pbism", ".platform"]:
        path = os.path.join(MODEL, *rel.split("/"))
        if not os.path.isfile(path):
            fail("missing", path, "expected semantic model file not found")

    model_txt = open(os.path.join(MODEL, "definition", "model.tmdl"), encoding="utf-8").read()
    for t in tables:
        token = "ref table '%s'" % t if not t.replace("_", "").isalnum() else "ref table %s" % t
        if token not in model_txt:
            fail("consistency", os.path.join(MODEL, "definition", "model.tmdl"),
                 "table %s is not referenced in model.tmdl" % t)

    # ---- pbip ------------------------------------------------------------
    pbip = os.path.join(ROOT, PROJECT + ".pbip")
    if not os.path.isfile(pbip):
        fail("missing", pbip, "pbip entry point not found")
    else:
        doc = json.load(open(pbip, encoding="utf-8"))
        p = doc["artifacts"][0]["report"]["path"]
        if not os.path.isdir(os.path.join(ROOT, p)):
            fail("reference", pbip, "report path '%s' does not exist" % p)
    ref = json.load(open(os.path.join(REPORT, "definition.pbir"), encoding="utf-8"))
    dpath = ref["datasetReference"]["byPath"]["path"]
    if not os.path.isdir(os.path.normpath(os.path.join(REPORT, dpath))):
        fail("reference", os.path.join(REPORT, "definition.pbir"),
             "dataset path '%s' does not resolve" % dpath)

    # ---- report ----------------------------------------------------------
    print("report: %d pages, %d visuals" % (len(page_ids), sum(per_page_visuals.values())))
    for pid in page_order:
        print("   %-18s %3d visuals%s" % (pid, per_page_visuals.get(pid, 0),
                                          "  (tooltip)" if pid in tooltip_pages else
                                          "  (drillthrough)" if pid in drillthrough_pages else ""))
    print()
    if notes:
        for n in sorted(set(notes)):
            print("note: %s" % n)
        print()
    if problems:
        by_kind = {}
        for kind, path, msg in problems:
            by_kind.setdefault(kind, []).append((path, msg))
        print("PROBLEMS: %d" % len(problems))
        for kind in sorted(by_kind):
            print("  [%s] %d" % (kind, len(by_kind[kind])))
            for path, msg in by_kind[kind][:25]:
                print("     %s\n        %s" % (path, msg))
            if len(by_kind[kind]) > 25:
                print("     ... and %d more" % (len(by_kind[kind]) - 25))
        return 1
    print("VALIDATION PASSED - schema, references and layout are clean")
    return 0


if __name__ == "__main__":
    sys.exit(main())
