"""Builders for PBIR report definition JSON.

Everything the report generator emits goes through these helpers so the
expression encoding (literals, measure references, colour bindings) is written
once and stays consistent across ~200 visuals.
"""

SCHEMA_VISUAL = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/visualContainer/1.4.0/schema.json"
SCHEMA_PAGE = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/page/1.4.0/schema.json"
SCHEMA_PAGES = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/pagesMetadata/1.0.0/schema.json"
SCHEMA_REPORT = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/report/1.0.0/schema.json"
SCHEMA_BOOKMARK = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmark/1.0.0/schema.json"
SCHEMA_BOOKMARKS = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/bookmarksMetadata/1.0.0/schema.json"
SCHEMA_VERSION = "https://developer.microsoft.com/json-schemas/fabric/item/report/definition/versionMetadata/1.0.0/schema.json"
SCHEMA_PBIR = "https://developer.microsoft.com/json-schemas/fabric/item/report/definitionProperties/1.0.0/schema.json"
SCHEMA_PLATFORM = "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json"
# The .pbip shortcut lives under fabric/pbip/, not fabric/item/pbip/.
SCHEMA_PBIP = "https://developer.microsoft.com/json-schemas/fabric/pbip/pbipProperties/1.0.0/schema.json"
SCHEMA_PBISM = "https://developer.microsoft.com/json-schemas/fabric/item/semanticModel/definitionProperties/1.0.0/schema.json"

MEASURE_TABLE = "_Metrics"

# --------------------------------------------------------------------------
# palette - the single source of truth for report colour
# --------------------------------------------------------------------------
BG_PAGE = "#0A0E17"
BG_OUTSPACE = "#06090F"
BG_CARD = "#131A26"
BG_BAND = "#0E1524"
BG_PANEL = "#0F1622"
BORDER = "#223049"
BORDER_SOFT = "#1A2434"
TEXT_HI = "#E9EEF7"
TEXT_MID = "#9AA9BF"
TEXT_LOW = "#6B7B93"
GREEN = "#24C38E"
AMBER = "#F5A623"
RED = "#FF4D5E"
BLUE = "#3E8BFF"
CYAN = "#22C7DE"
PURPLE = "#8B7CF6"
GRID = "#1B2537"

FONT = "Segoe UI"
FONT_SEMI = "Segoe UI Semibold"
FONT_LIGHT = "Segoe UI Light"

PAGE_W = 1440
PAGE_H = 810


# --------------------------------------------------------------------------
# expression encoding
# --------------------------------------------------------------------------
def lit(v):
    """Literal expression container."""
    if isinstance(v, bool):
        val = "true" if v else "false"
    elif isinstance(v, int):
        val = "%dD" % v
    elif isinstance(v, float):
        val = "%gD" % v
    else:
        val = "'%s'" % str(v).replace("'", "''")
    return {"expr": {"Literal": {"Value": val}}}


def measure_expr(name, entity=MEASURE_TABLE):
    return {"Measure": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": name}}


def column_expr(entity, prop):
    return {"Column": {"Expression": {"SourceRef": {"Entity": entity}}, "Property": prop}}


def m_bound(name, entity=MEASURE_TABLE):
    """Property value bound to a measure (conditional formatting)."""
    return {"expr": measure_expr(name, entity)}


def solid(color):
    """Solid colour from a hex string."""
    return {"solid": {"color": lit(color)}}


def solid_m(measure_name, entity=MEASURE_TABLE):
    """Solid colour driven by a measure that returns a hex string."""
    return {"solid": {"color": {"expr": measure_expr(measure_name, entity)}}}


# --------------------------------------------------------------------------
# projections
# --------------------------------------------------------------------------
def pm(name, entity=MEASURE_TABLE, display=None, fmt=None):
    """Measure projection."""
    p = {"field": measure_expr(name, entity),
         "queryRef": "%s.%s" % (entity, name),
         "nativeQueryRef": name}
    if display:
        p["displayName"] = display
    if fmt:
        p["format"] = fmt
    return p


def pc(entity, prop, display=None, fmt=None):
    """Column projection."""
    p = {"field": column_expr(entity, prop),
         "queryRef": "%s.%s" % (entity, prop),
         "nativeQueryRef": prop}
    if display:
        p["displayName"] = display
    if fmt:
        p["format"] = fmt
    return p


def qref(proj):
    return proj["queryRef"]


# --------------------------------------------------------------------------
# formatting object helpers
# --------------------------------------------------------------------------
def obj(props, selector=None):
    o = {"properties": props}
    if selector:
        o["selector"] = selector
    return o


def sel_meta(queryref):
    return {"metadata": queryref}


def sel_id(name):
    return {"id": name}


# --------------------------------------------------------------------------
# visual container
# --------------------------------------------------------------------------
_tab = [0]


def visual(name, x, y, w, h, vtype, roles=None, objects=None, container=None,
           z=None, filters=None, sort=None, sync_group=None, hidden=False,
           parent=None):
    """Assemble one visual container."""
    _tab[0] += 1
    v = {
        "$schema": SCHEMA_VISUAL,
        "name": name,
        "position": {"x": x, "y": y, "z": _tab[0] if z is None else z,
                     "width": w, "height": h, "tabOrder": _tab[0] * 10},
        "visual": {"visualType": vtype},
    }
    if roles:
        q = {"queryState": {}}
        for role, spec in roles.items():
            # A role is either a plain list of projections, or a dict carrying
            # field-parameter metadata alongside the materialised projections.
            q["queryState"][role] = spec if isinstance(spec, dict) else {"projections": spec}
        if sort:
            q["sortDefinition"] = sort
        v["visual"]["query"] = q
    if objects:
        v["visual"]["objects"] = objects
    if container:
        v["visual"]["visualContainerObjects"] = container
    if sync_group:
        v["visual"]["syncGroup"] = sync_group
    if roles:
        v["visual"]["drillFilterOtherVisuals"] = True
    if filters:
        v["filterConfig"] = {"filters": filters}
    if hidden:
        v["isHidden"] = True
    if parent:
        v["parentGroupName"] = parent
    return v


def sort_by(field_expr, direction="Descending"):
    return {"sort": [{"field": field_expr, "direction": direction}],
            "isDefaultSort": False}


# --------------------------------------------------------------------------
# container chrome presets
# --------------------------------------------------------------------------
def chrome(title=None, title_measure=None, subtitle=None, subtitle_measure=None,
           bg=BG_CARD, border=BORDER, radius=8, title_size=11, transparent=False,
           title_color=TEXT_HI, pad=None):
    """Standard card chrome: background, border, title, subtitle, no header."""
    c = {
        "background": [obj({"show": lit(not transparent),
                            "color": solid(bg),
                            "transparency": lit(100 if transparent else 0)})],
        "border": [obj({"show": lit(border is not None and not transparent),
                        "color": solid(border or BORDER),
                        "radius": lit(radius)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
    }
    if title or title_measure:
        props = {
            "show": lit(True),
            "fontColor": solid(title_color),
            # A transparent container sits on a panel that already supplies the
            # surface colour, so the title must not paint its own.
            "alignment": lit("left"),
            "fontSize": lit(title_size),
            "fontFamily": lit(FONT_SEMI),
            "titleWrap": lit(False),
        }
        if not transparent:
            props["background"] = solid(bg)
        props["text"] = m_bound(title_measure) if title_measure else lit(title)
        c["title"] = [obj(props)]
    else:
        c["title"] = [obj({"show": lit(False)})]
    if subtitle or subtitle_measure:
        props = {
            "show": lit(True),
            "fontColor": solid(TEXT_MID),
            "alignment": lit("left"),
            "fontSize": lit(9),
            "fontFamily": lit(FONT),
            "titleWrap": lit(True),
        }
        props["text"] = m_bound(subtitle_measure) if subtitle_measure else lit(subtitle)
        c["subTitle"] = [obj(props)]
    if pad:
        c["padding"] = [obj({"top": lit(pad[0]), "right": lit(pad[1]),
                             "bottom": lit(pad[2]), "left": lit(pad[3])})]
    return c


def tooltip_page(page_name):
    """Bind a visual to a report-page tooltip."""
    return {"visualTooltip": [obj({"show": lit(True),
                                   "type": lit("Canvas"),
                                   "section": lit(page_name)})]}


# --------------------------------------------------------------------------
# common visuals
# --------------------------------------------------------------------------
def textbox(name, x, y, w, h, runs, align="left", bg=None, border=None,
            valign="middle", z=None):
    """runs = [(text, size_pt, color, weight)]"""
    text_runs = []
    for t in runs:
        text, size, color, weight = (t + (None,) * 4)[:4]
        style = {"fontSize": "%gpt" % size, "color": color or TEXT_HI}
        if weight:
            style["fontWeight"] = str(weight)
            style["fontFamily"] = FONT_SEMI
        else:
            style["fontFamily"] = FONT
        text_runs.append({"value": text, "textStyle": style})
    objects = {
        "general": [obj({"paragraphs": [
            {"textRuns": text_runs, "horizontalTextAlignment": align}]})],
    }
    cont = {
        "background": [obj({"show": lit(bg is not None),
                            "color": solid(bg or BG_CARD),
                            "transparency": lit(0 if bg else 100)})],
        "border": [obj({"show": lit(border is not None),
                        "color": solid(border or BORDER), "radius": lit(8)})],
        "title": [obj({"show": lit(False)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
        "general": [obj({"altText": lit(" ".join(r[0] for r in runs)[:120])})],
    }
    v = visual(name, x, y, w, h, "textbox", objects=objects, container=cont, z=z)
    v["visual"]["objects"]["general"][0]["properties"]["verticalTextAlignment"] = lit(valign)
    return v


def panel(name, x, y, w, h, bg=BG_CARD, border=BORDER, radius=8, z=0):
    """An empty card surface used as the background of a composed KPI tile."""
    return textbox(name, x, y, w, h, [(" ", 8, TEXT_HI)], bg=bg, border=border, z=z)


def nav_button(name, x, y, w, h, label, target_page, active=False):
    """Page-navigation button for the report navigation bar."""
    fill = BLUE if active else BG_CARD
    fg = "#FFFFFF" if active else TEXT_MID
    line = BLUE if active else BORDER
    # A button formatting object carries "show" on an entry with no selector,
    # and the appearance for a given button state on an entry selected by that
    # state's id. Putting both on the same entry leaves the button unstyled.
    objects = {
        "icon": [obj({"show": lit(False)})],
        "outline": [obj({"show": lit(True)}),
                    obj({"lineColor": solid(line), "weight": lit(1),
                         "transparency": lit(0), "roundEdge": lit(6)},
                        sel_id("default"))],
        "fill": [obj({"show": lit(True)}),
                 obj({"fillColor": solid(fill), "transparency": lit(0)},
                     sel_id("default"))],
        "text": [obj({"show": lit(True)}),
                 obj({"text": lit(label), "fontColor": solid(fg),
                      "fontSize": lit(9),
                      "fontFamily": lit(FONT_SEMI if active else FONT),
                      "bold": lit(False), "horizontalAlignment": lit("center"),
                      "verticalAlignment": lit("middle"),
                      "topMargin": lit(0), "bottomMargin": lit(0),
                      "leftMargin": lit(2), "rightMargin": lit(2)},
                     sel_id("default"))],
    }
    cont = {
        "visualLink": [obj({"show": lit(True), "type": lit("PageNavigation"),
                            "navigationSection": lit(target_page),
                            "tooltip": lit("Go to " + label)})],
        "background": [obj({"show": lit(False)})],
        "border": [obj({"show": lit(False)})],
        "title": [obj({"show": lit(False)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
    }
    return visual(name, x, y, w, h, "actionButton", objects=objects, container=cont)


def bookmark_button(name, x, y, w, h, label, bookmark_name):
    objects = {
        "icon": [obj({"show": lit(False)})],
        "outline": [obj({"show": lit(True)}),
                    obj({"lineColor": solid(BORDER), "weight": lit(1),
                         "roundEdge": lit(6)}, sel_id("default"))],
        "fill": [obj({"show": lit(True)}),
                 obj({"fillColor": solid(BG_CARD), "transparency": lit(0)},
                     sel_id("default"))],
        "text": [obj({"show": lit(True)}),
                 obj({"text": lit(label), "fontColor": solid(TEXT_MID),
                      "fontSize": lit(9), "fontFamily": lit(FONT),
                      "horizontalAlignment": lit("center"),
                      "verticalAlignment": lit("middle")}, sel_id("default"))],
    }
    cont = {
        "visualLink": [obj({"show": lit(True), "type": lit("Bookmark"),
                            "bookmark": lit(bookmark_name),
                            "tooltip": lit(label)})],
        "background": [obj({"show": lit(False)})],
        "border": [obj({"show": lit(False)})],
        "title": [obj({"show": lit(False)})],
        "visualHeader": [obj({"show": lit(False)})],
        "dropShadow": [obj({"show": lit(False)})],
    }
    return visual(name, x, y, w, h, "actionButton", objects=objects, container=cont)


def card(name, x, y, w, h, measure, title=None, subtitle_measure=None,
         value_color=None, value_color_measure=None, size=28, bg=BG_CARD,
         border=BORDER, transparent=False, units=1, precision=None,
         entity=MEASURE_TABLE, tooltip=None, title_size=10):
    """Classic card: one big number or text value, with dynamic caption."""
    label_props = {
        "color": (solid_m(value_color_measure) if value_color_measure
                  else solid(value_color or TEXT_HI)),
        "fontSize": lit(size),
        "fontFamily": lit(FONT_SEMI),
        # 1 = no display units: reconciliation numbers are read exactly,
        # never rounded to "1.7M".
        "labelDisplayUnits": lit(units),
    }
    if precision is not None:
        label_props["labelPrecision"] = lit(precision)
    objects = {
        "labels": [obj(label_props)],
        "categoryLabels": [obj({"show": lit(False)})],
        "wordWrap": [obj({"show": lit(True)})],
    }
    cont = chrome(title=title, subtitle_measure=subtitle_measure, bg=bg,
                  border=border, transparent=transparent, title_size=title_size)
    if tooltip:
        cont.update(tooltip_page(tooltip))
    return visual(name, x, y, w, h, "card",
                  roles={"Values": [pm(measure, entity)]},
                  objects=objects, container=cont)


def sparkline(name, x, y, w, h, measure, color=BLUE, entity=MEASURE_TABLE):
    """Minimal line chart used as an in-card sparkline: no chrome at all."""
    p = pm(measure, entity)
    objects = {
        "categoryAxis": [obj({"show": lit(False), "axisType": lit("Categorical")})],
        "valueAxis": [obj({"show": lit(False), "gridlineShow": lit(False)})],
        "legend": [obj({"show": lit(False)})],
        "labels": [obj({"show": lit(False)})],
        "plotArea": [obj({"transparency": lit(100)})],
        "lineStyles": [obj({"strokeWidth": lit(2), "showMarker": lit(False),
                            "lineStyle": lit("solid")})],
        "dataPoint": [obj({"fill": solid(color)}, sel_meta(qref(p)))],
    }
    cont = chrome(transparent=True)
    return visual(name, x, y, w, h, "lineChart",
                  roles={"Category": [pc("Dim_Date", "Date")], "Y": [p]},
                  objects=objects, container=cont)


def axis_objects(cat_title=None, val_title=None, val_start=None, val_end=None,
                 legend=False, legend_pos="Top", cat_type="Categorical",
                 gridlines=True, cat_size=9, val_size=9, cat_concat=False):
    o = {
        "categoryAxis": [obj({
            "show": lit(True), "axisType": lit(cat_type),
            "labelColor": solid(TEXT_MID), "fontSize": lit(cat_size),
            "fontFamily": lit(FONT),
            "showAxisTitle": lit(cat_title is not None),
            "gridlineShow": lit(False),
            "concatenateLabels": lit(cat_concat),
        })],
        "valueAxis": [obj({
            "show": lit(True), "labelColor": solid(TEXT_MID),
            "fontSize": lit(val_size), "fontFamily": lit(FONT),
            "showAxisTitle": lit(val_title is not None),
            "gridlineShow": lit(gridlines),
            "gridlineColor": solid(GRID),
            "gridlineThickness": lit(1),
            "gridlineStyle": lit("solid"),
        })],
        "legend": [obj({"show": lit(legend), "position": lit(legend_pos),
                        "labelColor": solid(TEXT_MID), "fontSize": lit(9),
                        "fontFamily": lit(FONT), "showTitle": lit(False)})],
        "plotArea": [obj({"transparency": lit(100)})],
    }
    if cat_title:
        o["categoryAxis"][0]["properties"]["titleColor"] = solid(TEXT_LOW)
        o["categoryAxis"][0]["properties"]["titleText"] = lit(cat_title)
    if val_title:
        o["valueAxis"][0]["properties"]["titleColor"] = solid(TEXT_LOW)
        o["valueAxis"][0]["properties"]["titleText"] = lit(val_title)
    if val_start is not None:
        o["valueAxis"][0]["properties"]["start"] = lit(val_start)
    if val_end is not None:
        o["valueAxis"][0]["properties"]["end"] = lit(val_end)
    return o


def series_color(projection, color):
    return obj({"fill": solid(color)}, sel_meta(qref(projection)))


def line_style(projection, width=2, marker=False, style="solid", marker_size=4):
    return obj({"strokeWidth": lit(width), "showMarker": lit(marker),
                "lineStyle": lit(style), "markerSize": lit(marker_size)},
               sel_meta(qref(projection)))


def table_objects(font_size=9, header_size=9, row_pad=4, wrap=False):
    return {
        "grid": [obj({
            "gridVertical": lit(False),
            "gridHorizontal": lit(True),
            "gridHorizontalColor": solid(BORDER_SOFT),
            "gridHorizontalWeight": lit(1),
            "outlineColor": solid(BORDER_SOFT),
            "outlineWeight": lit(0),
            "rowPadding": lit(row_pad),
            "textSize": lit(font_size),
        })],
        "columnHeaders": [obj({
            "fontColor": solid(TEXT_LOW),
            "backColor": solid(BG_CARD),
            "fontSize": lit(header_size),
            "fontFamily": lit(FONT_SEMI),
            "bold": lit(False),
            "alignment": lit("left"),
            "autoSizeColumnWidth": lit(True),
            "wordWrap": lit(True),
        })],
        "values": [obj({
            "fontColor": solid(TEXT_HI),
            "backColor": solid(BG_CARD),
            "fontColorPrimary": solid(TEXT_HI),
            "backColorPrimary": solid(BG_CARD),
            "fontColorSecondary": solid(TEXT_HI),
            "backColorSecondary": solid(BG_PANEL),
            "bandedRowHeadersandTotal": lit(True),
            "fontSize": lit(font_size),
            "fontFamily": lit(FONT),
            "wordWrap": lit(wrap),
        })],
        "total": [obj({"show": lit(False)})],
    }


def value_color_rule(projection, color_measure):
    """Colour one table/matrix column by a measure returning a hex string."""
    return obj({"fontColor": solid_m(color_measure)}, sel_meta(qref(projection)))


def value_back_rule(projection, color_measure):
    return obj({"backColor": solid_m(color_measure)}, sel_meta(qref(projection)))


# --------------------------------------------------------------------------
# filters
# --------------------------------------------------------------------------
def measure_filter(name, measure, comparison, value, entity=MEASURE_TABLE):
    """Advanced filter on a measure. comparison: 0 eq,1 gt,2 gte,3 lt,4 lte."""
    src = "f"
    return {
        "name": name,
        "field": measure_expr(measure, entity),
        "type": "Advanced",
        "filter": {
            "Version": 2,
            "From": [{"Name": src, "Entity": entity, "Type": 0}],
            "Where": [{"Condition": {"Comparison": {
                "ComparisonKind": comparison,
                "Left": {"Measure": {"Expression": {"SourceRef": {"Source": src}},
                                     "Property": measure}},
                "Right": {"Literal": {"Value": "%dL" % value}},
            }}}],
        },
        "howCreated": "User",
    }


def field_parameter(column, index=0, length=1):
    """Declares that the projections at `index` are supplied by a field parameter."""
    return {"parameterExpr": column, "index": index, "length": length}


def drillthrough_filter(name, entity, prop):
    return {
        "name": name,
        "field": column_expr(entity, prop),
        "type": "Categorical",
        "howCreated": "Drillthrough",
        "isHiddenInViewMode": False,
    }


# --------------------------------------------------------------------------
# page
# --------------------------------------------------------------------------
def page(name, display, ordinal, visuals, height=PAGE_H, width=PAGE_W,
         ptype=None, binding=None, filters=None, visibility=None,
         interactions=None):
    p = {
        "$schema": SCHEMA_PAGE,
        "name": name,
        "displayName": display,
        "displayOption": "FitToPage",
        "height": height,
        "width": width,
        "objects": {
            "background": [obj({"color": solid(BG_PAGE), "transparency": lit(0)})],
            "outspace": [obj({"color": solid(BG_OUTSPACE), "transparency": lit(0)})],
            "outspacePane": [obj({
                "backgroundColor": solid(BG_BAND),
                "foregroundColor": solid(TEXT_MID),
                "borderColor": solid(BORDER),
                "border": lit(True),
                "checkboxAndApplyColor": solid(BLUE),
                "inputBoxColor": solid(BG_CARD),
                "fontFamily": lit(FONT),
                "titleSize": lit(11),
                "headerSize": lit(9),
                "searchTextSize": lit(9),
                "width": lit(280),
            })],
        },
    }
    if ptype:
        p["type"] = ptype
    if binding:
        p["pageBinding"] = binding
    if filters:
        p["filterConfig"] = {"filters": filters}
    if visibility:
        p["visibility"] = visibility
    if interactions:
        p["visualInteractions"] = interactions
    return p, visuals
