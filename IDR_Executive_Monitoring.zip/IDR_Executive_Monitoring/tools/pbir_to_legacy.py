"""Convert the generated PBIR definition into the legacy PBIP report format.

Why this exists
---------------
Power BI Desktop 2.157 (August 2026) does not consume the PBIR ``definition/``
folder in a PBIP.  Opening a project that only has PBIR loads the semantic model
and then shows an empty report - no page tabs, blank canvas - with no error.
Saving from Desktop confirms it: Desktop deletes ``definition/`` and writes a
single ``Report/report.json`` holding ``{config, layoutOptimization, report,
sections}``.

So PBIR stays the authoring format - it is far easier to generate and validate -
and this module lowers it to the legacy shape that Desktop actually reads.

The two formats are closely related:

    PBIR                                    legacy
    ------------------------------------    ------------------------------------
    visual.objects                          singleVisual.objects        (identical)
    visual.visualContainerObjects           singleVisual.vcObjects      (identical)
    visual.query.queryState.<role>          singleVisual.projections.<role>
      .projections[].queryRef                 + singleVisual.prototypeQuery
    visual.position                         visualContainer.{x,y,...} + layouts[0]
    page.objects                            section.config.objects
    filterConfig.filters[].field            filters[].expression

The one real translation is the query: PBIR names fields inline, legacy needs a
``prototypeQuery`` that declares entity aliases up front and a ``projections``
map that refers back to it by ``queryRef``.
"""
import copy
import glob
import json
import os
import uuid

# Deterministic ids, so regenerating the report produces a byte-identical file.
NS = uuid.UUID("6f1c9b52-1f3e-5b7a-9c44-2f8d6e10a7b3")

# Legacy section display: 1 = fit the page into the available space.
FIT_TO_PAGE = 1

# Roles whose first projection carries the "active" marker, matching what
# Desktop writes for category axes and slicer fields.
ACTIVE_FIRST = {"Category"}

# legacy filter provenance ordinals
HOW_CREATED = {"User": 0, "Auto": 1, "Drillthrough": 2, "Included": 3, "Drilldown": 4}


def _guid(*parts):
    return str(uuid.uuid5(NS, "|".join(parts)))


# --------------------------------------------------------------------------
# query translation
# --------------------------------------------------------------------------
def _entity_of(field):
    """Entity a PBIR field expression is rooted at."""
    for kind in ("Measure", "Column", "HierarchyLevel", "Aggregation"):
        node = field.get(kind)
        if isinstance(node, dict):
            src = node.get("Expression", {}).get("SourceRef", {})
            if "Entity" in src:
                return src["Entity"]
    return None


def _rebind(field, alias):
    """Same field expression, but bound to a prototypeQuery alias."""
    out = copy.deepcopy(field)
    for kind in ("Measure", "Column", "HierarchyLevel", "Aggregation"):
        if kind in out:
            out[kind]["Expression"] = {"SourceRef": {"Source": alias}}
    return out


class _Aliases:
    """Assigns the short entity aliases a prototypeQuery uses ('o', 'o1', 'p')."""

    def __init__(self):
        self.by_entity = {}
        self._used = set()

    def get(self, entity):
        if entity in self.by_entity:
            return self.by_entity[entity]
        stem = next((c.lower() for c in entity if c.isalpha()), "e")
        alias, n = stem, 0
        while alias in self._used:
            n += 1
            alias = "%s%d" % (stem, n)
        self._used.add(alias)
        self.by_entity[entity] = alias
        return alias

    def froms(self):
        return [{"Name": a, "Entity": e, "Type": 0}
                for e, a in sorted(self.by_entity.items(), key=lambda kv: kv[1])]


def _query(visual):
    """(projections, prototypeQuery, columnProperties) for a data visual.

    PBIR carries a per-projection displayName; legacy keeps the friendly name
    in columnProperties, keyed by queryRef. Without it a table shows the raw
    measure name in its column header.
    """
    qstate = (visual.get("query") or {}).get("queryState") or {}
    if not qstate:
        return None, None, None

    aliases = _Aliases()
    projections, select, columns = {}, [], {}
    is_slicer = visual.get("visualType") == "slicer"

    for role, spec in qstate.items():
        entries = []
        for i, proj in enumerate(spec.get("projections", [])):
            field, ref = proj.get("field"), proj.get("queryRef")
            if not field or not ref:
                continue
            entity = _entity_of(field)
            if entity is None:
                continue
            alias = aliases.get(entity)
            item = {"queryRef": ref}
            if i == 0 and (role in ACTIVE_FIRST or (is_slicer and role == "Values")):
                item["active"] = True
            entries.append(item)
            sel = _rebind(field, alias)
            sel["Name"] = ref
            select.append(sel)
            if proj.get("displayName"):
                columns[ref] = {"displayName": proj["displayName"]}
        if entries:
            projections[role] = entries

    if not select:
        return None, None, None

    proto = {"Version": 2, "From": aliases.froms(), "Select": select}

    order = []
    for s in ((visual.get("query") or {}).get("sortDefinition") or {}).get("sort", []):
        field = s.get("field")
        entity = _entity_of(field or {})
        if not field or entity is None:
            continue
        order.append({
            "Direction": 2 if s.get("direction") == "Descending" else 1,
            "Expression": _rebind(field, aliases.get(entity)),
        })
    if order:
        proto["OrderBy"] = order

    return projections, proto, (columns or None)


# --------------------------------------------------------------------------
# visual / section translation
# --------------------------------------------------------------------------
def _filters(node):
    """PBIR filterConfig -> the legacy filters JSON string."""
    out = []
    for i, f in enumerate((node or {}).get("filters", [])):
        item = {"name": f.get("name"), "type": f.get("type", "Categorical")}
        if "field" in f:
            item["expression"] = f["field"]
        if "filter" in f:
            item["filter"] = f["filter"]
        # legacy records provenance as an ordinal, not the PBIR enum name
        item["howCreated"] = HOW_CREATED.get(f.get("howCreated"), 0)
        item["ordinal"] = i
        out.append(item)
    return json.dumps(out, separators=(",", ":"))


def legacy_visual(doc):
    """One PBIR visual.json -> one legacy visualContainer."""
    vis = doc.get("visual") or {}
    pos = doc.get("position") or {}
    single = {"visualType": vis.get("visualType")}

    projections, proto, columns = _query(vis)
    if projections:
        single["projections"] = projections
        single["prototypeQuery"] = proto
        if columns:
            single["columnProperties"] = columns

    single["drillFilterOtherVisuals"] = vis.get("drillFilterOtherVisuals", True)
    # Without this a slicer repeated on every page filters only its own page,
    # so the date range silently stops applying as soon as the user navigates.
    if vis.get("syncGroup"):
        single["syncGroup"] = vis["syncGroup"]
    if vis.get("objects"):
        single["objects"] = vis["objects"]
    if vis.get("visualContainerObjects"):
        single["vcObjects"] = vis["visualContainerObjects"]

    layout_pos = {k: pos[k] for k in ("x", "y", "z", "width", "height") if k in pos}
    layout_pos["tabOrder"] = pos.get("tabOrder", 0)

    config = {
        "name": doc["name"],
        "layouts": [{"id": 0, "position": layout_pos}],
        "singleVisual": single,
    }

    return {
        "x": pos.get("x", 0),
        "y": pos.get("y", 0),
        "z": pos.get("z", 0),
        "width": pos.get("width", 0),
        "height": pos.get("height", 0),
        "config": json.dumps(config, separators=(",", ":")),
        "filters": _filters(doc.get("filterConfig")),
    }


def legacy_section(page, visuals, ordinal):
    section_config = {}
    if page.get("objects"):
        section_config["objects"] = page["objects"]

    return {
        "id": ordinal,
        "name": page["name"],
        "displayName": page.get("displayName", page["name"]),
        "objectId": _guid("section", page["name"]),
        "filters": "[]",
        "ordinal": ordinal,
        "width": page.get("width", 1280),
        "height": page.get("height", 720),
        "displayOption": FIT_TO_PAGE,
        "config": json.dumps(section_config, separators=(",", ":")),
        "visualContainers": visuals,
    }


# --------------------------------------------------------------------------
# entry point
# --------------------------------------------------------------------------
def build_legacy(definition_dir):
    """Read a PBIR definition folder and return the legacy report.json dict."""
    pages_dir = os.path.join(definition_dir, "pages")
    meta = json.load(open(os.path.join(pages_dir, "pages.json"), encoding="utf-8"))
    order = meta.get("pageOrder", [])

    sections = []
    for ordinal, name in enumerate(order):
        page_path = os.path.join(pages_dir, name, "page.json")
        if not os.path.exists(page_path):
            continue
        page = json.load(open(page_path, encoding="utf-8"))

        # A tooltip page needs a legacy "pod" to be reachable; without one it
        # would show up as an ordinary page, so it is left out entirely.
        if page.get("type") == "Tooltip":
            continue

        docs = []
        for vpath in sorted(glob.glob(os.path.join(pages_dir, name, "visuals",
                                                   "*", "visual.json"))):
            docs.append(json.load(open(vpath, encoding="utf-8")))
        docs.sort(key=lambda d: d.get("position", {}).get("z", 0))
        sections.append(legacy_section(page, [legacy_visual(d) for d in docs],
                                       len(sections)))

    config = {
        "version": "5.37",
        "themeCollection": {},
        "activeSectionIndex": 0,
        "linguisticSchemaSyncVersion": 2,
    }

    return {
        "config": json.dumps(config, separators=(",", ":")),
        "layoutOptimization": 0,
        "report": {},
        "sections": sections,
    }


def main():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    definition = os.path.join(root, "build", "pbir", "definition")
    out = os.path.join(root, "IDR_Executive_Monitoring.Report", "report.json")
    doc = build_legacy(definition)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, indent=2)
    total = sum(len(s["visualContainers"]) for s in doc["sections"])
    print("legacy report written to %s" % out)
    print("  sections: %d   visuals: %d" % (len(doc["sections"]), total))


if __name__ == "__main__":
    main()
