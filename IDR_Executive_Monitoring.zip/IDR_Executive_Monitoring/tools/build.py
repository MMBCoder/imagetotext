"""Regenerates the whole PBIP project and validates it.

Run:  python tools/build.py
Exit code 0 when every stage passes.
"""
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TOOLS = os.path.join(ROOT, "tools")

STAGES = [
    ("generate business glossary", "gen_metric_definitions.py"),
    ("generate semantic model", "gen_semantic_model.py"),
    ("generate report", "gen_report.py"),
    ("generate data dictionary", "gen_docs.py"),
    ("validate project structure", "validate_project.py"),
    ("validate data and alert logic", "validate_data.py"),
]


def main():
    failures = []
    for label, script in STAGES:
        print("=" * 72)
        print("  %s  (%s)" % (label, script))
        print("=" * 72)
        r = subprocess.run([sys.executable, os.path.join(TOOLS, script)],
                           cwd=ROOT)
        if r.returncode != 0:
            failures.append(label)
        print()

    print("=" * 72)
    if failures:
        print("BUILD FAILED: %s" % ", ".join(failures))
        return 1
    print("BUILD OK - project regenerated and validated")
    print()
    print("Open IDR_Executive_Monitoring.pbip in Power BI Desktop,")
    print("then File > Save as > .pbix to produce a binary file.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
