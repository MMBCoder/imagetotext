"""Metric-selector measures.

One set of measures serves two surfaces:

  * Historical Trends - the field parameter picks a metric and these measures
    report its current value, baseline, range, volatility and direction.
  * Root Cause Explorer - the same measures render one row per metric, so a
    manager sees every headline metric moving side by side on one date.

Both resolve through the same COALESCE, so there is a single implementation of
"the selected metric" rather than two that can drift apart.
"""

from model_measures import (M, F_COUNT, F_PCT, F_Z, F_INT, F_SCORE,
                            FLD_TREND, FLD_UX, FLD_ALERT)
from model_measures_alerts import C_GREEN, C_AMBER, C_RED, C_NEUTRAL

LF = chr(10)

# metric label -> (format string, severity rule measure or None)
WATCH_METRICS = [
    ("IDR Resolution Rate", "0.00%", "Sev Rank IDR Resolution"),
    ("IDR Non-Resolution Rate", "0.00%", "Sev Rank IDR Resolution"),
    ("IDR Not Resolved", "#,##0", "Sev Rank IDR Not Resolved"),
    ("IDR Resolved", "#,##0", "Sev Rank IDR Resolution"),
    ("Web IDR Resolved", "#,##0", None),
    ("App IDR Resolved", "#,##0", None),
    ("Web Resolution %", "0.0%", None),
    ("App Resolution %", "0.0%", None),
    ("Total EDL Logins", "#,##0", "Sev Rank Volume"),
    ("Unique EDL Logins", "#,##0", "Sev Rank Volume"),
    ("Total Kafka Logins Events", "#,##0", "Sev Rank Volume"),
    ("Unique Kafka Logins", "#,##0", "Sev Rank Volume"),
    ("Total EDL vs Kafka Difference", "+#,##0;-#,##0;0", "Sev Rank Direction"),
    ("Unique EDL vs Kafka Difference", "+#,##0;-#,##0;0", "Sev Rank Direction"),
    ("Total Reconciliation %", "0.0%", "Sev Rank Reconciliation"),
    ("Unique Reconciliation %", "0.0%", "Sev Rank Reconciliation"),
    ("Absolute Total Difference", "#,##0", "Sev Rank Reconciliation"),
    ("Overlap Population", "#,##0", "Sev Rank Overlap"),
]

SELECTED = (
    "          -- The selected metric, resolved from either surface: the Root Cause\n"
    "          -- table (one row per metric) or the Historical Trends field parameter.\n"
    "          VAR _sel =\n"
    "              COALESCE (\n"
    "                  SELECTEDVALUE ( 'Dim_Metric_Watch'[Metric] ),\n"
    "                  SELECTEDVALUE ( 'Trend Metric'[Trend Metric] )\n"
    "              )\n"
)


def _switch(body_fn, indent="          "):
    lines = [SELECTED, indent + "RETURN\n", indent + "    SWITCH (\n",
             indent + "        _sel,\n"]
    for label, fmt, _sev in WATCH_METRICS:
        lines.append(indent + '        "%s", %s,\n' % (label, body_fn(label, fmt)))
    lines.append(indent + "        BLANK ( )\n")
    lines.append(indent + "    )\n")
    return "".join(lines)


def selector_measures():
    out = []

    def in_timeframe(dax):
        """Blank outside the window chosen on the timeframe slicer.

        Historical Trends used to restrict its visuals with a visual-level
        filter on [Timeframe Filter]. A legacy visual filter on a measure is
        evaluated outside the row context of the visual, which empties the
        whole visual, so the window is applied in the measure instead.
        Timeframe Filter returns 1 when nothing is selected, so pages without
        the slicer are unaffected.
        """
        return (LF + "          IF ( [Timeframe Filter] = 1," + LF
                + dax.rstrip() + LF + "          )" + LF + "          ")

    def text_variant(suffix, desc, fmt_override=None, name_suffix=None):
        nm = "Selected Metric %s" % (name_suffix or suffix.strip("() "))
        dax = _switch(lambda label, fmt:
                      'FORMAT ( [%s %s], "%s" )' % (label, suffix, fmt_override or fmt))
        return M(nm, in_timeframe(dax), None, FLD_TREND, desc)

    out.append(M("Selected Metric Name",
                 SELECTED + "          RETURN COALESCE ( _sel, \"No metric selected\" )\n",
                 None, FLD_TREND,
                 "Label of the metric currently selected on Historical Trends, or the metric in row context on Root Cause Explorer."))

    out.append(text_variant("(Current)", "Current value of the selected metric on the selected business date."))
    out.append(text_variant("(Previous Day)", "Value of the selected metric on the previous date with data."))
    out.append(text_variant("(Delta)", "Day-on-day movement in the selected metric.",
                            name_suffix="Delta"))
    out.append(text_variant("(7D Baseline)", "Seven-day baseline of the selected metric, excluding the selected date.",
                            name_suffix="7D Baseline"))
    out.append(text_variant("(7D Avg)", "Rolling seven-day average of the selected metric.",
                            name_suffix="7D Avg"))
    out.append(text_variant("(Historical Avg)", "All-history average of the selected metric.",
                            name_suffix="Historical Avg"))
    out.append(text_variant("(Historical Min)", "Lowest observed value of the selected metric.",
                            name_suffix="Historical Min"))
    out.append(text_variant("(Historical Max)", "Highest observed value of the selected metric.",
                            name_suffix="Historical Max"))
    out.append(text_variant("(Delta %)", "Day-on-day percentage movement in the selected metric.",
                            fmt_override="+0.0%;-0.0%;0.0%", name_suffix="Delta Pct"))
    out.append(text_variant("(vs 7D Baseline %)",
                            "Movement of the selected metric against its seven-day baseline.",
                            fmt_override="+0.0%;-0.0%;0.0%", name_suffix="vs Baseline Pct"))
    out.append(text_variant("(Volatility)",
                            "Coefficient of variation of the selected metric over the baseline window.",
                            fmt_override="0.0%", name_suffix="Volatility"))

    # Numeric current value. The text variants above are formatted per metric
    # and cannot be plotted, so the trend chart needs this one.
    out.append(M("Selected Metric Value",
                 in_timeframe(_switch(lambda label, fmt: "[%s (Current)]" % label)),
                 None, FLD_TREND,
                 "Current value of the selected metric as a number, for charting. "
                 "Blank outside the selected timeframe window."))

    # numeric z-score (kept numeric so it can drive conditional formatting)
    out.append(M("Selected Metric Z-Score",
                 _switch(lambda label, fmt: "[%s (Z-Score)]" % label),
                 F_Z, FLD_TREND,
                 "Standard deviations between the selected metric and its seven-day baseline."))

    out.append(M("Selected Metric Trend",
                 _switch(lambda label, fmt: "[%s (Trend)]" % label),
                 None, FLD_TREND,
                 "Direction of travel of the selected metric against its seven-day baseline."))

    # severity of the selected metric, via the rule that governs it
    def sev_body(label, fmt):
        for lbl, _f, sev in WATCH_METRICS:
            if lbl == label:
                return "[%s]" % sev if sev else "BLANK ( )"
        return "BLANK ( )"

    out.append(M("Selected Metric Severity Rank",
                 _switch(sev_body), F_INT, FLD_ALERT,
                 "Severity rank of the alert rule governing the selected metric.",
                 hidden=True))

    out.append(M("Selected Metric Severity",
                 """
                 VAR _r = [Selected Metric Severity Rank]
                 RETURN
                     SWITCH ( _r, 3, "CRITICAL", 2, "WARNING", 1, "OK", "-" )
                 """,
                 None, FLD_ALERT,
                 "Severity of the alert rule governing the selected metric."))

    out.append(M("Selected Metric Colour",
                 """
                 SWITCH ( [Selected Metric Severity Rank], 3, "{RED}", 2, "{AMBER}",
                     1, "{GREEN}", "{NEUTRAL}" )
                 """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
                    .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
                 None, FLD_UX,
                 "Semantic colour for the selected metric.", hidden=True))

    out.append(M("Selected Metric Range",
                 """
                 [Selected Metric Historical Min] & "   to   " & [Selected Metric Historical Max]
                 """,
                 None, FLD_TREND,
                 "Observed range of the selected metric across all loaded history."))
    return out


# --------------------------------------------------------------------------
# data-quality check catalogue
# --------------------------------------------------------------------------
DQ_CHECKS = [
    ("DQ01", "Missing Event Date", "Structural", "DQ Missing Event Date",
     "Rows with no business date. Such rows cannot be placed on any trend."),
    ("DQ02", "Duplicate Event Date", "Structural", "DQ Duplicate Date Count",
     "More than one row for the same date. Breaks the daily grain and double counts every SUM."),
    ("DQ03", "Null in required column", "Structural", "DQ Null Value Count",
     "A column that must always be populated is empty."),
    ("DQ04", "Negative count value", "Structural", "DQ Negative Value Count",
     "A count column holds a negative number. The two difference columns are excluded: negative is valid there."),
    ("DQ05", "Web + App does not equal IDR Resolved", "Arithmetic", "DQ IDR Consistency Breaches",
     "Channel-level resolved counts do not reconcile to the total."),
    ("DQ06", "Published difference disagrees with recomputed", "Arithmetic",
     "DQ Reconciliation Consistency Breaches",
     "The published EDL/Kafka difference does not equal the difference recomputed from the volume columns."),
    ("DQ07", "Published rate outside 0-100%", "Arithmetic", "DQ Unexpected Resolution Rate Count",
     "The published resolution rate is not a valid proportion."),
    ("DQ08", "Published rate differs from recalculated rate", "Trust", "DQ Rate Variance Breaches",
     "The source percentage disagrees with the rate recalculated from the counts beyond tolerance."),
    ("DQ09", "Missing calendar day", "Completeness", "DQ Missing Day Count",
     "A day inside the loaded range carries no data at all."),
    ("DQ10", "Unexpected volume movement", "Analytical", "DQ Unexpected Volume Movement Count",
     "Login volume beyond the critical z-score tolerance. Reported here, alerted through Rule 6."),
    ("DQ11", "Unexpected overlap movement", "Analytical", "DQ Unexpected Overlap Movement Count",
     "An identity population beyond the critical tolerance. Reported here, alerted through Rule 5."),
    ("DQ12", "Unexpected resolution movement", "Analytical", "DQ Unexpected Resolution Movement Count",
     "Resolution rate below the critical threshold. Reported here, alerted through Rule 1."),
]


def dq_check_measures():
    branches = "".join(
        '                  "%s", [%s],\n' % (key, meas)
        for key, _n, _c, meas, _d in DQ_CHECKS)
    return [
        M("DQ Check Count",
          """
          SWITCH (
              SELECTEDVALUE ( 'Dim_DQ_Checks'[Check Key] ),
%s                  BLANK ( )
          )
          """ % branches,
          F_INT, "07 - Data Quality",
          "Number of rows failing the data-quality check in row context."),

        M("DQ Check Status",
          """
          -- Analytical checks are informational: they are alerted through the
          -- rule engine, not counted as defects in the data.
          VAR _n = [DQ Check Count]
          VAR _cat = SELECTEDVALUE ( 'Dim_DQ_Checks'[Category] )
          RETURN
              SWITCH (
                  TRUE ( ),
                  ISBLANK ( _n ), "-",
                  _cat = "Analytical" && _n > 0, "INFORMATIONAL",
                  _n = 0, "PASS",
                  _cat = "Trust" || _cat = "Completeness", "WARNING",
                  "CRITICAL"
              )
          """,
          None, "07 - Data Quality",
          "Verdict for the data-quality check in row context."),

        M("DQ Check Colour",
          """
          SWITCH ( [DQ Check Status], "CRITICAL", "{RED}", "WARNING", "{AMBER}",
              "INFORMATIONAL", "{BLUE}", "PASS", "{GREEN}", "{NEUTRAL}" )
          """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
             .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL)
             .replace("{BLUE}", "#3E8BFF"),
          None, FLD_UX,
          "Semantic colour for the data-quality check in row context.", hidden=True),
    ]
