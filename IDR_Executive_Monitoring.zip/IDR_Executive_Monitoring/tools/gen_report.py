"""Builds the IDR Executive Monitoring report.

Reading order, and why the pages are in this order
--------------------------------------------------
1. Overview               what happened over the dates I selected
2. EDL vs CDP Volume      do the two platforms agree on volume
3. IDR Resolution         how much resolved, split by web and app
4. Why Resolution Failed  which missing event is costing us the most
5. Daily Detail           every source field, one row per event date
6. Alerts & Data Quality  what to investigate, and whether to trust the data
7. Definitions            the source data dictionary

Everything responds to one date-range slicer that is synced across pages, so
"the selected period" means the same thing everywhere. Headline numbers are
sums over that period, and the resolution rate follows the source dictionary:
sum(idr resolved) / sum(idr resolved + idr not resolved).

Layout rules, kept deliberately strict so nothing is clipped:
  * at most ~20 containers on a page
  * body text 10pt, panel titles 12pt, KPI values 30pt
  * every table wraps and every card word-wraps
  * one grid: M outside, G between, nothing overlaps
"""
import json
import os
import shutil
import time
import uuid

from report_lib import (
    BG_PAGE, BG_CARD, BG_PANEL, BORDER,
    TEXT_HI, TEXT_MID, TEXT_LOW, GREEN, AMBER, RED, BLUE,
    FONT, FONT_SEMI, PAGE_W, PAGE_H,
    lit, obj, solid, pm, pc, qref, sel_meta,
    measure_expr, column_expr, visual, chrome, textbox, panel, nav_button,
    card, axis_objects, table_objects, value_color_rule, sort_by, page,
    SCHEMA_PAGES, SCHEMA_REPORT, SCHEMA_VERSION, SCHEMA_PLATFORM,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "IDR_Executive_Monitoring"
REPORT_DIR = os.path.join(ROOT, PROJECT + ".Report")

# PBIR is the authoring format: one file per visual is easy to generate and to
# validate against the published schemas. It is NOT what ships - Power BI
# Desktop 2.157 ignores a PBIR definition folder inside a PBIP and opens an
# empty report - so it is staged here and lowered by pbir_to_legacy.
STAGE_DIR = os.path.join(ROOT, "build", "pbir")
DEF = os.path.join(STAGE_DIR, "definition")

NS = uuid.UUID("2b7e4d10-5c9a-5f3e-8a61-7d4c2e9b0f15")

# --------------------------------------------------------------------------
# layout grid
# --------------------------------------------------------------------------
M = 28                       # page margin
G = 16                       # gutter
CW = PAGE_W - 2 * M          # content width

HEAD_Y = 16
NAV_Y = 116
NAV_H = 32
BODY_Y = 162
KPI_H = 112

FS_TITLE = 19
FS_SUB = 10
FS_CARD_TITLE = 10
FS_CARD_VALUE = 30
FS_PANEL_TITLE = 12
FS_BODY = 10

DATE_SYNC = {"groupName": "syncEventDate", "fieldChanges": False,
             "filterChanges": True}

PAGES = [
    ("pgOverview", "Overview", "OVERVIEW"),
    ("pgVolume", "EDL vs CDP Volume", "VOLUME"),
    ("pgResolution", "IDR Resolution", "RESOLUTION"),
    ("pgWhyFailed", "Why Resolution Failed", "WHY FAILED"),
    ("pgDetail", "Daily Detail", "DAILY DETAIL"),
    ("pgAlerts", "Alerts & Data Quality", "ALERTS & DQ"),
    ("pgDefinitions", "Definitions", "DEFINITIONS"),
]

_seq = [0]


def vn(prefix):
    _seq[0] += 1
    return "%s%04d" % (prefix, _seq[0])


def rmtree_resilient(path, attempts=5):
    """Remove a generated folder, tolerating transient cloud-sync locks."""
    if not os.path.isdir(path):
        return
    for i in range(attempts):
        try:
            shutil.rmtree(path)
            return
        except OSError:
            time.sleep(0.4 * (i + 1))
    for root, dirs, files in os.walk(path, topdown=False):
        for f in files:
            try:
                os.remove(os.path.join(root, f))
            except OSError:
                pass
        for d in dirs:
            try:
                os.rmdir(os.path.join(root, d))
            except OSError:
                pass


def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


# --------------------------------------------------------------------------
# shared furniture
# --------------------------------------------------------------------------
def date_slicer(x, y, w, h):
    """The one control that defines "the selected period", synced everywhere."""
    objects = {
        "general": [obj({"outlineColor": solid(BORDER), "outlineWeight": lit(1)})],
        "data": [obj({"mode": lit("Between")})],
        "header": [obj({"show": lit(False)})],
        "items": [obj({"fontColor": solid(TEXT_HI), "background": solid(BG_CARD),
                       "fontSize": lit(FS_BODY), "fontFamily": lit(FONT)})],
        "date": [obj({"fontColor": solid(TEXT_HI), "fontSize": lit(FS_BODY),
                      "fontFamily": lit(FONT)})],
    }
    return visual(vn("dateSlicer"), x, y, w, h, "slicer",
                  roles={"Values": [pc("Dim_Date", "Date")]},
                  objects=objects, sync_group=DATE_SYNC,
                  container=chrome(title="EVENT DATE RANGE", title_size=FS_SUB,
                                   bg=BG_PANEL))


def header(page_id, title, subtitle):
    """Title, live period label, date slicer and the page navigation bar."""
    v = []
    v.append(panel(vn("hdrBand"), 0, 0, PAGE_W, NAV_Y + NAV_H + 8,
                   bg=BG_PANEL, border=None, z=0))
    # A 19pt run needs ~34px of line box; a 30px container clips the glyph tops.
    v.append(textbox(vn("hdrTitle"), M, HEAD_Y - 4, 700, 40,
                     [(title, FS_TITLE, TEXT_HI)]))
    v.append(textbox(vn("hdrSub"), M, HEAD_Y + 36, 700, 34,
                     [(subtitle, FS_SUB, TEXT_MID)]))

    # The period label is a measure, so it always states the dates actually in
    # effect rather than a caption someone has to remember to update.
    v.append(card(vn("hdrPeriod"), PAGE_W - M - 690, HEAD_Y + 8, 340, 52,
                  "Selected Period Label", title="SHOWING EVENT DATES", size=13,
                  transparent=True, title_size=FS_SUB))
    v.append(date_slicer(PAGE_W - M - 330, HEAD_Y - 2, 330, 96))

    bw = (CW - 6 * 8) / 7.0
    for i, (pid, _disp, short) in enumerate(PAGES):
        v.append(nav_button(vn("nav"), M + i * (bw + 8), NAV_Y, bw, NAV_H,
                            short, pid, active=(pid == page_id)))
    return v


def kpi_row(y, tiles):
    """A row of evenly spaced KPI cards.

    tiles: (title, measure, caption_measure, colour) where colour is either a
    hex string or the name of a colour measure.
    """
    n = len(tiles)
    w = (CW - (n - 1) * G) / float(n)
    out = []
    for i, (title, measure, caption, colour) in enumerate(tiles):
        is_hex = isinstance(colour, str) and colour.startswith("#")
        out.append(card(vn("kpi"), M + i * (w + G), y, w, KPI_H, measure,
                        title=title, subtitle_measure=caption,
                        value_color=colour if is_hex else None,
                        value_color_measure=None if is_hex else colour,
                        size=FS_CARD_VALUE, title_size=FS_CARD_TITLE))
    return out


def line_chart(name, x, y, w, h, projections, title, subtitle,
               colours=None, legend=True, val_title=None, subtitle_measure=None):
    o = axis_objects(legend=legend, val_title=val_title, cat_type="Categorical")
    o["labels"] = [obj({"show": lit(False)})]
    o["lineStyles"] = [obj({"strokeWidth": lit(3), "showMarker": lit(True),
                            "markerSize": lit(4)})]
    if colours:
        o["dataPoint"] = [obj({"fill": solid(c)}, sel_meta(qref(p)))
                          for p, c in zip(projections, colours)]
    return visual(name, x, y, w, h, "lineChart",
                  roles={"Category": [pc("Dim_Date", "Date")],
                         "Y": projections},
                  objects=o,
                  container=chrome(title=title, subtitle=subtitle,
                                   subtitle_measure=subtitle_measure,
                                   title_size=FS_PANEL_TITLE))


def bar_chart(name, x, y, w, h, category, value, measure_name, title, subtitle,
              colour=BLUE):
    """Horizontal bars: long category names stay readable instead of being
    rotated or truncated the way they are on a column axis."""
    o = axis_objects(legend=False, cat_type="Categorical")
    o["labels"] = [obj({"show": lit(True), "fontSize": lit(FS_BODY),
                        "color": solid(TEXT_HI), "fontFamily": lit(FONT),
                        "labelDisplayUnits": lit(1)})]
    o["dataPoint"] = [obj({"fill": solid(colour)})]
    return visual(name, x, y, w, h, "barChart",
                  roles={"Category": [category], "Y": [value]},
                  objects=o,
                  sort=sort_by(measure_expr(measure_name), "Descending"),
                  container=chrome(title=title, subtitle=subtitle,
                                   title_size=FS_PANEL_TITLE))


def data_table(name, x, y, w, h, projections, title, subtitle, sort=None,
               colour_rules=None):
    t = table_objects(font_size=FS_BODY, header_size=FS_BODY, row_pad=8,
                      wrap=True)
    for rule in (colour_rules or []):
        t["values"].append(rule)
    return visual(name, x, y, w, h, "tableEx",
                  roles={"Values": projections}, objects=t, sort=sort,
                  container=chrome(title=title, subtitle=subtitle,
                                   title_size=FS_PANEL_TITLE))


def narrative(name, x, y, w, h, measure, title):
    """Full-width sentence, word wrapped, with room to actually show it - the
    previous build truncated this to an ellipsis."""
    objects = {
        "labels": [obj({"color": solid(TEXT_HI), "fontSize": lit(12),
                        "fontFamily": lit(FONT), "labelDisplayUnits": lit(1)})],
        "categoryLabels": [obj({"show": lit(False)})],
        "wordWrap": [obj({"show": lit(True)})],
    }
    return visual(name, x, y, w, h, "card",
                  roles={"Values": [pm(measure)]}, objects=objects,
                  container=chrome(title=title, title_size=FS_PANEL_TITLE))


# ==========================================================================
# 1. Overview
# ==========================================================================
def page_overview():
    pid = "pgOverview"
    v = header(pid, "IDR EXECUTIVE OVERVIEW",
               "EDL vs CDP volume, IDR resolution, and why resolution failed - "
               "over the event dates selected")

    v += kpi_row(BODY_Y, [
        ("OVERALL IDR RESOLUTION RATE (%)", "Overall IDR Resolution Rate (%)",
         "Period Rate Caption", "Period Rate Colour"),
        ("_IDR_RESOLVED", "IDR Resolved (Period)", "Period Resolved Caption", GREEN),
        ("IDR_NOT_RESOLVED", "IDR Not Resolved (Period)",
         "Period Not Resolved Caption", RED),
        ("PROFILES ATTEMPTED", "Profiles Attempted (Period)",
         "Period Attempted Caption", TEXT_HI),
    ])

    y2 = BODY_Y + KPI_H + G
    v += kpi_row(y2, [
        ("TOTAL EDL LOGINS", "Total EDL Logins (Period)",
         "Session Level Caption", TEXT_HI),
        ("TOTAL KAFKA LOGINS EVENTS", "Total Kafka Logins Events (Period)",
         "Session Match Caption", TEXT_HI),
        ("UNIQUE EDL LOGINS", "Unique EDL Logins (Period)",
         "Profile Level Caption", TEXT_HI),
        ("UNIQUE KAFKA LOGINS AT PROFILE",
         "Unique Kafka Logins at Profile (Period)",
         "Profile Match Caption", TEXT_HI),
    ])

    y3 = y2 + KPI_H + G
    v.append(narrative(vn("ovNarr"), M, y3, CW, 74, "Period Narrative",
                       "WHAT THE SELECTED PERIOD SHOWS"))

    y4 = y3 + 74 + G
    ch = PAGE_H - y4 - M
    half = (CW - G) / 2.0
    v.append(line_chart(
        vn("ovRate"), M, y4, half, ch,
        [pm("Overall IDR Resolution Rate (%)", display="Resolution rate")],
        "IDR RESOLUTION RATE BY EVENT DATE",
        "Each point is that day's resolved / (resolved + not resolved)",
        colours=[BLUE], legend=False, val_title="Resolution rate"))

    v.append(bar_chart(
        vn("ovWhy"), M + half + G, y4, half, ch,
        pc("Fact_Overlap_Daily", "Segment", display="Reason"),
        pm("Non-Resolution Population (Period)", display="Profiles"),
        "Non-Resolution Population (Period)",
        "WHY RESOLUTION FAILED",
        "Profiles by the evidence they carried - these add up to IDR_Not_Resolved",
        colour=RED))
    return page(pid, "Overview", 0, v)


# ==========================================================================
# 2. EDL vs CDP volume
# ==========================================================================
def page_volume():
    pid = "pgVolume"
    v = header(pid, "EDL vs CDP VOLUME",
               "sessionid level counts every login event; syfid level counts one "
               "row per profile. A positive difference means EDL recorded more")

    v += kpi_row(BODY_Y, [
        ("TOTAL EDL LOGINS", "Total EDL Logins (Period)",
         "Session Level Caption", TEXT_HI),
        ("TOTAL KAFKA LOGINS EVENTS", "Total Kafka Logins Events (Period)",
         "Session Match Caption", TEXT_HI),
        ("DIFFERENCE TOTAL EDL vs KAFKA LOGINS",
         "Difference Total EDL vs Kafka Logins (Period)",
         "Session Gap Caption", AMBER),
        ("SESSION LEVEL MATCH RATE (%)", "Session Level Match Rate (%)",
         "Session Match Caption", "Session Match Colour"),
    ])

    y2 = BODY_Y + KPI_H + G
    v += kpi_row(y2, [
        ("UNIQUE EDL LOGINS", "Unique EDL Logins (Period)",
         "Profile Level Caption", TEXT_HI),
        ("UNIQUE KAFKA LOGINS AT PROFILE",
         "Unique Kafka Logins at Profile (Period)",
         "Profile Match Caption", TEXT_HI),
        ("DIFFERENCE UNIQUE EDL vs KAFKA LOGINS",
         "Difference Unique EDL vs Kafka Logins (Period)",
         "Profile Gap Caption", AMBER),
        ("PROFILE LEVEL MATCH RATE (%)", "Profile Level Match Rate (%)",
         "Profile Match Caption", "Profile Match Colour"),
    ])

    y2b = y2 + KPI_H + G
    v += kpi_row(y2b, [
        ("WEB: DIFFERENCE EDL vs CDP", "Difference Web EDL vs CDP (Period)",
         "Web Gap Caption", AMBER),
        ("WEB MATCH RATE (%)", "Web Level Match Rate (%)",
         "Web Device Caption", "Web Match Colour"),
        ("APP: DIFFERENCE EDL vs CDP", "Difference App EDL vs CDP (Period)",
         "App Gap Caption", AMBER),
        ("APP MATCH RATE (%)", "App Level Match Rate (%)",
         "App Device Caption", "App Match Colour"),
    ])

    # Four grains of the same comparison, side by side: every panel is EDL
    # against CDP, so the eye can scan across and see which grain diverges.
    # Device level is a like-for-like pair because *_idr_resolved_edl is the
    # EDL side at syfid level and Web/App_IDR_Resolved is the CDP side.
    y3 = y2b + KPI_H + G
    ch = PAGE_H - y3 - M
    qw = (CW - 3 * G) / 4.0

    v.append(line_chart(
        vn("volTotal"), M, y3, qw, ch,
        [pm("Total EDL Logins (Period)", display="Total EDL Logins"),
         pm("Total Kafka Logins Events (Period)", display="Total Kafka Logins Events")],
        "SESSIONID LEVEL",
        "Every login event. Where the lines separate, the platforms stopped agreeing",
        colours=[BLUE, GREEN]))

    v.append(line_chart(
        vn("volUnique"), M + (qw + G), y3, qw, ch,
        [pm("Unique EDL Logins (Period)", display="Unique EDL Logins"),
         pm("Unique Kafka Logins at Profile (Period)",
            display="Unique Kafka Logins at Profile")],
        "SYFID (PROFILE) LEVEL",
        "One row per profile rather than per event",
        colours=[BLUE, AMBER]))

    v.append(line_chart(
        vn("volWeb"), M + 2 * (qw + G), y3, qw, ch,
        [pm("Web IDR Resolved EDL (Period)", display="web_idr_resolved_edl (EDL)"),
         pm("Web IDR Resolved (Period)", display="Web_IDR_Resolved (CDP)")],
        "WEB DEVICE, SYFID LEVEL", None,
        colours=[BLUE, "#8B7CF6"], subtitle_measure="Web Device Caption"))

    v.append(line_chart(
        vn("volApp"), M + 3 * (qw + G), y3, qw, ch,
        [pm("Apps IDR Resolved EDL (Period)", display="apps_idr_resolved_edl (EDL)"),
         pm("App IDR Resolved (Period)", display="App_IDR_Resolved (CDP)")],
        "APP DEVICE, SYFID LEVEL", None,
        colours=[BLUE, "#22C7DE"], subtitle_measure="App Device Caption"))
    return page(pid, "EDL vs CDP Volume", 1, v)


# ==========================================================================
# 3. IDR resolution
# ==========================================================================
def page_resolution():
    pid = "pgResolution"
    v = header(pid, "IDR RESOLUTION",
               "A profile resolves when CDP holds (web or app) + kafka + account. "
               "The same profile can resolve on both web and app")

    v += kpi_row(BODY_Y, [
        ("OVERALL IDR RESOLUTION RATE (%)", "Overall IDR Resolution Rate (%)",
         "Period Rate Caption", "Period Rate Colour"),
        ("WEB_IDR_RESOLVED", "Web IDR Resolved (Period)",
         "Web Share Caption", TEXT_HI),
        ("APP_IDR_RESOLVED", "App IDR Resolved (Period)",
         "App Share Caption", TEXT_HI),
        ("IDR_NOT_RESOLVED", "IDR Not Resolved (Period)",
         "Period Not Resolved Caption", RED),
    ])

    y2 = BODY_Y + KPI_H + G
    ch = 292
    half = (CW - G) / 2.0
    v.append(line_chart(
        vn("resRate"), M, y2, half, ch,
        [pm("Overall IDR Resolution Rate (%)", display="Resolution rate")],
        "RESOLUTION RATE BY EVENT DATE",
        "Volume weighted per day, straight from the source definition",
        colours=[BLUE], legend=False, val_title="Resolution rate"))

    p_web = pm("Web IDR Resolved (Period)", display="Web_IDR_Resolved (CDP)")
    p_webe = pm("Web IDR Resolved EDL (Period)", display="web_idr_resolved_edl (EDL)")
    p_app = pm("App IDR Resolved (Period)", display="App_IDR_Resolved (CDP)")
    p_appe = pm("Apps IDR Resolved EDL (Period)", display="apps_idr_resolved_edl (EDL)")
    o = axis_objects(legend=True)
    o["labels"] = [obj({"show": lit(False)})]
    o["dataPoint"] = [obj({"fill": solid(BLUE)}, sel_meta(qref(p_web))),
                      obj({"fill": solid("#8B7CF6")}, sel_meta(qref(p_webe))),
                      obj({"fill": solid(GREEN)}, sel_meta(qref(p_app))),
                      obj({"fill": solid("#22C7DE")}, sel_meta(qref(p_appe)))]
    v.append(visual(vn("resSplit"), M + half + G, y2, half, ch,
                    "clusteredColumnChart",
                    roles={"Category": [pc("Dim_Date", "Date")],
                           "Y": [p_web, p_webe, p_app, p_appe]},
                    objects=o,
                    container=chrome(
                        title="IDR RESOLVED AT SYFID LEVEL: CDP vs EDL, BY CHANNEL",
                        subtitle="Same measurement and grain on each platform, so the pair should track",
                        title_size=FS_PANEL_TITLE)))

    y3 = y2 + ch + G
    th = PAGE_H - y3 - M
    cols = [
        pc("Dim_Date", "Date", display="Event_date"),
        pm("IDR Resolved (Period)", display="_IDR_Resolved"),
        pm("IDR Not Resolved (Period)", display="IDR_Not_Resolved"),
        pm("Overall IDR Resolution Rate (%)", display="Overall Idr Resolution Rate (%)"),
        pm("Web IDR Resolved (Period)", display="Web_IDR_Resolved"),
        pm("Web IDR Resolved EDL (Period)", display="web_idr_resolved_edl"),
        pm("App IDR Resolved (Period)", display="App_IDR_Resolved"),
        pm("Apps IDR Resolved EDL (Period)", display="apps_idr_resolved_edl"),
    ]
    v.append(data_table(vn("resTbl"), M, y3, CW, th, cols,
                        "RESOLUTION BY EVENT DATE",
                        "Source field names, newest event date first",
                        sort=sort_by(column_expr("Dim_Date", "Date"), "Descending")))
    return page(pid, "IDR Resolution", 2, v)


# ==========================================================================
# 4. Why resolution failed
# ==========================================================================
def page_why_failed():
    pid = "pgWhyFailed"
    v = header(pid, "WHY RESOLUTION FAILED",
               "The eight partial-match populations sum exactly to "
               "IDR_Not_Resolved, so this is the complete decomposition")

    v += kpi_row(BODY_Y, [
        ("IDR_NOT_RESOLVED", "IDR Not Resolved (Period)",
         "Period Not Resolved Caption", RED),
        ("LARGEST REASON", "Top Non-Resolution Reason",
         "Top Reason Caption", AMBER),
        ("SHARE OF NON-RESOLUTION", "Top Non-Resolution Reason Share (%)",
         "Top Reason Share Caption", AMBER),
        ("MOST MISSED EVENT", "Top Missing Event", "Top Missing Caption", AMBER),
    ])

    y2 = BODY_Y + KPI_H + G
    ch = 286
    half = (CW - G) / 2.0
    v.append(bar_chart(
        vn("whyReason"), M, y2, half, ch,
        pc("Fact_Overlap_Daily", "Segment", display="Reason"),
        pm("Non-Resolution Population (Period)", display="Profiles"),
        "Non-Resolution Population (Period)",
        "PROFILES BY REASON",
        "The evidence the profile did carry in CDP", colour=RED))

    v.append(bar_chart(
        vn("whyMissing"), M + half + G, y2, half, ch,
        pc("Fact_Overlap_Daily", "Missing Event", display="Missing event"),
        pm("Non-Resolution Population (Period)", display="Profiles"),
        "Non-Resolution Population (Period)",
        "PROFILES BY MISSING EVENT",
        "The same profiles grouped by the leg that was absent - this is the fix list",
        colour=AMBER))

    y3 = y2 + ch + G
    th = PAGE_H - y3 - M
    o = axis_objects(legend=True, legend_pos="Right")
    o["labels"] = [obj({"show": lit(False)})]
    # Weekly, not daily: the sample is 15 days but the real feed is 7+ months of
    # daily rows, and 200+ stacked columns is unreadable. Weeks stay legible at
    # both scales - the daily view lives on the Overview line and Daily Detail.
    v.append(visual(vn("whyTrend"), M, y3, half, th, "columnChart",
                    roles={"Category": [pc("Dim_Date", "Year-Week")],
                           "Y": [pm("Non-Resolution Population (Period)",
                                    display="Profiles")],
                           "Series": [pc("Fact_Overlap_Daily", "Segment")]},
                    objects=o,
                    container=chrome(
                        title="NON-RESOLUTION BY WEEK AND REASON",
                        subtitle="Stacked: column height is IDR_Not_Resolved for the week",
                        title_size=FS_PANEL_TITLE)))

    cols = [
        pc("Fact_Overlap_Daily", "Segment", display="Reason"),
        pc("Fact_Overlap_Daily", "Missing Event", display="Missing event"),
        pm("Non-Resolution Population (Period)", display="Profiles"),
        pm("Non-Resolution Share (%)", display="Share"),
    ]
    v.append(data_table(vn("whyTbl"), M + half + G, y3, half, th, cols,
                        "REASON RANKING",
                        "Largest contributor first; shares add to 100%",
                        sort=sort_by(measure_expr("Non-Resolution Population (Period)"),
                                     "Descending")))
    return page(pid, "Why Resolution Failed", 3, v)


# ==========================================================================
# 5. Daily detail - every source field
# ==========================================================================
def page_detail():
    pid = "pgDetail"
    v = header(pid, "DAILY DETAIL",
               "Every field from the source workbook, one row per Event_date, "
               "using the file's own field names")

    y = BODY_Y
    h = PAGE_H - y - M
    cols = [
        pc("Dim_Date", "Date", display="Event_date"),
        pm("Total EDL Logins (Period)", display="Total EDL Logins"),
        pm("Unique EDL Logins (Period)", display="Unique EDL Logins"),
        pm("Total Kafka Logins Events (Period)", display="Total Kafka Logins Events"),
        pm("Unique Kafka Logins at Profile (Period)",
           display="Unique Kafka Logins at Profile"),
        pm("Difference Total EDL vs Kafka Logins (Period)",
           display="Difference Total EDL vs Kafka Logins"),
        pm("Difference Unique EDL vs Kafka Logins (Period)",
           display="Difference Unique EDL vs Kafka Logins"),
        pm("IDR Resolved (Period)", display="_IDR_Resolved"),
        pm("IDR Not Resolved (Period)", display="IDR_Not_Resolved"),
        pm("Overall IDR Resolution Rate (%)",
           display="Overall Idr Resolution Rate (%)"),
        pm("Web IDR Resolved (Period)", display="Web_IDR_Resolved"),
        pm("App IDR Resolved (Period)", display="App_IDR_Resolved"),
        pm("Web IDR Resolved EDL (Period)", display="web_idr_resolved_edl"),
        pm("Apps IDR Resolved EDL (Period)", display="apps_idr_resolved_edl"),
    ]
    v.append(data_table(vn("detTbl"), M, y, CW, h, cols,
                        "DAILY SOURCE DETAIL",
                        "Newest event date first. The total row is the selected period",
                        sort=sort_by(column_expr("Dim_Date", "Date"), "Descending")))
    return page(pid, "Daily Detail", 4, v)


# ==========================================================================
# 6. Alerts and data quality
# ==========================================================================
def page_alerts():
    pid = "pgAlerts"
    v = header(pid, "ALERTS & DATA QUALITY",
               "Rule-based checks on the latest loaded event date, and whether the "
               "source data can be trusted")

    v += kpi_row(BODY_Y, [
        ("PLATFORM HEALTH SCORE", "IDR Platform Health Score",
         "Health Score Caption", "Health Score Colour"),
        ("ACTIVE ALERTS", "Active Alerts", "Active Alerts Caption",
         "Alert Flag Colour"),
        ("CRITICAL ALERTS", "Critical Alerts", "Critical Alerts Caption", RED),
        ("DATA QUALITY", "Data Quality Status", "Data Quality Caption",
         "Data Quality Colour"),
    ])

    y2 = BODY_Y + KPI_H + G
    h = PAGE_H - y2 - M
    half = (CW - G) / 2.0

    alert_cols = [
        pm("Rule Severity", display="Severity"),
        pc("Dim_Alert_Rules", "Rule", display="What is wrong"),
        pm("Rule Current Value", display="Current"),
        pm("Rule Message", display="Business interpretation"),
    ]
    v.append(data_table(
        vn("alertTbl"), M, y2, half, h, alert_cols,
        "WHAT NEEDS ATTENTION",
        "Only rules that are firing, worst first",
        sort=sort_by(measure_expr("Alert Priority Score"), "Descending"),
        colour_rules=[value_color_rule(alert_cols[0], "Rule Severity Colour")]))

    dq_cols = [
        pc("Dim_DQ_Checks", "Check", display="Check"),
        pm("DQ Check Count", display="Rows"),
        pm("DQ Check Status", display="Status"),
    ]
    v.append(data_table(
        vn("dqTbl"), M + half + G, y2, half, h, dq_cols,
        "DATA QUALITY CHECKS",
        "The model flags, it never silently corrects",
        colour_rules=[value_color_rule(dq_cols[2], "DQ Check Colour")]))
    return page(pid, "Alerts & Data Quality", 5, v)


# ==========================================================================
# 7. Definitions
# ==========================================================================
def page_definitions():
    pid = "pgDefinitions"
    v = header(pid, "DEFINITIONS",
               "The source data dictionary - every field on this report traces "
               "back to one of these rows")

    y = BODY_Y
    h = PAGE_H - y - M
    cols = [
        pc("Dim_Metric_Definitions", "Metric Name", display="Var_name"),
        pc("Dim_Metric_Definitions", "Definition", display="Definition"),
        pc("Dim_Metric_Definitions", "Business Meaning", display="Why it matters"),
    ]
    v.append(data_table(vn("defTbl"), M, y, CW, h, cols,
                        "DATA DICTIONARY",
                        "Mirrors the dictionary tab of idr_kafka_edl.xlsx",
                        sort=sort_by(column_expr("Dim_Metric_Definitions", "Sort"),
                                     "Ascending")))
    return page(pid, "Definitions", 6, v)


# ==========================================================================
def theme():
    return {
        "name": "IDRCommandCenter",
        "dataColors": [BLUE, GREEN, AMBER, RED, "#8B7CF6", "#22C7DE",
                       "#5C7099", "#C3D0E6"],
        "background": BG_PAGE,
        "backgroundLight": BG_CARD,
        "foreground": TEXT_HI,
        "foregroundNeutralSecondary": TEXT_MID,
        "foregroundNeutralTertiary": TEXT_LOW,
        "tableAccent": BLUE,
        "good": GREEN, "neutral": AMBER, "bad": RED,
        "textClasses": {
            "title": {"fontSize": FS_PANEL_TITLE, "fontFace": FONT_SEMI,
                      "color": TEXT_HI},
            "label": {"fontSize": FS_BODY, "fontFace": FONT, "color": TEXT_MID},
            "callout": {"fontSize": FS_CARD_VALUE, "fontFace": FONT_SEMI,
                        "color": TEXT_HI},
        },
    }


def main():
    rmtree_resilient(STAGE_DIR)

    builders = [page_overview, page_volume, page_resolution, page_why_failed,
                page_detail, page_alerts, page_definitions]

    order, total = [], 0
    for build in builders:
        p, visuals = build()
        order.append(p["name"])
        write(os.path.join(DEF, "pages", p["name"], "page.json"), p)
        for vis in visuals:
            write(os.path.join(DEF, "pages", p["name"], "visuals",
                               vis["name"], "visual.json"), vis)
        total += len(visuals)

    write(os.path.join(DEF, "pages", "pages.json"), {
        "$schema": SCHEMA_PAGES,
        "pageOrder": order,
        "activePageName": order[0],
    })
    write(os.path.join(DEF, "report.json"), {
        "$schema": SCHEMA_REPORT,
        "layoutOptimization": "None",
        "themeCollection": {
            "customTheme": {"name": "IDRCommandCenter",
                            "reportVersionAtImport": "5.55",
                            "type": "RegisteredResources"},
        },
        "resourcePackages": [{
            "name": "RegisteredResources",
            "type": "RegisteredResources",
            "items": [{"name": "IDRCommandCenter.json",
                       "path": "IDRCommandCenter.json",
                       "type": "CustomTheme"}],
        }],
        "settings": {"useStylableVisualContainerHeader": True,
                     "hideVisualContainerHeader": False,
                     "exportDataMode": "AllowSummarized"},
    })
    write(os.path.join(DEF, "version.json"),
          {"$schema": SCHEMA_VERSION, "version": "4.0.0"})

    # ---- lower the staged PBIR to the format Desktop actually reads --------
    # definition.pbir and the .pbip carry no $schema: that is what Desktop
    # itself writes, and an invented one is what broke the very first open.
    rmtree_resilient(REPORT_DIR)
    # Report definition format version. Desktop 2.157 writes "4.0", but "1.0"
    # opens identically there and is far likelier to be understood by an older
    # Desktop - this project has to open on a March 2026 build too.
    write(os.path.join(REPORT_DIR, "definition.pbir"), {
        "version": "1.0",
        "datasetReference": {"byPath": {"path": "../%s.SemanticModel" % PROJECT}},
    })
    write(os.path.join(REPORT_DIR, ".platform"), {
        "$schema": SCHEMA_PLATFORM,
        "metadata": {"type": "Report", "displayName": PROJECT},
        "config": {"version": "2.0",
                   "logicalId": str(uuid.uuid5(NS, "logical::Report"))},
    })
    write(os.path.join(REPORT_DIR, "StaticResources", "RegisteredResources",
                       "IDRCommandCenter.json"), theme())
    write(os.path.join(ROOT, PROJECT + ".pbip"), {
        "version": "1.0",
        "artifacts": [{"report": {"path": PROJECT + ".Report"}}],
        "settings": {"enableAutoRecovery": True},
    })

    import pbir_to_legacy
    legacy = pbir_to_legacy.build_legacy(DEF)
    write(os.path.join(REPORT_DIR, "report.json"), legacy)
    shipped = sum(len(s["visualContainers"]) for s in legacy["sections"])

    print("report written to %s" % REPORT_DIR)
    print("  pages:   %d" % len(order))
    print("  visuals: %d staged, %d shipped in %d sections"
          % (total, shipped, len(legacy["sections"])))
    for p in order:
        n = len(os.listdir(os.path.join(DEF, "pages", p, "visuals")))
        print("    %-16s %3d visuals" % (p, n))


if __name__ == "__main__":
    main()
