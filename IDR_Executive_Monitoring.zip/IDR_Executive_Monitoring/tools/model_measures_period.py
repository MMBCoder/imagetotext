"""Period measures - everything that answers "over the dates I selected".

The rest of the model is as-of: it reports the latest loaded business date and
compares it with a baseline, which is what an alert engine needs. This module
is the other half, and it is what the dashboard reads.

Every measure here aggregates across whatever the date filter currently holds,
so a user who selects a month gets that month's numbers and a user who selects
seven months gets seven months of numbers - the same measure either way.

The headline rate follows the source dictionary exactly:

    Overall Idr Resolution Rate (%) =
        sum(idr resolved) / sum(idr resolved + idr not resolved)

computed over the selected event dates, not averaged from daily rates. Those
two differ whenever daily volume varies, and the volume-weighted one is the
correct answer to "how did we do over this period".

Field names follow the source workbook so a number on the dashboard can be
traced back to a column in the file.
"""
from model_measures import (M, F_COUNT, F_COUNT_SIGNED, F_PCT2,
                            FLD_EXEC, FLD_IDR, FLD_RECON, FLD_VOL, FLD_OVR)
from model_measures_alerts import C_GREEN, C_AMBER, C_RED, C_NEUTRAL

FLD_PERIOD = "00 - Selected Period"

# (measure name, source column, folder, description)
PERIOD_SUMS = [
    ("Total EDL Logins (Period)", "Total EDL Logins", FLD_VOL,
     "Total logins at sessionid level in EDL, summed over the selected dates."),
    ("Unique EDL Logins (Period)", "Unique EDL Logins", FLD_VOL,
     "Total logins at syfid (profile) level in EDL, summed over the selected dates."),
    ("Total Kafka Logins Events (Period)", "Total Kafka Logins Events", FLD_VOL,
     "Total logins at sessionid level in CDP, summed over the selected dates."),
    ("Unique Kafka Logins at Profile (Period)", "Unique Kafka Logins at Profile", FLD_VOL,
     "Total logins at syfid (profile) level in CDP, summed over the selected dates."),
    ("IDR Resolved (Period)", "IDR Resolved", FLD_IDR,
     "Profiles where identity resolved, summed over the selected dates."),
    ("IDR Not Resolved (Period)", "IDR Not Resolved", FLD_IDR,
     "Profiles where identity did not resolve, summed over the selected dates."),
    ("Web IDR Resolved (Period)", "Web IDR Resolved", FLD_IDR,
     "Web login at syfid level in CDP, summed over the selected dates."),
    ("App IDR Resolved (Period)", "App IDR Resolved", FLD_IDR,
     "App login at syfid level in CDP, summed over the selected dates."),
    ("Web IDR Resolved EDL (Period)", "Web IDR Resolved EDL", FLD_IDR,
     "web_idr_resolved_edl: web IDR resolved at syfid (profile) level in EDL, "
     "summed over the selected dates. The EDL counterpart of Web IDR Resolved."),
    ("Apps IDR Resolved EDL (Period)", "Apps IDR Resolved EDL", FLD_IDR,
     "apps_idr_resolved_edl: apps IDR resolved at syfid (profile) level in EDL, "
     "summed over the selected dates. The EDL counterpart of App IDR Resolved."),
]


def period_measures():
    out = []

    for name, col, folder, desc in PERIOD_SUMS:
        out.append(M(name, "SUM ( 'Fact_IDR_Daily'[%s] )" % col,
                     F_COUNT, folder, desc))

    # ---- the headline rate, straight from the dictionary ------------------
    out.append(M(
        "Overall IDR Resolution Rate (%)",
        """
        -- Dictionary: sum(idr resolved) / sum(idr resolved + idr not resolved)
        -- across the event dates selected in the filter. Volume weighted, so a
        -- quiet day cannot pull the period rate around the way an average of
        -- daily rates would.
        VAR _res = [IDR Resolved (Period)]
        VAR _not = [IDR Not Resolved (Period)]
        RETURN DIVIDE ( _res, _res + _not )
        """,
        F_PCT2, FLD_EXEC,
        "Overall IDR resolution rate across the selected event dates: "
        "resolved / (resolved + not resolved). Formatted as a percentage."))

    out.append(M(
        "Overall IDR Non-Resolution Rate (%)",
        "1 - [Overall IDR Resolution Rate (%)]",
        F_PCT2, FLD_EXEC,
        "Share of profiles that did not resolve across the selected event dates."))

    out.append(M(
        "Profiles Attempted (Period)",
        "[IDR Resolved (Period)] + [IDR Not Resolved (Period)]",
        F_COUNT, FLD_IDR,
        "Resolved plus not resolved: the denominator of the resolution rate."))

    # ---- EDL vs CDP volume reconciliation --------------------------------
    out.append(M(
        "Difference Total EDL vs Kafka Logins (Period)",
        "[Total EDL Logins (Period)] - [Total Kafka Logins Events (Period)]",
        F_COUNT_SIGNED, FLD_RECON,
        "EDL minus CDP at sessionid level over the selected dates. "
        "Positive means EDL recorded more events than CDP."))

    out.append(M(
        "Difference Unique EDL vs Kafka Logins (Period)",
        "[Unique EDL Logins (Period)] - [Unique Kafka Logins at Profile (Period)]",
        F_COUNT_SIGNED, FLD_RECON,
        "EDL minus CDP at syfid (profile) level over the selected dates."))

    out.append(M(
        "Session Level Match Rate (%)",
        "DIVIDE ( [Total Kafka Logins Events (Period)], [Total EDL Logins (Period)] )",
        F_PCT2, FLD_RECON,
        "CDP as a share of EDL at sessionid level. 100% means the two platforms "
        "agree on event volume."))

    out.append(M(
        "Profile Level Match Rate (%)",
        "DIVIDE ( [Unique Kafka Logins at Profile (Period)], [Unique EDL Logins (Period)] )",
        F_PCT2, FLD_RECON,
        "CDP as a share of EDL at syfid (profile) level."))

    # ---- device level: the same measurement on each platform --------------
    # web_idr_resolved_edl / apps_idr_resolved_edl are the EDL side at syfid
    # level, and Web_IDR_Resolved / App_IDR_Resolved are the CDP side at the
    # same grain, so each pair is a like-for-like device comparison.
    out.append(M(
        "Difference Web EDL vs CDP (Period)",
        "[Web IDR Resolved EDL (Period)] - [Web IDR Resolved (Period)]",
        F_COUNT_SIGNED, FLD_RECON,
        "web_idr_resolved_edl minus Web_IDR_Resolved over the selected dates. "
        "Positive means EDL resolved more web profiles than CDP."))

    out.append(M(
        "Difference App EDL vs CDP (Period)",
        "[Apps IDR Resolved EDL (Period)] - [App IDR Resolved (Period)]",
        F_COUNT_SIGNED, FLD_RECON,
        "apps_idr_resolved_edl minus App_IDR_Resolved over the selected dates."))

    out.append(M(
        "Web Level Match Rate (%)",
        "DIVIDE ( [Web IDR Resolved (Period)], [Web IDR Resolved EDL (Period)] )",
        F_PCT2, FLD_RECON,
        "CDP web resolved as a share of EDL web resolved, at syfid level."))

    out.append(M(
        "App Level Match Rate (%)",
        "DIVIDE ( [App IDR Resolved (Period)], [Apps IDR Resolved EDL (Period)] )",
        F_PCT2, FLD_RECON,
        "CDP app resolved as a share of EDL app resolved, at syfid level."))

    # ---- channel split ----------------------------------------------------
    out.append(M(
        "Web Share of Resolved (%)",
        "DIVIDE ( [Web IDR Resolved (Period)], [IDR Resolved (Period)] )",
        F_PCT2, FLD_IDR,
        "Web as a share of all resolved profiles over the selected dates."))

    out.append(M(
        "App Share of Resolved (%)",
        "DIVIDE ( [App IDR Resolved (Period)], [IDR Resolved (Period)] )",
        F_PCT2, FLD_IDR,
        "App as a share of all resolved profiles over the selected dates."))

    # ---- non-resolution decomposition ------------------------------------
    # Fact_Overlap_Daily carries the eight partial-match populations, so these
    # work in the row context of a segment, a missing event, or the whole table.
    out.append(M(
        "Non-Resolution Population (Period)",
        "SUM ( 'Fact_Overlap_Daily'[Population] )",
        F_COUNT, FLD_OVR,
        "Profiles in the partial-match population(s) currently in context, "
        "summed over the selected dates. With no segment filter this equals "
        "IDR Not Resolved."))

    out.append(M(
        "Non-Resolution Share (%)",
        """
        -- Share of all non-resolution that this reason accounts for, so the
        -- shares add to 100% however the visual is sliced.
        -- REMOVEFILTERS on the individual columns is not enough: in the legacy
        -- report format the visual's grouping did not clear that way and every
        -- row read 100%. Clearing the whole table does, and the date filter
        -- still applies because it arrives through Dim_Date.
        VAR _all =
            CALCULATE ( [Non-Resolution Population (Period)],
                        REMOVEFILTERS ( 'Fact_Overlap_Daily' ) )
        RETURN DIVIDE ( [Non-Resolution Population (Period)], _all )
        """,
        F_PCT2, FLD_OVR,
        "Share of all non-resolution over the selected dates that this reason "
        "accounts for."))

    out.append(M(
        "Non-Resolution Rank",
        """
        -- Rank across all eight reasons, never within whatever the visual
        -- happens to group by. Ranking with the grouping columns still in
        -- filter context restarts the numbering inside each group.
        VAR _all =
            CALCULATETABLE (
                ADDCOLUMNS (
                    VALUES ( 'Fact_Overlap_Daily'[Segment] ),
                    "@n", [Non-Resolution Population (Period)]
                ),
                REMOVEFILTERS ( 'Fact_Overlap_Daily' )
            )
        VAR _me =
            CALCULATE (
                [Non-Resolution Population (Period)],
                REMOVEFILTERS ( 'Fact_Overlap_Daily'[Missing Event] ),
                REMOVEFILTERS ( 'Fact_Overlap_Daily'[Segment Type] )
            )
        RETURN
            IF ( NOT ISBLANK ( _me ), COUNTROWS ( FILTER ( _all, [@n] > _me ) ) + 1 )
        """,
        "0", FLD_OVR,
        "Rank of this reason by profiles affected over the selected dates, "
        "largest first."))

    out.append(M(
        "Top Non-Resolution Reason",
        """
        -- The single biggest reason profiles failed to resolve over the
        -- selected dates. Drives the headline sentence on the overview.
        VAR _t =
            ADDCOLUMNS (
                CALCULATETABLE (
                    VALUES ( 'Fact_Overlap_Daily'[Segment] ),
                    REMOVEFILTERS ( 'Fact_Overlap_Daily' )
                ),
                "@n", [Non-Resolution Population (Period)]
            )
        RETURN MAXX ( TOPN ( 1, _t, [@n], DESC ), 'Fact_Overlap_Daily'[Segment] )
        """,
        None, FLD_OVR,
        "Name of the partial-match population contributing the most "
        "non-resolution over the selected dates."))

    out.append(M(
        "Top Non-Resolution Reason Share (%)",
        """
        VAR _top = [Top Non-Resolution Reason]
        VAR _all =
            CALCULATE ( [Non-Resolution Population (Period)],
                        REMOVEFILTERS ( 'Fact_Overlap_Daily' ) )
        VAR _n =
            CALCULATE ( [Non-Resolution Population (Period)],
                        REMOVEFILTERS ( 'Fact_Overlap_Daily' ),
                        'Fact_Overlap_Daily'[Segment] = _top )
        RETURN DIVIDE ( _n, _all )
        """,
        F_PCT2, FLD_OVR,
        "Share of non-resolution attributable to the single largest reason."))

    out.append(M(
        "Top Missing Event",
        """
        -- Grouping the eight populations by the leg they were missing turns a
        -- list of segments into an instruction: go and fix this event.
        VAR _t =
            ADDCOLUMNS (
                CALCULATETABLE (
                    VALUES ( 'Fact_Overlap_Daily'[Missing Event] ),
                    REMOVEFILTERS ( 'Fact_Overlap_Daily' )
                ),
                "@n", [Non-Resolution Population (Period)]
            )
        RETURN MAXX ( TOPN ( 1, _t, [@n], DESC ), 'Fact_Overlap_Daily'[Missing Event] )
        """,
        None, FLD_OVR,
        "The event whose absence accounts for the most non-resolution over the "
        "selected dates."))

    # ---- period context labels -------------------------------------------
    out.append(M(
        "Selected Period Label",
        """
        VAR _a = MIN ( 'Dim_Date'[Date] )
        VAR _b = MAX ( 'Dim_Date'[Date] )
        RETURN
            IF (
                _a = _b,
                FORMAT ( _a, "dd-mmm-yyyy" ),
                FORMAT ( _a, "dd-mmm-yyyy" ) & "  to  " & FORMAT ( _b, "dd-mmm-yyyy" )
            )
        """,
        None, FLD_PERIOD,
        "The event date range currently selected, for the page subtitle."))

    out.append(M(
        "Selected Day Count",
        "COUNTROWS ( VALUES ( 'Dim_Date'[Date] ) ) + 0",
        "#,##0", FLD_PERIOD,
        "Number of event dates in the current selection."))

    # ---- card captions ----------------------------------------------------
    # Every KPI card carries a caption that says what the number is measured
    # against, so a card is never a bare figure a reader has to interpret.
    def caption(name, dax, desc):
        out.append(M(name, dax, None, FLD_PERIOD, desc))

    caption("Period Rate Caption",
            """
            "sum(_IDR_Resolved) / sum(_IDR_Resolved + IDR_Not_Resolved) over "
                & FORMAT ( [Selected Day Count], "#,##0" ) & " day(s)"
            """,
            "Caption under the overall resolution rate.")

    caption("Period Resolved Caption",
            """
            "profiles resolved  |  " & FORMAT ( [Web Share of Resolved (%)], "0.0%" )
                & " web, " & FORMAT ( [App Share of Resolved (%)], "0.0%" ) & " app"
            """,
            "Caption under IDR Resolved.")

    caption("Period Not Resolved Caption",
            """
            "profiles unresolved  |  " & FORMAT ( [Overall IDR Non-Resolution Rate (%)], "0.00%" )
                & " of attempts"
            """,
            "Caption under IDR Not Resolved.")

    caption("Period Attempted Caption",
            '"resolved + not resolved, the rate denominator"',
            "Caption under Profiles Attempted.")

    caption("Session Level Caption", '"sessionid level, EDL"',
            "Caption under Total EDL Logins.")
    caption("Session Match Caption",
            """
            "sessionid level, CDP  |  " & FORMAT ( [Session Level Match Rate (%)], "0.0%" )
                & " of EDL"
            """,
            "Caption under Total Kafka Logins Events and the session match rate.")
    caption("Session Gap Caption",
            '"EDL minus CDP at sessionid level"',
            "Caption under the total difference.")

    caption("Profile Level Caption", '"syfid (profile) level, EDL"',
            "Caption under Unique EDL Logins.")
    caption("Profile Match Caption",
            """
            "syfid level, CDP  |  " & FORMAT ( [Profile Level Match Rate (%)], "0.0%" )
                & " of EDL"
            """,
            "Caption under Unique Kafka Logins at Profile and the profile match rate.")
    caption("Profile Gap Caption",
            '"EDL minus CDP at syfid (profile) level"',
            "Caption under the unique difference.")

    caption("Web Device Caption",
            """
            "web_idr_resolved_edl (EDL) vs Web_IDR_Resolved (CDP)  |  CDP is "
                & FORMAT ( [Web Level Match Rate (%)], "0.0%" ) & " of EDL"
            """,
            "Subtitle for the web device comparison.")
    caption("App Device Caption",
            """
            "apps_idr_resolved_edl (EDL) vs App_IDR_Resolved (CDP)  |  CDP is "
                & FORMAT ( [App Level Match Rate (%)], "0.0%" ) & " of EDL"
            """,
            "Subtitle for the app device comparison.")
    caption("Web Gap Caption",
            '"EDL minus CDP, web at syfid level"',
            "Caption under the web difference card.")
    caption("App Gap Caption",
            '"EDL minus CDP, app at syfid level"',
            "Caption under the app difference card.")

    caption("Web Share Caption",
            '"web login at syfid level  |  " & FORMAT ( [Web Share of Resolved (%)], "0.0%" ) & " of resolved"',
            "Caption under Web IDR Resolved.")
    caption("App Share Caption",
            '"app login at syfid level  |  " & FORMAT ( [App Share of Resolved (%)], "0.0%" ) & " of resolved"',
            "Caption under App IDR Resolved.")

    caption("Top Reason Caption",
            '"the evidence these profiles did carry in CDP"',
            "Caption under the largest non-resolution reason.")
    caption("Top Reason Share Caption",
            """
            VAR _top = [Top Non-Resolution Reason]
            VAR _n =
                CALCULATE ( [Non-Resolution Population (Period)],
                            REMOVEFILTERS ( 'Fact_Overlap_Daily' ),
                            'Fact_Overlap_Daily'[Segment] = _top )
            RETURN FORMAT ( _n, "#,##0" ) & " profiles"
            """,
            "Caption under the largest reason's share.")
    caption("Top Missing Caption",
            '"the event to go and fix"',
            "Caption under the most-missed event.")

    caption("Health Score Caption",
            '"0-100 on the latest loaded date  |  " & [Health Score Band]',
            "Caption under the platform health score.")
    caption("Active Alerts Caption",
            '"rules at warning or critical  |  " & [Alert Flag]',
            "Caption under the active alert count.")
    caption("Critical Alerts Caption",
            '"rules at critical on the latest loaded date"',
            "Caption under the critical alert count.")
    caption("Data Quality Caption",
            '"checks on the loaded data  |  flagged, never corrected"',
            "Caption under the data quality status.")

    # ---- card colours -----------------------------------------------------
    # Semantic only: colour states a verdict, it is never decoration.
    out.append(M(
        "Period Rate Colour",
        """
        VAR _r = [Overall IDR Resolution Rate (%)]
        RETURN
            SWITCH (
                TRUE ( ),
                ISBLANK ( _r ), "{NEUTRAL}",
                _r < [THR Crit IDR_RESOLUTION_RATE], "{RED}",
                _r < [THR Warn IDR_RESOLUTION_RATE], "{AMBER}",
                "{GREEN}"
            )
        """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
           .replace("{GREEN}", C_GREEN).replace("{NEUTRAL}", C_NEUTRAL),
        None, FLD_PERIOD,
        "Semantic colour for the period resolution rate, against the configured "
        "thresholds.", hidden=True))

    def match_colour(name, measure, desc):
        out.append(M(
            name,
            """
            VAR _r = [{M}]
            RETURN
                SWITCH (
                    TRUE ( ),
                    ISBLANK ( _r ), "{NEUTRAL}",
                    _r < 1 - [THR Crit RECON_GAP_PCT], "{RED}",
                    _r < 1 - [THR Warn RECON_GAP_PCT], "{AMBER}",
                    "{GREEN}"
                )
            """.replace("{M}", measure).replace("{RED}", C_RED)
               .replace("{AMBER}", C_AMBER).replace("{GREEN}", C_GREEN)
               .replace("{NEUTRAL}", C_NEUTRAL),
            None, FLD_PERIOD, desc, hidden=True))

    match_colour("Session Match Colour", "Session Level Match Rate (%)",
                 "Semantic colour for the sessionid-level match rate.")
    match_colour("Profile Match Colour", "Profile Level Match Rate (%)",
                 "Semantic colour for the syfid-level match rate.")
    match_colour("Web Match Colour", "Web Level Match Rate (%)",
                 "Semantic colour for the web device match rate.")
    match_colour("App Match Colour", "App Level Match Rate (%)",
                 "Semantic colour for the app device match rate.")

    out.append(M(
        "Alert Flag Colour",
        """
        SWITCH ( [Alert Flag], "CRITICAL", "{RED}", "ACTION REQUIRED", "{AMBER}",
                 "WATCH", "{AMBER}", "{GREEN}" )
        """.replace("{RED}", C_RED).replace("{AMBER}", C_AMBER)
           .replace("{GREEN}", C_GREEN),
        None, FLD_PERIOD,
        "Semantic colour for the active alert count.", hidden=True))

    out.append(M(
        "Period Narrative",
        """
        -- One sentence a leader can read without touching a filter.
        VAR _days = [Selected Day Count]
        VAR _rate = [Overall IDR Resolution Rate (%)]
        VAR _not = [IDR Not Resolved (Period)]
        VAR _top = [Top Non-Resolution Reason]
        VAR _share = [Top Non-Resolution Reason Share (%)]
        RETURN
            IF (
                ISBLANK ( _rate ),
                "No data for the selected dates.",
                "Across " & FORMAT ( _days, "#,##0" ) & " day(s), "
                    & FORMAT ( _rate, "0.00%" ) & " of profiles resolved. "
                    & FORMAT ( _not, "#,##0" ) & " did not, and the largest single "
                    & "reason is " & _top & " at " & FORMAT ( _share, "0.0%" )
                    & " of all non-resolution - these profiles are missing their "
                    & CALCULATE (
                          SELECTEDVALUE ( 'Fact_Overlap_Daily'[Missing Event] ),
                          REMOVEFILTERS ( 'Fact_Overlap_Daily' ),
                          'Fact_Overlap_Daily'[Segment] = _top
                      )
                    & " event."
            )
        """,
        None, FLD_PERIOD,
        "Plain-language summary of the selected period for the overview page."))

    return out
