"""Generates data/MetricDefinitions.csv - the glossary behind the Definitions page.

Two sections, kept apart on purpose:

  * SOURCE FIELDS are read straight from the `dictionary` tab of the workbook,
    verbatim. They are the customer's own definitions, so nothing here
    paraphrases or "improves" them - if a definition is wrong, it gets fixed in
    the workbook and this regenerates.

  * CALCULATED lists what this report adds on top. Each one says how it is
    derived, so a number on a page can be traced to source columns.

Regenerating is deterministic, so the CSV reviews cleanly in source control.
"""
import csv
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORKBOOK = os.path.join(ROOT, "data", "idr_kafka_edl.xlsx")
OUT = os.path.join(ROOT, "data", "MetricDefinitions.csv")

HEADER = ["Sort", "Domain", "Metric Name", "Definition", "Formula",
          "Business Meaning", "Threshold", "Direction", "Usage"]

# Where each source field is used, and why a reader should care. Keyed by the
# workbook's own Var_name so it stays aligned if a definition is reworded.
CONTEXT = {
    "Total EDL Logins": (
        "The EDL side of the sessionid-level volume comparison.",
        "Overview, EDL vs CDP Volume, Daily Detail"),
    "Unique EDL Logins": (
        "The EDL side of the profile-level volume comparison.",
        "Overview, EDL vs CDP Volume, Daily Detail"),
    "Total Kafka Logins Events": (
        "The CDP side of the sessionid-level comparison. Compared with Total "
        "EDL Logins to see whether the platforms agree on event volume.",
        "Overview, EDL vs CDP Volume, Daily Detail"),
    "Unique Kafka Logins at Profile": (
        "The CDP side of the profile-level comparison.",
        "Overview, EDL vs CDP Volume, Daily Detail"),
    "Web_IDR_Resolved": (
        "How much of resolution comes through web. Adds to App_IDR_Resolved to "
        "give _IDR_Resolved.",
        "IDR Resolution, Daily Detail"),
    "App_IDR_Resolved": (
        "How much of resolution comes through app.",
        "IDR Resolution, Daily Detail"),
    "_IDR_Resolved": (
        "The numerator of the resolution rate.",
        "Overview, IDR Resolution, Daily Detail"),
    "IDR_Not_Resolved": (
        "The population to reduce. The eight partial-match fields below "
        "account for it exactly, so every unresolved profile has a stated "
        "reason.",
        "Overview, Why Resolution Failed, Daily Detail"),
    "Web_Only": ("Missing both kafka and account.", "Why Resolution Failed"),
    "Kafka_Only": ("Missing web or app, and account.", "Why Resolution Failed"),
    "App_Only": ("Missing both kafka and account.", "Why Resolution Failed"),
    "Kafka_and_Web": ("Missing the account event.", "Why Resolution Failed"),
    "Kafka_and_Apps": ("Missing the account event.", "Why Resolution Failed"),
    "Web_and_Account": ("Missing the kafka event.", "Why Resolution Failed"),
    "Kafka_and_Account": ("Missing the web or app event.", "Why Resolution Failed"),
    "Apps_and_Account": ("Missing the kafka event.", "Why Resolution Failed"),
    "Difference Total EDL vs Kafka Logins": (
        "Positive means EDL recorded more events than CDP at sessionid level.",
        "EDL vs CDP Volume, Daily Detail"),
    "Difference Unique EDL vs Kafka Logins": (
        "Positive means EDL recorded more profiles than CDP at syfid level.",
        "EDL vs CDP Volume, Daily Detail"),
    "Event_date": (
        "The grain of the whole model: one row per event date. Every filter on "
        "this report is a range of these.",
        "Every page"),
    "Overall Idr Resolution Rate (%)": (
        "Shipped empty in the workbook by design. The report calculates it over "
        "the selected date range instead - see the calculated entry below.",
        "Calculated, not read"),
    "apps_idr_resolved_edl": (
        "The EDL counterpart of App_IDR_Resolved: same measurement, same grain, "
        "other platform. Comparing the two is the channel-level EDL vs CDP check.",
        "IDR Resolution, Daily Detail"),
    "web_idr_resolved_edl": (
        "The EDL counterpart of Web_IDR_Resolved: same measurement, same grain, "
        "other platform.",
        "IDR Resolution, Daily Detail"),
}

# What this report adds on top of the source columns.
CALCULATED = [
    ("Overall IDR Resolution Rate (%)",
     "Share of attempted profiles that resolved, across the event dates selected in the filter.",
     "sum(_IDR_Resolved) / sum(_IDR_Resolved + IDR_Not_Resolved)",
     "The headline number. Volume weighted over the whole selected range, so a "
     "quiet day cannot pull it around the way an average of daily rates would.",
     "Warn < 98.5% | Critical < 97.0%", "Higher is better",
     "Overview, IDR Resolution"),
    ("Overall IDR Non-Resolution Rate (%)",
     "The complement of the resolution rate over the selected dates.",
     "1 - Overall IDR Resolution Rate (%)",
     "The share of profiles the pipeline could not identify.",
     "Warn > 1.5% | Critical > 3.0%", "Lower is better", "Overview"),
    ("Profiles Attempted",
     "Resolved plus not resolved over the selected dates.",
     "sum(_IDR_Resolved) + sum(IDR_Not_Resolved)",
     "The denominator of the resolution rate, shown so the rate can be checked.",
     "n/a", "Informational", "Overview"),
    ("Session Level Match Rate (%)",
     "CDP event volume as a share of EDL event volume at sessionid level.",
     "sum(Total Kafka Logins Events) / sum(Total EDL Logins)",
     "100% means the two platforms agree. A persistent gap means events are "
     "being lost between EDL and CDP.",
     "Warn < 95% | Critical < 90%", "Higher is better",
     "Overview, EDL vs CDP Volume"),
    ("Profile Level Match Rate (%)",
     "CDP profile volume as a share of EDL profile volume at syfid level.",
     "sum(Unique Kafka Logins at Profile) / sum(Unique EDL Logins)",
     "The profile-level equivalent. Diverging from the session-level rate "
     "points at a de-duplication difference rather than lost events.",
     "Warn < 95% | Critical < 90%", "Higher is better",
     "Overview, EDL vs CDP Volume"),
    ("Non-Resolution Population",
     "Profiles in a given partial-match population over the selected dates.",
     "sum of the matching source column, unpivoted to one row per date and reason",
     "Lets one measure answer 'which reason is driving non-resolution' instead "
     "of eight separate ones.",
     "n/a", "Lower is better", "Why Resolution Failed"),
    ("Non-Resolution Share (%)",
     "Share of all non-resolution attributable to one reason.",
     "Non-Resolution Population / total across all eight reasons",
     "Turns eight raw counts into a ranked list, so effort goes to the "
     "population that actually moves the rate.",
     "n/a", "Lower is better", "Overview, Why Resolution Failed"),
    ("Top Non-Resolution Reason",
     "The partial-match population contributing the most non-resolution over the selected dates.",
     "the reason with the largest Non-Resolution Population",
     "The single thing to investigate first.", "n/a", "Informational",
     "Overview, Why Resolution Failed"),
    ("Top Missing Event",
     "The event whose absence accounts for the most non-resolution.",
     "reasons grouped by their missing leg, largest group wins",
     "Groups the eight populations into an instruction: this is the event to go "
     "and fix.", "n/a", "Informational", "Why Resolution Failed"),
    ("Web Share of Resolved (%)",
     "Web as a share of all resolved profiles over the selected dates.",
     "sum(Web_IDR_Resolved) / sum(_IDR_Resolved)",
     "Shows whether a change in resolution is web driven or app driven.",
     "n/a", "Informational", "IDR Resolution"),
    ("App Share of Resolved (%)",
     "App as a share of all resolved profiles over the selected dates.",
     "sum(App_IDR_Resolved) / sum(_IDR_Resolved)",
     "The app-side counterpart.", "n/a", "Informational", "IDR Resolution"),
]


# Definitions the customer has corrected in conversation but not yet saved back
# into the workbook. The override is listed here rather than edited into the
# file so that regenerating never silently reverts to a stale definition; delete
# an entry once the workbook itself carries the wording.
OVERRIDES = {
    "apps_idr_resolved_edl": "apps idr resolved at syfid level in EDL",
    "web_idr_resolved_edl": "web idr resolved at syfid level in EDL",
}


def source_rows():
    """Definitions read verbatim from the workbook's dictionary tab."""
    import openpyxl
    wb = openpyxl.load_workbook(WORKBOOK, data_only=True, read_only=True)
    if "dictionary" not in wb.sheetnames:
        raise SystemExit("no 'dictionary' tab in %s" % WORKBOOK)
    rows, sort = [], 10
    for var, definition in wb["dictionary"].iter_rows(min_row=2, max_col=2,
                                                      values_only=True):
        if not var:
            continue
        meaning, usage = CONTEXT.get(var, ("", "Daily Detail"))
        text = OVERRIDES.get(var, definition)
        rows.append([sort, "Source field", var,
                     " ".join(str(text or "").split()),
                     "read directly from the workbook", meaning, "n/a",
                     "Informational", usage])
        sort += 10
    return rows


def calculated_rows(start):
    rows, sort = [], start
    for name, definition, formula, meaning, thr, direction, usage in CALCULATED:
        rows.append([sort, "Calculated", name, definition, formula, meaning,
                     thr, direction, usage])
        sort += 10
    return rows


def main():
    src = source_rows()
    rows = src + calculated_rows(1000)
    with open(OUT, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(HEADER)
        w.writerows(rows)
    print("glossary written to %s" % OUT)
    print("  source fields: %d   calculated: %d" % (len(src), len(rows) - len(src)))


if __name__ == "__main__":
    main()
