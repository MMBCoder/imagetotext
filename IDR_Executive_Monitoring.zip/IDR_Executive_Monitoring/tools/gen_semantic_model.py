"""Generates the IDR_Executive_Monitoring.SemanticModel folder (TMDL).

Run:  python tools/gen_semantic_model.py
Deterministic: lineage tags are UUID5 values derived from object names, so
re-running produces byte-identical output and clean source-control diffs.
"""
import json
import os
import uuid
import shutil

from model_measures import (date_context, base_measures, trend_measures, TREND_KPIS)
from model_measures_alerts import (threshold_measures, severity_measures,
                                   alert_measures, health_measures, ALERT_RULES)
from model_measures_dq import dq_measures, narrative_measures, ux_measures
from model_measures_period import period_measures
from model_measures_selector import (selector_measures, dq_check_measures,
                                     WATCH_METRICS, DQ_CHECKS)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT = "IDR_Executive_Monitoring"
MODEL_DIR = os.path.join(ROOT, PROJECT + ".SemanticModel")
DEF = os.path.join(MODEL_DIR, "definition")

NS = uuid.UUID("6f1d0c2e-9a4b-5c7d-8e3f-1a2b3c4d5e6f")

SCHEMA_PBISM = ("https://developer.microsoft.com/json-schemas/fabric/"
                "item/semanticModel/definitionProperties/1.0.0/schema.json")


def rmtree_resilient(path, attempts=5):
    """Remove a generated folder, tolerating transient locks.

    Cloud-sync clients and open shells routinely hold a handle on a folder for
    a moment; a single rmtree then fails half way and leaves the project in a
    broken state.  Retry, and fall back to emptying the folder in place.
    """
    import time
    if not os.path.isdir(path):
        return
    for i in range(attempts):
        try:
            shutil.rmtree(path)
            return
        except OSError:
            time.sleep(0.4 * (i + 1))
    for root, dirs, files in os.walk(path, topdown=False):
        for f in files:
            try:
                os.remove(os.path.join(root, f))
            except OSError:
                pass
        for d in dirs:
            try:
                os.rmdir(os.path.join(root, d))
            except OSError:
                pass


def lt(kind, name):
    """Deterministic lineage tag."""
    return str(uuid.uuid5(NS, "%s::%s" % (kind, name)))


TAB = "\t"


def q(name):
    """Quote a TMDL identifier when it is not a bare word."""
    if name and all(c.isalnum() or c == "_" for c in name) and not name[0].isdigit():
        return name
    return "'" + name.replace("'", "''") + "'"


def block(dax, depth):
    """Render a DAX/M expression as a TMDL value.

    Multi-line values use the triple-backtick delimited form that Power BI
    Desktop itself writes.  The alternative - relying on indentation to mark
    where the expression ends - is ambiguous as soon as the expression contains
    a blank line, which several of the health-score measures do.
    """
    lines = [ln.rstrip() for ln in dax.strip("\n").split("\n")]
    # strip the common leading indentation the catalogue uses
    non_empty = [ln for ln in lines if ln.strip()]
    pad = min((len(ln) - len(ln.lstrip()) for ln in non_empty), default=0)
    lines = [ln[pad:] if ln.strip() else "" for ln in lines]
    ind = TAB * depth
    if len(lines) == 1:
        return " = " + lines[0] + "\n"
    out = " = ```\n"
    for ln in lines:
        out += (ind + ln).rstrip() + "\n" if ln.strip() else "\n"
    out += ind + "```\n"
    return out


# ==========================================================================
# source column mapping
# ==========================================================================
RENAMES = [
    ("Total EDL Logins", "Total EDL Logins"),
    ("Unique EDL Logins", "Unique EDL Logins"),
    ("Total Kafka Logins Events", "Total Kafka Logins Events"),
    ("Unique Kafka Logins at Profile", "Unique Kafka Logins at Profile"),
    ("Web_IDR_Resolved", "Web IDR Resolved"),
    ("App_IDR_Resolved", "App IDR Resolved"),
    # The workbook ships this header with a leading underscore. Both spellings
    # are listed and MissingField.Ignore tolerates whichever is present.
    ("_IDR_Resolved", "IDR Resolved"),
    ("IDR_Resolved", "IDR Resolved"),
    ("IDR_Not_Resolved", "IDR Not Resolved"),
    ("Web_Only", "Web Only"),
    ("Kafka_Only", "Kafka Only"),
    ("App_Only", "App Only"),
    ("Kafka_and_Web", "Kafka and Web"),
    ("Kafka_and_Apps", "Kafka and Apps"),
    ("Web_and_Account", "Web and Account"),
    ("Kafka_and_Account", "Kafka and Account"),
    ("Apps_and_Account", "Apps and Account"),
    ("Difference Total EDL vs Kafka Logins", "Difference Total EDL vs Kafka Logins"),
    ("Difference Unique EDL vs Kafka Logins", "Difference Unique EDL vs Kafka Logins"),
    ("Event_date", "Event Date"),
    ("Overall Idr Resolution Rate (%)", "Overall IDR Resolution Rate"),
    ("apps_idr_resolved_edl", "Apps IDR Resolved EDL"),
    ("web_idr_resolved_edl", "Web IDR Resolved EDL"),
]

FACT_COLUMNS = [
    # (model name, dataType, formatString, description)
    ("Event Date", "dateTime", "dd-mmm-yyyy", "Business date of the daily snapshot. The grain of this table is one row per Event Date."),
    # Volume: EDL against CDP (the workbook calls the CDP side "Kafka").
    # sessionid level = every login event; syfid level = one row per profile.
    ("Total EDL Logins", "int64", "#,##0", "Total logins at sessionid level in the EDL data."),
    ("Unique EDL Logins", "int64", "#,##0", "Total logins at syfid (profile) level in the EDL data."),
    ("Total Kafka Logins Events", "int64", "#,##0", "Total logins at sessionid level in the CDP data."),
    ("Unique Kafka Logins at Profile", "int64", "#,##0", "Total logins at syfid (profile) level in the CDP data."),

    # IDR breakdown of the CDP data.
    ("Web IDR Resolved", "int64", "#,##0", "Web login at syfid level in the CDP data."),
    ("App IDR Resolved", "int64", "#,##0", "App login at syfid level in the CDP data."),
    ("IDR Resolved", "int64", "#,##0", "Profiles where identity resolved: web + kafka + account, or app + kafka + account. Equals Web IDR Resolved plus App IDR Resolved on every loaded row."),
    ("IDR Not Resolved", "int64", "#,##0", "Profiles where identity did not resolve because at least one of the three events is missing. Equals the sum of the eight partial-match populations below on every loaded row."),

    # The eight partial-match populations. Each is a profile that carries only
    # part of the evidence needed to resolve, so each one is a REASON a profile
    # sits in IDR Not Resolved - together they account for it exactly.
    ("Web Only", "int64", "#,##0", "Profiles with a web event only in CDP. Counts towards IDR Not Resolved."),
    ("Kafka Only", "int64", "#,##0", "Profiles with a kafka event only in CDP. Counts towards IDR Not Resolved."),
    ("App Only", "int64", "#,##0", "Profiles with an app event only in CDP. Counts towards IDR Not Resolved."),
    ("Kafka and Web", "int64", "#,##0", "Profiles with kafka and web events only in CDP - the account event is missing. Counts towards IDR Not Resolved."),
    ("Kafka and Apps", "int64", "#,##0", "Profiles with kafka and apps events only in CDP - the account event is missing. Counts towards IDR Not Resolved."),
    ("Web and Account", "int64", "#,##0", "Profiles with web and account events only in CDP - the kafka event is missing. Counts towards IDR Not Resolved."),
    ("Kafka and Account", "int64", "#,##0", "Profiles with kafka and account events only in CDP - the web or app event is missing. Counts towards IDR Not Resolved."),
    ("Apps and Account", "int64", "#,##0", "Profiles with apps and account events only in CDP - the kafka event is missing. Counts towards IDR Not Resolved."),

    ("Difference Total EDL vs Kafka Logins", "int64", "+#,##0;-#,##0;0", "Difference between EDL and CDP at sessionid level. Positive means EDL recorded more."),
    ("Difference Unique EDL vs Kafka Logins", "int64", "+#,##0;-#,##0;0", "Difference between EDL and CDP at syfid (profile) level. Positive means EDL recorded more."),

    # The workbook ships this column empty on purpose: the dictionary says the
    # rate "should be calculated based on the range of event dates selected in
    # filter". The measure [Overall IDR Resolution Rate (%)] does exactly that,
    # and this raw column is not used anywhere.
    ("Overall IDR Resolution Rate", "double", "0.00%", "Raw source column, shipped empty. The rate is calculated over the selected date range by the measure of the same name."),

    # These two are the EDL side, not CDP. That makes them directly comparable
    # with Web IDR Resolved / App IDR Resolved, which are the same measurement
    # at the same grain on the CDP side.
    ("Apps IDR Resolved EDL", "int64", "#,##0", "Source column apps_idr_resolved_edl: apps IDR resolved at syfid (profile) level in EDL."),
    ("Web IDR Resolved EDL", "int64", "#,##0", "Source column web_idr_resolved_edl: web IDR resolved at syfid (profile) level in EDL."),
]

# Resolution needs three events: (web or app) + kafka + account. Each row below
# is a partial-match population - the evidence a profile did have, and the leg
# it was missing. These eight sum exactly to IDR Not Resolved on every loaded
# row, which is what makes "why did resolution fail?" answerable.
#   (segment, evidence held, missing leg, display order)
OVERLAP_SEGMENTS = [
    ("Kafka and Web", "Two of three", "Account", 1),
    ("Kafka and Apps", "Two of three", "Account", 2),
    ("Kafka and Account", "Two of three", "Web or App", 3),
    ("Web and Account", "Two of three", "Kafka", 4),
    ("Apps and Account", "Two of three", "Kafka", 5),
    ("Web Only", "One of three", "Kafka and Account", 6),
    ("App Only", "One of three", "Kafka and Account", 7),
    ("Kafka Only", "One of three", "Web or App, and Account", 8),
]

# Only metrics that carry the full trend-intelligence pattern, so the statistics
# strip on Historical Trends is populated whichever metric is selected.
TREND_METRIC_FIELDS = [m[0] for m in WATCH_METRICS]

SCORECARD_ROWS = [
    ("RESOLUTION", "IDR Resolution Rate", 1),
    ("NON_RESOLUTION", "IDR Non-Resolution Rate", 2),
    ("RECON_TOTAL", "EDL / Kafka Reconciliation", 3),
    ("RECON_UNIQUE", "Unique Reconciliation", 4),
    ("WEB_RES", "Web Resolution", 5),
    ("APP_RES", "App Resolution", 6),
    ("DATA_QUALITY", "Data Quality", 7),
    ("ACTIVE_ALERTS", "Active Alerts", 8),
]

TIMEFRAMES = [
    ("Last 7 Days", 7, 1),
    ("Last 30 Days", 30, 2),
    ("Last 90 Days", 90, 3),
    ("Last 6 Months", 182, 4),
    ("Last 12 Months", 365, 5),
    ("All History", 0, 6),
]

RULE_DESCRIPTIONS = {
    "R01": "Resolution rate below its absolute threshold, or falling materially against the previous day or the 7-day baseline.",
    "R02": "Unresolved IDR volume above its baseline growth tolerance, its absolute ceiling, or its z-score tolerance.",
    "R03": "EDL/Kafka reconciliation rate drifting against its own 7-day baseline, on total or unique volume.",
    "R04": "Signed EDL/Kafka variance changed direction. A move to negative means Kafka now exceeds EDL.",
    "R05": "One of the eight identity overlap populations moved abnormally against its 7-day baseline.",
    "R06": "Login volume outside the recent noise band, judged by z-score so normal growth is not flagged.",
    "R07": "Several independent controls failing on the same date, which points to one upstream cause.",
    "R08": "Structural data-quality defects detected in the loaded data.",
    "R09": "The resolution rate published by the source disagrees with the rate recalculated from the counts.",
}


# ==========================================================================
# TMDL writers
# ==========================================================================
def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)


def column_tmdl(table, name, dtype, fmt, desc, hidden=False, inferred=False,
                source=None, is_key=False, sort_by=None, summarize="none",
                extended=None):
    s = ""
    if desc:
        s += TAB + "/// " + desc + "\n"
    s += TAB + "column " + q(name) + "\n"
    s += TAB * 2 + "dataType: " + dtype + "\n"
    if is_key:
        s += TAB * 2 + "isKey\n"
    if hidden:
        s += TAB * 2 + "isHidden\n"
    if fmt:
        s += TAB * 2 + "formatString: " + fmt + "\n"
    s += TAB * 2 + "lineageTag: " + lt("column", table + "." + name) + "\n"
    s += TAB * 2 + "summarizeBy: " + summarize + "\n"
    if inferred:
        s += TAB * 2 + "isNameInferred\n"
    s += TAB * 2 + "sourceColumn: " + (source if source else name) + "\n"
    if sort_by:
        s += TAB * 2 + "sortByColumn: " + q(sort_by) + "\n"
    if extended:
        s += TAB * 2 + "extendedProperty ParameterMetadata = \n"
        for ln in extended.split("\n"):
            s += TAB * 4 + ln + "\n"
    s += "\n"
    s += TAB * 2 + "annotation SummarizationSetBy = Automatic\n"
    s += "\n"
    return s


def measure_tmdl(m):
    s = ""
    if m["desc"]:
        s += TAB + "/// " + m["desc"] + "\n"
    s += TAB + "measure " + q(m["name"])
    s += block(m["dax"], 3)
    if m["fmt"]:
        s += TAB * 2 + "formatString: " + m["fmt"] + "\n"
    s += TAB * 2 + "lineageTag: " + lt("measure", m["name"]) + "\n"
    if m["hidden"]:
        s += TAB * 2 + "isHidden\n"
    if m["folder"]:
        s += TAB * 2 + "displayFolder: " + m["folder"] + "\n"
    s += "\n"
    return s


# ==========================================================================
# tables
# ==========================================================================
def fact_table():
    ren = ",\n                ".join(
        '{"%s", "%s"}' % (a, b) for a, b in RENAMES if a != b)
    types = ",\n                ".join(
        '{"%s", %s}' % (n, {"int64": "Int64.Type", "double": "type number",
                            "dateTime": "type date"}[t])
        for n, t, _f, _d in FACT_COLUMNS)

    m = """
let
    // Source workbook is addressed through parameters so the project can be
    // repointed at a new drop without editing any query logic.
    File = File.Contents ( ProjectDataFolder & "\\" & SourceWorkbookName ),
    Book = Excel.Workbook ( File, null, true ),
    // Fall back to the first sheet if the expected sheet name is ever renamed.
    Sheet = try Book{[Item = SourceSheetName, Kind = "Sheet"]}[Data] otherwise Book{0}[Data],
    Promoted = Table.PromoteHeaders ( Sheet, [PromoteAllScalars = true] ),
    Renamed = Table.RenameColumns (
        Promoted,
        {
                %s
        },
        MissingField.Ignore
    ),
    Typed = Table.TransformColumnTypes (
        Renamed,
        {
                %s
        }
    ),
    // Rows with no business date cannot be placed on a trend.  They are removed
    // here and counted by the data-quality layer rather than silently dropped.
    Dated = Table.SelectRows ( Typed, each [Event Date] <> null ),
    Sorted = Table.Sort ( Dated, {{"Event Date", Order.Ascending}} )
in
    Sorted
""" % (ren, types)

    s = "/// One row per business date. Daily snapshot of EDL, Kafka, IDR resolution and identity overlap volumes.\n"
    s += "table Fact_IDR_Daily\n"
    s += TAB + "lineageTag: " + lt("table", "Fact_IDR_Daily") + "\n\n"
    for name, dtype, fmt, desc in FACT_COLUMNS:
        s += column_tmdl("Fact_IDR_Daily", name, dtype, fmt, desc, hidden=True)
    s += TAB + "partition Fact_IDR_Daily = m\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(m, 4)
    s += "\n"
    s += TAB + "annotation PBI_ResultType = Table\n"
    return s


def refresh_table():
    m = """
let
    // Captured at refresh time.  Distinct from the business date: it answers
    // "when did this model last load", not "what day does it describe".
    Source = #table (
        type table [Refreshed At = datetime],
        { { DateTime.LocalNow ( ) } }
    )
in
    Source
"""
    s = "/// Single-row table carrying the model refresh timestamp.\n"
    s += "table " + q("Refresh Info") + "\n"
    s += TAB + "lineageTag: " + lt("table", "Refresh Info") + "\n\n"
    s += column_tmdl("Refresh Info", "Refreshed At", "dateTime", "dd-mmm-yyyy hh:nn:ss",
                     "Timestamp of the last model refresh.", hidden=True)
    s += TAB + "partition " + q("Refresh Info") + " = m\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(m, 4)
    s += "\n"
    s += TAB + "annotation PBI_ResultType = Table\n"
    return s


def m_text(v):
    """One M string literal. M escapes a quote by doubling it."""
    return '"' + str(v).replace('"', '""') + '"'


def csv_fallback_literal(filename, indent=4):
    """An M #table literal holding a configuration CSV as of build time.

    The configuration CSVs live beside the workbook so a business user can retune
    a threshold without touching DAX. On a machine that only has the workbook
    they are simply absent, and a missing file fails the whole refresh rather
    than degrading gracefully. Baking the current contents in as a fallback means
    the model always loads: the file wins when it is there, these defaults when
    it is not.

    Every value is emitted as text, exactly as Csv.Document would produce it, so
    one Table.TransformColumnTypes step types both paths identically.
    """
    import csv as _csv
    path = os.path.join(ROOT, "data", filename)
    if not os.path.exists(path):
        raise SystemExit(
            "cannot build: %s is missing. It is needed at build time to bake "
            "the defaults into the model. Run tools/gen_metric_definitions.py, "
            "or restore the file, and retry." % path)
    with open(path, encoding="utf-8", newline="") as fh:
        rows = list(_csv.reader(fh))
    header, body = rows[0], rows[1:]
    pad = " " * indent
    lines = ["#table (",
             pad + "    { " + ", ".join(m_text(h) for h in header) + " },",
             pad + "    {"]
    for i, r in enumerate(body):
        r = (r + [""] * len(header))[:len(header)]
        tail = "," if i < len(body) - 1 else ""
        lines.append(pad + "        { " + ", ".join(m_text(c) for c in r) + " }" + tail)
    lines.append(pad + "    }")
    lines.append(pad + ")")
    return ("\n" + pad).join(lines)


def thresholds_table():
    m = """
let
    // Business-editable configuration.  Put Thresholds.csv beside the workbook
    // and refresh: no DAX edit is required to retune any alert or health-score
    // weight.  When the file is absent - a machine that only has the workbook -
    // the defaults captured at build time are used instead, so the model still
    // loads rather than failing the whole refresh on a missing config file.
    FromFile =
        try
            Table.PromoteHeaders (
                Csv.Document (
                    File.Contents ( ProjectDataFolder & "\\Thresholds.csv" ),
                    [ Delimiter = ",", Columns = 8, Encoding = 65001, QuoteStyle = QuoteStyle.Csv ]
                ),
                [PromoteAllScalars = true]
            )
        otherwise null,
    Default = {FALLBACK_THRESHOLDS},
    Source = if FromFile = null then Default else FromFile,
    Typed = Table.TransformColumnTypes (
        Source,
        {
                {"Metric Key", type text},
                {"Metric", type text},
                {"Warning Threshold", type number},
                {"Critical Threshold", type number},
                {"Direction", type text},
                {"Weight", type number},
                {"Unit", type text},
                {"Description", type text}
        }
    )
in
    Typed
"""
    m = m.replace("{FALLBACK_THRESHOLDS}", csv_fallback_literal("Thresholds.csv"))
    cols = [
        ("Metric Key", "string", None, "Stable key referenced by the DAX threshold lookups. Do not rename."),
        ("Metric", "string", None, "Business name of the metric being governed."),
        ("Warning Threshold", "double", "0.000", "Value at which the metric enters warning."),
        ("Critical Threshold", "double", "0.000", "Value at which the metric becomes critical."),
        ("Direction", "string", None, "Whether higher or lower values are worse."),
        ("Weight", "double", "0", "Weight of this metric in the platform health score. Zero means the metric alerts but does not score."),
        ("Unit", "string", None, "Unit the thresholds are expressed in."),
        ("Description", "string", None, "What the threshold governs and when to retune it."),
    ]
    s = "/// Disconnected configuration table. Every alert threshold and health-score weight is read from here, so thresholds can be retuned without editing DAX.\n"
    s += "table Dim_Thresholds\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_Thresholds") + "\n\n"
    for n, t, f, d in cols:
        s += column_tmdl("Dim_Thresholds", n, t, f, d)
    s += TAB + "partition Dim_Thresholds = m\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(m, 4)
    s += "\n"
    s += TAB + "annotation PBI_ResultType = Table\n"
    return s


def metric_definitions_table():
    m = """
let
    // Same pattern as Dim_Thresholds: the CSV wins when it is present, otherwise
    // the glossary captured at build time is used, so the Definitions page is
    // never empty on a machine that only has the workbook.
    FromFile =
        try
            Table.PromoteHeaders (
                Csv.Document (
                    File.Contents ( ProjectDataFolder & "\\MetricDefinitions.csv" ),
                    [ Delimiter = ",", Columns = 9, Encoding = 65001, QuoteStyle = QuoteStyle.Csv ]
                ),
                [PromoteAllScalars = true]
            )
        otherwise null,
    Default = {FALLBACK_DEFINITIONS},
    Source = if FromFile = null then Default else FromFile,
    Typed = Table.TransformColumnTypes (
        Source,
        {
                {"Sort", Int64.Type},
                {"Domain", type text},
                {"Metric Name", type text},
                {"Definition", type text},
                {"Formula", type text},
                {"Business Meaning", type text},
                {"Threshold", type text},
                {"Direction", type text},
                {"Usage", type text}
        }
    )
in
    Typed
"""
    m = m.replace("{FALLBACK_DEFINITIONS}", csv_fallback_literal("MetricDefinitions.csv"))
    cols = [
        ("Sort", "int64", "0", "Display order in the glossary.", True),
        ("Domain", "string", None, "Metric family.", False),
        ("Metric Name", "string", None, "Business name of the metric.", False),
        ("Definition", "string", None, "What the metric measures.", False),
        ("Formula", "string", None, "How the metric is calculated.", False),
        ("Business Meaning", "string", None, "Why the metric matters and how to read a breach.", False),
        ("Threshold", "string", None, "Warning and critical thresholds in force.", False),
        ("Direction", "string", None, "Whether higher or lower is better.", False),
        ("Usage", "string", None, "Where the metric is used in the report.", False),
    ]
    s = "/// Business glossary driving the Metric Definitions page. Edit data/MetricDefinitions.csv to change it.\n"
    s += "table Dim_Metric_Definitions\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_Metric_Definitions") + "\n\n"
    for n, t, f, d, h in cols:
        # Metric Name sorts by the hidden Sort column so the glossary keeps its
        # curated order rather than falling back to alphabetical.
        s += column_tmdl("Dim_Metric_Definitions", n, t, f, d, hidden=h,
                         sort_by="Sort" if n == "Metric Name" else None)
    s += TAB + "partition Dim_Metric_Definitions = m\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(m, 4)
    s += "\n"
    s += TAB + "annotation PBI_ResultType = Table\n"
    return s


def date_table():
    dax = """
-- Calendar spans exactly the loaded data, so charts stay tight to real
-- history and automatically extend as new days are appended.
VAR _min = CALCULATE ( MIN ( 'Fact_IDR_Daily'[Event Date] ), ALL ( 'Fact_IDR_Daily' ) )
VAR _max = CALCULATE ( MAX ( 'Fact_IDR_Daily'[Event Date] ), ALL ( 'Fact_IDR_Daily' ) )
RETURN
    ADDCOLUMNS (
        CALENDAR ( _min, _max ),
        "Year", YEAR ( [Date] ),
        "Quarter Number", QUARTER ( [Date] ),
        "Quarter", "Q" & QUARTER ( [Date] ),
        "Month Number", MONTH ( [Date] ),
        "Month Name", FORMAT ( [Date], "mmmm" ),
        "Month", FORMAT ( [Date], "mmm yyyy" ),
        "Month Sort", YEAR ( [Date] ) * 100 + MONTH ( [Date] ),
        "Week", WEEKNUM ( [Date], 21 ),
        "Day", DAY ( [Date] ),
        "Day of Week", FORMAT ( [Date], "dddd" ),
        "Day of Week Number", WEEKDAY ( [Date], 2 ),
        "Is Weekend", WEEKDAY ( [Date], 2 ) >= 6,
        "Year-Month", FORMAT ( [Date], "yyyy-mm" ),
        "Year-Week", FORMAT ( YEAR ( [Date] ), "0000" ) & "-W" & FORMAT ( WEEKNUM ( [Date], 21 ), "00" ),
        "Year-Week Sort", YEAR ( [Date] ) * 100 + WEEKNUM ( [Date], 21 ),
        "Day Label", FORMAT ( [Date], "dd mmm" ),
        "Day Offset", DATEDIFF ( _max, [Date], DAY )
    )
"""
    cols = [
        ("Date", "dateTime", "dd-mmm-yyyy", "Calendar date. Primary date axis for every trend in this report.", False, None, True),
        ("Year", "int64", "0", "Calendar year.", False, None, False),
        ("Quarter Number", "int64", "0", "Quarter as a number, used to sort Quarter.", True, None, False),
        ("Quarter", "string", None, "Calendar quarter.", False, "Quarter Number", False),
        ("Month Number", "int64", "0", "Month as a number, used to sort Month Name.", True, None, False),
        ("Month Name", "string", None, "Full month name.", False, "Month Number", False),
        ("Month", "string", None, "Month and year, for example Oct 2025.", False, "Month Sort", False),
        ("Month Sort", "int64", "0", "Sort key for Month.", True, None, False),
        ("Week", "int64", "0", "ISO week number.", False, None, False),
        ("Day", "int64", "0", "Day of month.", False, None, False),
        ("Day of Week", "string", None, "Full weekday name.", False, "Day of Week Number", False),
        ("Day of Week Number", "int64", "0", "Weekday number with Monday as 1.", True, None, False),
        ("Is Weekend", "boolean", None, "True for Saturday and Sunday. Weekend volume runs materially lower, so this separates seasonality from incidents.", False, None, False),
        ("Year-Month", "string", None, "Year and month as yyyy-mm.", False, None, False),
        ("Year-Week", "string", None, "Year and ISO week as yyyy-Www.", False, "Year-Week Sort", False),
        ("Year-Week Sort", "int64", "0", "Sort key for Year-Week.", True, None, False),
        ("Day Label", "string", None, "Compact day label for dense trend axes.", False, "Date", False),
        ("Day Offset", "int64", "0", "Days relative to the latest loaded date. Zero is the latest date, -1 the day before.", False, None, False),
    ]
    s = "/// Date dimension generated from the loaded data range. Marked as the model date table; every trend uses this rather than the raw Event Date.\n"
    s += "table Dim_Date\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_Date") + "\n"
    s += TAB + "dataCategory: Time\n\n"
    for n, t, f, d, h, sb, key in cols:
        s += column_tmdl("Dim_Date", n, t, f, d, hidden=h, inferred=True,
                         source="[%s]" % n, is_key=key, sort_by=sb)
    s += TAB + "partition Dim_Date = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Dim_Date") + "\n"
    return s


def overlap_table():
    parts = []
    for seg, evidence, missing, order in OVERLAP_SEGMENTS:
        parts.append(
            '        SELECTCOLUMNS (\n'
            '            \'Fact_IDR_Daily\',\n'
            '            "Event Date", \'Fact_IDR_Daily\'[Event Date],\n'
            '            "Segment", "%s",\n'
            '            "Segment Type", "%s",\n'
            '            "Missing Event", "%s",\n'
            '            "Segment Order", %d,\n'
            '            "Population", \'Fact_IDR_Daily\'[%s]\n'
            '        )' % (seg, evidence, missing, order, seg))
    dax = ("-- The eight partial-match populations unpivoted to one row per date\n"
           "-- and segment.  They sum exactly to IDR Not Resolved, so this table\n"
           "-- is the decomposition of non-resolution: one ranking measure answers\n"
           "-- \"which reason is driving it?\" instead of eight separate ones.\n"
           "UNION (\n" + ",\n".join(parts) + "\n)\n")

    cols = [
        ("Event Date", "dateTime", "dd-mmm-yyyy", "Business date of the population snapshot.", True, None),
        ("Segment", "string", None, "Partial-match population: the evidence the profile did carry in CDP.", False, "Segment Order"),
        ("Segment Type", "string", None, "How much of the three-event evidence the profile carried: one of three, or two of three.", False, None),
        ("Missing Event", "string", None, "The event whose absence stopped the profile resolving. This is the thing to go and fix.", False, None),
        ("Segment Order", "int64", "0", "Display order, largest contributor first.", True, None),
        ("Population", "int64", "#,##0", "Profiles in this population on the date. Summing every segment for a date gives IDR Not Resolved.", True, None),
    ]
    s = "/// The eight partial-match populations unpivoted to one row per date and segment. They sum exactly to IDR Not Resolved, so this is the decomposition of why resolution failed.\n"
    s += "table Fact_Overlap_Daily\n"
    s += TAB + "lineageTag: " + lt("table", "Fact_Overlap_Daily") + "\n\n"
    for n, t, f, d, h, sb in cols:
        s += column_tmdl("Fact_Overlap_Daily", n, t, f, d, hidden=h, inferred=True,
                         source="[%s]" % n, sort_by=sb)
    s += TAB + "partition Fact_Overlap_Daily = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Fact_Overlap_Daily") + "\n"
    return s


def _datatable(name, desc, coldefs, rows, hidden_cols=(), sort_map=None):
    """Build a DATATABLE-backed calculated dimension."""
    sort_map = sort_map or {}
    types = ", ".join('"%s", %s' % (c, t) for c, t in coldefs)
    body = []
    for r in rows:
        vals = []
        for v in r:
            if isinstance(v, str):
                vals.append('"%s"' % v.replace('"', '""'))
            else:
                vals.append(str(v))
        body.append("        { " + ", ".join(vals) + " }")
    dax = "DATATABLE (\n    %s,\n    {\n%s\n    }\n)\n" % (types, ",\n".join(body))

    s = "/// " + desc + "\n"
    s += "table " + q(name) + "\n"
    s += TAB + "lineageTag: " + lt("table", name) + "\n\n"
    for (c, t), d in zip(coldefs, [None] * len(coldefs)):
        pass
    return s, dax


def alert_rules_table():
    rows = [(k, n, c, p, RULE_DESCRIPTIONS[k]) for k, n, c, p in ALERT_RULES]
    coldefs = [("Rule Key", "STRING"), ("Rule", "STRING"), ("Category", "STRING"),
               ("Rule Priority", "INTEGER"), ("Rule Description", "STRING")]
    types = ", ".join('"%s", %s' % (c, t) for c, t in coldefs)
    body = ",\n".join(
        '        { %s }' % ", ".join('"%s"' % v.replace('"', '""') if isinstance(v, str) else str(v)
                                     for v in r) for r in rows)
    dax = ("-- Disconnected rule catalogue.  One row per business rule; the severity,\n"
           "-- value, baseline and message measures dispatch on Rule Key.  Adding a\n"
           "-- rule is a row here plus one SWITCH branch, not a new page.\n"
           "DATATABLE (\n    %s,\n    {\n%s\n    }\n)\n" % (types, body))

    cols = [
        ("Rule Key", "string", None, "Stable key the DAX alert engine dispatches on. Do not rename.", True, None),
        ("Rule", "string", None, "Business name of the alert rule.", False, "Rule Priority"),
        ("Category", "string", None, "Domain the rule belongs to.", False, None),
        ("Rule Priority", "int64", "0", "Tie-break order within a severity. 1 is most urgent.", True, None),
        ("Rule Description", "string", None, "What the rule detects.", False, None),
    ]
    s = "/// Catalogue of the nine business alert rules. Drives the executive alert panel.\n"
    s += "table Dim_Alert_Rules\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_Alert_Rules") + "\n\n"
    for n, t, f, d, h, sb in cols:
        s += column_tmdl("Dim_Alert_Rules", n, t, f, d, hidden=h, inferred=True,
                         source="[%s]" % n, sort_by=sb)
    s += TAB + "partition Dim_Alert_Rules = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Dim_Alert_Rules") + "\n"
    return s


def scorecard_table():
    coldefs = [("Metric Key", "STRING"), ("Metric", "STRING"), ("Scorecard Order", "INTEGER")]
    types = ", ".join('"%s", %s' % (c, t) for c, t in coldefs)
    body = ",\n".join('        { "%s", "%s", %d }' % r for r in SCORECARD_ROWS)
    dax = ("-- Rows of the Management Summary scorecard.  Disconnected: the value,\n"
           "-- target, trend and status measures dispatch on Metric Key.\n"
           "DATATABLE (\n    %s,\n    {\n%s\n    }\n)\n" % (types, body))
    cols = [
        ("Metric Key", "string", None, "Stable key the scorecard measures dispatch on.", True, None),
        ("Metric", "string", None, "Metric name shown in the scorecard.", False, "Scorecard Order"),
        ("Scorecard Order", "int64", "0", "Display order.", True, None),
    ]
    s = "/// Rows of the Management Summary scorecard.\n"
    s += "table Dim_Scorecard\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_Scorecard") + "\n\n"
    for n, t, f, d, h, sb in cols:
        s += column_tmdl("Dim_Scorecard", n, t, f, d, hidden=h, inferred=True,
                         source="[%s]" % n, sort_by=sb)
    s += TAB + "partition Dim_Scorecard = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Dim_Scorecard") + "\n"
    return s


def metric_watch_table():
    coldefs = [("Metric", "STRING"), ("Format", "STRING"), ("Metric Order", "INTEGER")]
    types = ", ".join('"%s", %s' % (c, t) for c, t in coldefs)
    body = ",\n".join('        { "%s", "%s", %d }' % (m[0], m[1].replace('"', '""'), i + 1)
                      for i, m in enumerate(WATCH_METRICS))
    dax = ("-- Watchlist of headline metrics.  Disconnected: the Selected Metric\n"
           "-- measures dispatch on Metric, which is why the Root Cause Explorer can\n"
           "-- show every metric moving side by side on a single date.\n"
           "DATATABLE (\n    %s,\n    {\n%s\n    }\n)\n" % (types, body))
    cols = [
        ("Metric", "string", None, "Metric name. Must match the measure names in the trend-intelligence layer.", False, "Metric Order"),
        ("Format", "string", None, "Format string the metric is rendered with.", True, None),
        ("Metric Order", "int64", "0", "Display order.", True, None),
    ]
    s = "/// Watchlist of headline metrics, used as the row source of the Root Cause Explorer comparison table.\n"
    s += "table Dim_Metric_Watch\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_Metric_Watch") + "\n\n"
    for n, t, f, d, h, sb in cols:
        s += column_tmdl("Dim_Metric_Watch", n, t, f, d, hidden=h, inferred=True,
                         source="[%s]" % n, sort_by=sb)
    s += TAB + "partition Dim_Metric_Watch = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Dim_Metric_Watch") + "\n"
    return s


def dq_checks_table():
    coldefs = [("Check Key", "STRING"), ("Check", "STRING"), ("Category", "STRING"),
               ("Check Order", "INTEGER"), ("Check Description", "STRING")]
    types = ", ".join('"%s", %s' % (c, t) for c, t in coldefs)
    body = ",\n".join(
        '        { "%s", "%s", "%s", %d, "%s" }'
        % (k, n.replace('"', '""'), c, i + 1, d.replace('"', '""'))
        for i, (k, n, c, _m, d) in enumerate(DQ_CHECKS))
    dax = ("-- Catalogue of data-quality checks.  Structural and arithmetic checks\n"
           "-- count as defects; analytical checks are surfaced here but alerted\n"
           "-- through the rule engine so nothing is scored twice.\n"
           "DATATABLE (\n    %s,\n    {\n%s\n    }\n)\n" % (types, body))
    cols = [
        ("Check Key", "string", None, "Stable key the data-quality measures dispatch on.", True, None),
        ("Check", "string", None, "Name of the data-quality check.", False, "Check Order"),
        ("Category", "string", None, "Structural, Arithmetic, Trust, Completeness or Analytical.", False, None),
        ("Check Order", "int64", "0", "Display order.", True, None),
        ("Check Description", "string", None, "What the check detects and why it matters.", False, None),
    ]
    s = "/// Catalogue of the data-quality checks run against the loaded data.\n"
    s += "table Dim_DQ_Checks\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_DQ_Checks") + "\n\n"
    for n, t, f, d, h, sb in cols:
        s += column_tmdl("Dim_DQ_Checks", n, t, f, d, hidden=h, inferred=True,
                         source="[%s]" % n, sort_by=sb)
    s += TAB + "partition Dim_DQ_Checks = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Dim_DQ_Checks") + "\n"
    return s


def timeframe_table():
    coldefs = [("Timeframe", "STRING"), ("Days", "INTEGER"), ("Timeframe Order", "INTEGER")]
    types = ", ".join('"%s", %s' % (c, t) for c, t in coldefs)
    body = ",\n".join('        { "%s", %d, %d }' % r for r in TIMEFRAMES)
    dax = ("-- Disconnected timeframe selector.  Windows are measured back from the\n"
           "-- latest loaded business date, so the report keeps working when the feed\n"
           "-- lags the calendar.  Zero days means all history.\n"
           "DATATABLE (\n    %s,\n    {\n%s\n    }\n)\n" % (types, body))
    cols = [
        ("Timeframe", "string", None, "Timeframe label shown in the slicer.", False, "Timeframe Order"),
        ("Days", "int64", "0", "Length of the window in days. Zero means all history.", True, None),
        ("Timeframe Order", "int64", "0", "Display order.", True, None),
    ]
    s = "/// Disconnected timeframe selector for the Historical Trends page.\n"
    s += "table Dim_Timeframe\n"
    s += TAB + "lineageTag: " + lt("table", "Dim_Timeframe") + "\n\n"
    for n, t, f, d, h, sb in cols:
        s += column_tmdl("Dim_Timeframe", n, t, f, d, hidden=h, inferred=True,
                         source="[%s]" % n, sort_by=sb)
    s += TAB + "partition Dim_Timeframe = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Dim_Timeframe") + "\n"
    return s


def trend_metric_table():
    rows = ",\n".join(
        '    ("%s", NAMEOF ( \'_Metrics\'[%s] ), %d)' % (f, f, i)
        for i, f in enumerate(TREND_METRIC_FIELDS))
    dax = ("-- Field parameter: lets an executive swap the metric on the Historical\n"
           "-- Trends page without a page per metric.\n"
           "{\n" + rows + "\n}\n")
    s = "/// Field parameter listing the metrics available on the Historical Trends page.\n"
    s += "table " + q("Trend Metric") + "\n"
    s += TAB + "lineageTag: " + lt("table", "Trend Metric") + "\n\n"
    s += column_tmdl("Trend Metric", "Trend Metric", "string", None,
                     "Metric selected for the trend chart.", sort_by="Trend Metric Order",
                     source="[Value1]")
    s += column_tmdl("Trend Metric", "Trend Metric Fields", "string", None,
                     "Underlying measure reference for the selected metric.",
                     hidden=True, source="[Value2]",
                     extended='{\n  "version": 3,\n  "kind": 2\n}')
    s += column_tmdl("Trend Metric", "Trend Metric Order", "int64", "0",
                     "Display order in the field parameter slicer.",
                     hidden=True, source="[Value3]", summarize="sum")
    s += TAB + "partition " + q("Trend Metric") + " = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block(dax, 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "Trend Metric") + "\n"
    return s


def metrics_table(measures):
    s = "/// Home table for every explicit measure in the model. Holds no data of its own.\n"
    s += "table _Metrics\n"
    s += TAB + "lineageTag: " + lt("table", "_Metrics") + "\n\n"
    for m in measures:
        s += measure_tmdl(m)
    s += column_tmdl("_Metrics", "_", "string", None, None, hidden=True,
                     inferred=True, source="[_]")
    s += TAB + "partition _Metrics = calculated\n"
    s += TAB * 2 + "mode: import\n"
    s += TAB * 2 + "source" + block('ROW ( "_", "" )', 4)
    s += "\n"
    s += TAB + "annotation PBI_Id = " + lt("pbiid", "_Metrics") + "\n"
    return s


# ==========================================================================
# model-level files
# ==========================================================================
def expressions_tmdl():
    params = [
        ("ProjectDataFolder", os.path.join(ROOT, "data"),
         "Folder holding the source workbook and the configuration CSVs. Repoint this to move the project."),
        ("SourceWorkbookName", "idr_kafka_edl.xlsx",
         "File name of the source workbook inside ProjectDataFolder."),
        ("SourceSheetName", "idr",
         "Worksheet holding the daily data. The query falls back to the first sheet if this name is not found."),
    ]
    s = ""
    for name, default, desc in params:
        s += "/// " + desc + "\n"
        s += "expression " + q(name) + " = \"" + default.replace('"', '""') + "\""
        s += " meta [IsParameterQuery=true, Type=\"Text\", IsParameterQueryRequired=true]\n"
        s += TAB + "lineageTag: " + lt("expression", name) + "\n"
        s += "\n"
        s += TAB + "annotation PBI_ResultType = Text\n"
        s += "\n"
    return s


def relationships_tmdl():
    rels = [
        ("Dim_Date_Fact_IDR_Daily", "Fact_IDR_Daily", "Event Date", "Dim_Date", "Date"),
        ("Dim_Date_Fact_Overlap_Daily", "Fact_Overlap_Daily", "Event Date", "Dim_Date", "Date"),
    ]
    s = ""
    for name, ft, fc, tt, tc in rels:
        s += "relationship " + name + "\n"
        s += TAB + "fromColumn: " + ft + "." + q(fc) + "\n"
        s += TAB + "toColumn: " + tt + "." + q(tc) + "\n"
        s += "\n"
    return s


def model_tmdl(tables):
    s = "model Model\n"
    s += TAB + "culture: en-US\n"
    s += TAB + "defaultPowerBIDataSourceVersion: powerBI_V3\n"
    s += TAB + "discourageImplicitMeasures\n"
    s += TAB + "sourceQueryCulture: en-US\n"
    s += TAB + "dataAccessOptions\n"
    s += TAB * 2 + "legacyRedirects\n"
    s += TAB * 2 + "returnErrorValuesAsNull\n"
    s += "\n"
    s += "annotation PBI_QueryOrder = [\"ProjectDataFolder\",\"SourceWorkbookName\",\"SourceSheetName\",\"Fact_IDR_Daily\",\"Dim_Thresholds\",\"Dim_Metric_Definitions\",\"Refresh Info\"]\n"
    s += "\n"
    s += "annotation __PBI_TimeIntelligenceEnabled = 0\n"
    s += "\n"
    s += "annotation PBI_ProTooling = [\"DevMode\"]\n"
    s += "\n"
    for t in tables:
        s += "ref table " + q(t) + "\n"
    s += "\n"
    s += "ref role Viewer\n"
    return s


def roles_tmdl():
    s = "/// Read-only consumption role. No row filters: this is a single-tenant operational model.\n"
    s += "role Viewer\n"
    s += TAB + "modelPermission: read\n"
    return s


def database_tmdl():
    return "database\n" + TAB + "compatibilityLevel: 1567\n"


# ==========================================================================
# main
# ==========================================================================
def collect_measures():
    ms = []
    ms += date_context()
    ms += base_measures()
    ms += period_measures()
    ms += trend_measures()
    ms += threshold_measures()
    ms += severity_measures()
    ms += alert_measures()
    ms += health_measures()
    ms += dq_measures()
    ms += narrative_measures()
    ms += ux_measures()
    ms += selector_measures()
    ms += dq_check_measures()
    seen = {}
    for m in ms:
        if m["name"] in seen:
            raise SystemExit("duplicate measure name: %s" % m["name"])
        seen[m["name"]] = m
    return ms


def main():
    measures = collect_measures()

    rmtree_resilient(MODEL_DIR)

    tables = {
        "Fact_IDR_Daily": fact_table(),
        "Fact_Overlap_Daily": overlap_table(),
        "Dim_Date": date_table(),
        "Dim_Thresholds": thresholds_table(),
        "Dim_Metric_Definitions": metric_definitions_table(),
        "Dim_Alert_Rules": alert_rules_table(),
        "Dim_Scorecard": scorecard_table(),
        "Dim_Timeframe": timeframe_table(),
        "Dim_Metric_Watch": metric_watch_table(),
        "Dim_DQ_Checks": dq_checks_table(),
        "Trend Metric": trend_metric_table(),
        "Refresh Info": refresh_table(),
        "_Metrics": metrics_table(measures),
    }
    order = ["Fact_IDR_Daily", "Fact_Overlap_Daily", "Dim_Date", "Dim_Thresholds",
             "Dim_Metric_Definitions", "Dim_Alert_Rules", "Dim_Scorecard",
             "Dim_Timeframe", "Dim_Metric_Watch", "Dim_DQ_Checks", "Trend Metric",
             "Refresh Info", "_Metrics"]

    for name in order:
        write(os.path.join(DEF, "tables", name + ".tmdl"), tables[name])

    write(os.path.join(DEF, "model.tmdl"), model_tmdl(order))
    write(os.path.join(DEF, "database.tmdl"), database_tmdl())
    write(os.path.join(DEF, "expressions.tmdl"), expressions_tmdl())
    write(os.path.join(DEF, "relationships.tmdl"), relationships_tmdl())
    write(os.path.join(DEF, "roles", "Viewer.tmdl"), roles_tmdl())

    # Power BI requires $schema on the .pbism and refuses to open the project
    # without it. The URL lives under item/semanticModel/, not item/pbism/.
    write(os.path.join(MODEL_DIR, "definition.pbism"), json.dumps({
        "$schema": SCHEMA_PBISM,
        "version": "4.2",
        "settings": {},
    }, indent=2) + "\n")
    write(os.path.join(MODEL_DIR, ".platform"),
          '{\n'
          '  "$schema": "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/platformProperties/2.0.0/schema.json",\n'
          '  "metadata": {\n'
          '    "type": "SemanticModel",\n'
          '    "displayName": "%s"\n'
          '  },\n'
          '  "config": {\n'
          '    "version": "2.0",\n'
          '    "logicalId": "%s"\n'
          '  }\n'
          '}\n' % (PROJECT, lt("logical", "SemanticModel")))
    write(os.path.join(MODEL_DIR, "diagramLayout.json"),
          '{\n  "version": "1.1.0",\n  "diagrams": []\n}\n')

    print("semantic model written to %s" % MODEL_DIR)
    print("  tables:   %d" % len(order))
    print("  measures: %d" % len(measures))
    folders = {}
    for m in measures:
        folders[m["folder"].split("\\")[0]] = folders.get(m["folder"].split("\\")[0], 0) + 1
    for f in sorted(folders):
        print("    %-28s %3d" % (f, folders[f]))


if __name__ == "__main__":
    main()
